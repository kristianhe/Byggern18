#include "setup.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

void XMEM_Init(void);
int MEM_write(uint16_t ad_start, uint16_t adress, char data);
int MEM_read(uint16_t ad_start, uint16_t adress);
void SRAM_test();

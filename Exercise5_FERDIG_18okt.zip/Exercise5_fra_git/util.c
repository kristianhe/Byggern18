#include "util.h"

void timer1_init(){

	TCCR1A = 0x00; //top value = 0xFFFF
	TCCR1B |= (0<<CS12) | (1<<CS11) | (0<<CS10); // clk/8 prescale -> overflow hvert 0.1 s
	TIMSK |= (1<<TOIE1);
}

void exInterInit_0(){
	MCUCR |= (1<<ISC01) | (0<<ISC00);
	GICR |= (1<<INT0);
}

void exInterInit_1(){
	MCUCR |= (0<<ISC11) | (1<<ISC10);
	GICR |= (1<<INT1);
}

void blink(){
	pinB |= (0b00000001);
	_delay_ms(250);
	pinB &= ~(0b00000001);
	_delay_ms(250);
	pinB |= (0b00000001);
}

int  Scale(uint8_t  In, int  MaxIn, int  MinIn, int  MaxOut, int  MinOut)
{
	float k;
  int in = (int)In;
	int Out;

	k = (float)(MaxOut-MinOut)/(float)(MaxIn-MinIn);
  Out = (int)(k*in-k*MinIn+MinOut);

  return Out;
}

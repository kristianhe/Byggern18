
#include "setup.h"
#include "uart.h"
#include "memory.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "oled.h"
#include "oledMeny.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

bool Deltime = false;
bool flagMenu = false;
bool Button = false;

uint8_t slidL;
uint8_t slidR;
uint8_t buttonL;
uint8_t buttonR;
uint8_t counter = 0;
uint16_t tellerMenu = 0;

uint8_t Rvalue = 3;
char Wvalue = 42;

Joystick_Position joyPos;
Joystick_Direction joyDir;
Slider_Position sliPos;

ISR(TIMER1_OVF_vect){
	Deltime ^= true;
}
ISR(INT0_vect){
	Button = true;
}
bool timerDelay() //interupt-basert delayfunksjon på 500 ms
{
	if(Deltime){
		Deltime = false;
		return true;
	}
	else{return false;}
}

int main(void){
	DDRB |= (1<<PB0);

	exInterInit_0();
	timer1_init();
	XMEM_Init();
	UART_Init(MYUBRR);
	//spi_init();		// Overflødig når canInit under
	canInit();

	loopbackInit();

	//SRAM_test();

	Joystick_Init();
	oled_init();
	menuInit();

	sei();

	CAN_frame TXtest;
	CAN_frame RXtest;

	TXtest.id = 5;
	TXtest.length = 4;
	TXtest.data[0] = 1;
	TXtest.data[1] = 2;
	TXtest.data[2] = 3;
	TXtest.data[3] = 4;


	while(1)
	{

		canTransmit(TXtest);
		_delay_ms(500);
		RXtest = canRecive();
		_delay_ms(100);
		printf("ID: %d	Lengde: %d\n", RXtest.id, RXtest.length);
		_delay_ms(500);
		for(uint8_t i = 0; i < RXtest.length; i++)
		{
			printf("Data[%d]: %d\n", i, RXtest.data[i]);
		}
		printf("\n");
		/*
		joyDir = Joystick_getDirection();
		if(timerDelay()){counter++;}

		if ((joyDir == 2) && ((flagMenu == false) || (counter > 2))) // UP
		{
			menuDecrementPosition();
			flagMenu = true;
			counter = 0;
		}
		else if ((joyDir == 3) && ((flagMenu == false) || (counter > 2))) // DOWN
		{
			menuIncrementPosition();
			flagMenu = true;
			counter = 0;
		}
		else if (joyDir == 4)	// NEUTRAL
		{
			if (timerDelay()){flagMenu = false;}
		}

		if (Button)
		{
			printf("Go to boathoase\n");
			menuEnter();
			Button = false;
		}
		*/
	}
	return 0;
}

/*
joyPos = Joystick_getPosition();
joyDir = Joystick_getDirection();
sliPos = Slider_getPosition();
buttonL = Slider_getLeftButton();
buttonR = Slider_getRightButton();
*/

#include "setup.h"
#include "memory.h"
#include "util.h"
#include "MCP2515.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

typedef struct CAN_frame CAN_frame;
struct CAN_frame
{
  uint8_t   id;
  uint8_t   length;
  uint8_t   data[8];
};

void canInit();
void canTransmit(CAN_frame frame);
CAN_frame canRecive();
bool canTXcomp();
//SIDH  >> 3
//SIDL << 5

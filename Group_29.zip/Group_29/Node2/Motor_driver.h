#include "setup.h"
#include "timer.h"
#include "util.h"
#include "TWI_Master.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define OE PH5
#define RST PH6
#define SEL PH3
#define EN PH4
#define DIR PH1

void motorInit();
void motorControl(int input);
void encoderReset();
uint16_t encoderRead();
void EC_disable();
void EC_enable();

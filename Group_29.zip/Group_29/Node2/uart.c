#include "uart.h"

FILE *uart;

char test[10];

void UART_init(unsigned int ubrr)
{
	UBRR0L = (unsigned char)(ubrr);									//Sets baud rate of UART0
	UBRR0H = (unsigned char)(ubrr >> 8);
	UCSR0B = (1<<RXEN0) | (1<<TXEN0); 							//Turns on the receiver (RXEN0) and the transmitter (TXEN0)
	UCSR0C = (1<<USBS0) | (3<<UCSZ00); 							//Sets the frame format: 8 data, 2 stop bit, no parity
	uart = fdevopen(&UART_transmit, &UART_Receive);	//Connects printf (Neat'o)
}

int UART_transmit(char c, FILE *f) 								//Waits for an empty transmission buffer
{
	while (!(UCSR0A & (1<<UDRE0)));
	UDR0 = c; 																			//Puts data (char) in the buffer (UDR0)
	return 0;
}

unsigned char UART_Receive(void)
{
	//unsigned char data;
	while (!(UCSR0A & (1<<RXC0))); 									//Waits for data to be received
	//if (UCSR0A & (1<<RXC0)) data = UDR0;

	return UDR0; 																		//Grabs and returns opposite data from the buffer
}

void UART_flush(void) 														//Flushing of the receive buffer
{
	unsigned char dummy;
	while ( UCSR0A & (1<<RXC0) ) dummy = UDR0;
}

unsigned char UART_Receive_Instant(void)
{
	if (UCSR0A & (1<<RXC0)) return UDR0;
	else return 'X';
}

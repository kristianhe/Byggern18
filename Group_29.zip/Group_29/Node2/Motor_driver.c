#include "Motor_driver.h"

void motorInit()
{
  TWI_Master_Initialise();

	DDRH |= (1 << OE) | (1 << RST) | (1 << SEL) | (1 << EN) | (1 << DIR); 	//Setter alle portene vi vil bruke til motorstyring som outputs (MJ1)
	DDRK = 0;                                                               //Setter alle portene vi vil bruke til lesing av enkoderen til inputs (MJ2)
	PORTH |= (1 << EN);		                                                  //Enable motor
	PORTH &= ~(1 << OE);	                                                  //Output enable (encoder) (active low)

  EC_enable();
	encoderReset();		                                                      //Reset encoder
}

void motorControl(int input)
{
  uint8_t motorGain = (uint8_t)abs(input);

  if (input < 0){
    PORTH |= (1 << DIR);
    DAC_write(motorGain);
  }
  else
  {
    PORTH &= ~(1 << DIR);
    DAC_write(motorGain);
  }
}

void encoderReset()
{
	PORTH &= ~(1 << RST);		 //Toggle !RST to reset encoder (active low)
	_delay_ms(10);				   //Wait
	PORTH |= (1 << RST);		 //Toggle back
}

uint16_t encoderRead()
{
  //PORTH &= ~(1 << OE);	    // Output enable (encoder) (active low)
	PORTH &= ~(1 << SEL);		    // Setter SEL lav for å få de høye bittene
	_delay_us(30);				      // Vent ~20 mikrosekunder
	uint8_t encoderH = PINK;		// Leser de høyeste bittene
	PORTH |= (1 << SEL);		    // Setter SEL høy for å få de lave bittene
	_delay_us(30);				      // Vent ~20 mikrosekunder
	uint8_t encoderL = PINK;		// Leser de laveste bittene

  uint16_t res = (-1)*(uint16_t)((encoderH << 8) | encoderL);
  return res;
}

void EC_disable()
{
  PORTH |= (1 << OE);	        //Output disenable (encoder) (active low)
}
void EC_enable()
{
  PORTH &= ~(1 << OE);	      //Output enable (encoder) (active low)
}

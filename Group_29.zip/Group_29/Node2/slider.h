#include "setup.h"
#include "adc.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#ifndef SLIDER_H_
#define SLIDER_H_

typedef struct slider_position {
	uint8_t	left;
	uint8_t right;
} slider_position;

void sliderInit();
slider_position sliderGetPosition();
int sliderGetLeftButton();
int sliderGetRightButton();

#endif

#include "DAC_driver.h"

void DAC_write(uint8_t motorVoltage) 				//Writes from the MCU to the DAC-IC (MAX520) through the I2C/TWI bus. We change the motor voltag with the outputs of the DAC
{
	uint8_t data[3];

	data[0] = 0x50;														//Slave address byte (unchanged, the first 0101 is default, the rest is 0000).
	data[1] = 0x00;														//Command byte (dont do anything, we're just setting the DAC outputs)
	data[2] = motorVoltage;										//Output byte

  TWI_Start_Transceiver_With_Data(data, 3);	//3 is the message length. Logic for START and STOPP is made in these functions
}

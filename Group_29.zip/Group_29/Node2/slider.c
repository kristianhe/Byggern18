#include "slider.h"

void sliderInit()
{
	DDRB &= ~(1 << DDB1);
	DDRB &= ~(1 << DDB2);
}

slider_position sliderGetPosition()
{
	slider_position sliPos;
	sliPos.left  = ADC_read(2);
	sliPos.right = ADC_read(3);

	return sliPos;
}

int sliderGetLeftButton()
{
	return !(!(PINB & (1 << PINB1)));
}

int sliderGetRightButton()
{
	return !(!(PINB & (1 << PINB2)));
}

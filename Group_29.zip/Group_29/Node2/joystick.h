#include "setup.h"
#include "util.h"
#include "adc.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#ifndef JOYSTICK_H_
#define JOYSTICK_H_

typedef enum
{
	LEFT,
	RIGHT,
	UP,
	DOWN,
	NEUTRAL
}Joystick_Direction;

typedef struct
{
	int x;
	int y;
}Joystick_Position;

void joystickInit();
void joystickCalibrate();
Joystick_Position joystickGetPosition();
Joystick_Direction joystickGetDirection();
int joystickGetButton();

#endif

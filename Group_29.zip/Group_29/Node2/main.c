/*==============================================================================
Solution for the lab in TTK4155 by group 29
- Extensive use of timer functionalities
- No use  util/delay for timing over ~1 ms
- Added functionalities for talking to a graphical user interface using UART
================================================================================*/
#include "setup.h"
#include "uart.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"
#include "timer.h"
#include "Notes.h"
#include "Motor_driver.h"
#include "pid.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>     		//atoi
#include <string.h>					//strchr
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define K_P   1
#define K_I 	0.0
#define K_D 	1.3

#define SCALING 100
struct PID_DATA pidData;
uint16_t PID_param [4][3] = {{100,0,130},{150,0,90},{300,50,90},{300,0,10}};

bool Deltime = false;
bool INTflag = false;

//Global counters
uint8_t stateCounter = 0;
uint8_t trigCounter = 0;
uint8_t timeStep = 0;
uint8_t startupCounter = 0;
uint8_t SCTlimit = 0;
uint16_t scorecount = 0;

//Timer0 overflow interrupt
ISR(TIMER0_OVF_vect){
	trigCounter++;
	timeStep++;
	startupCounter++;
	stateCounter++;
	SCTlimit++;
}

//Timer1 overflow interrupt
ISR(TIMER1_OVF_vect){
	scorecount++;
}

//function for setting different difficultes
void setDiff(char level) {
	switch (level) {
		case 1:
			pid_ChangeControllerValues(PID_param [0][0], PID_param [0][1], PID_param [0][2], &pidData);
			break;
		case 2:
			pid_ChangeControllerValues(PID_param [1][0], PID_param [1][1], PID_param [1][2], &pidData);
			break;
		case 3:
			pid_ChangeControllerValues(PID_param [2][0], PID_param [2][1], PID_param [2][2], &pidData);
			break;
		case 4:
			pid_ChangeControllerValues(PID_param [3][0], PID_param [3][1], PID_param [3][1], &pidData);
			break;
	}
}

//Initialize the drivers
void drivers()
{
	UART_init(MYUBRR);
	PWM_init();
	timer0_init();
	timer1_init();
	CAN_init();
	IR_init();
	motorInit();
	PID_init(K_P*SCALING, K_I*SCALING, K_D*SCALING, &pidData);
}

int main(void)
{
	//Drivers and global interrupt
	drivers();
	sei();
	DDRE |= (1<<PE4);
	OCR3A = 3200;

	//State variables for the game
	uint8_t score = 0;
	uint8_t state = 42;
	bool stateFlag = false;


	//Inputs and outputs
	uint8_t servoVal = 0;
	uint8_t joyPos_x = 0;
	uint8_t dirVal = 0;
	uint8_t solenoid = 0;
	uint8_t sliderPos = 0;
	uint8_t IR_value = 255;

	//For the PID controller
	uint8_t refPos = 128;
	uint16_t enc = 0;
	int motorInput = 0;
	uint16_t tmpEnc1 = 0;
	uint16_t tmpEnc2 = 0;
	int deltaEnc = 0;

	//Boolean control variables
	bool startFlag = false;
	bool trigFlag = false;
	bool trigCountFlag = false;
	bool GUImode = false;
	bool GUIexit = false;
	bool GAMEOVER = false;

	//For state machine
	bool oddFlag = true;
	bool evenFlag = false;
	bool calcDelta = false;
	bool pidFlag = false;

	//CAN frame
	CAN_frame RXframe;
	CAN_frame TXframe;
	CAN_frame GUIframe;
	GUIframe.id = 94;
	TXframe.id = 13;
	TXframe.length = 1;
	TXframe.data[0] = 0;
	//Pregame ID 62
	//Ingame ID 42

	//Variables used for the GUI
	char guidata[15];
	char inputChar = 0;
	bool endMsgFlag = false;
	uint8_t len = 0;
	uint8_t ctr = 0;
	char dummy;
	int PID_temp = 0;
	int kp = 0;
	int ki = 0;
	int kd = 0;

	//Resetting the motor and encoder
	while((startupCounter < 100) && !(startFlag))
	{
		motorControl(-128);
		encoderReset();
	}
	printf("Node 2 opertional\n");
	_delay_ms(500);

	while(1)
	{
		//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			//functions that are run continuously
		//------------------------------------
		//DC motor, servo motor and IR
		//---------------------------------------------------------------------------
		motorControl(motorInput); 											//Gain for the DC motor
		OCR3A = scale(servoVal, 255,0, 4600, 1800); 		//PWM values for the servo motor, In: 0 - 255. out: 1800 - 4600 ~ Translates to duty cycle 0.9 - 2.1 ms
		IR_value = IR_readWithFilter(); 								//Reading the values from the ADC. Can be in the range 0 - ~50
		//---------------------------------------------------------------------------

		//logic for when the IR diodes are blocked
		//---------------------------------------------------------------------------
		if ((IR_value < 10) && (SCTlimit > 100)) GAMEOVER = true;
		else if ((state == 69) && (scorecount%2 == 0)){
			score++;
			printf("score %d\n", score);
		}
		//---------------------------------------------------------------------------

		//UART reception (TX/RX GUI)
		//---------------------------------------------------------------------------
		if (GUImode){
			//----------------------------
			dummy = UART_Receive_Instant();

			if (dummy != 'X')
			{
				for (int k = 0; k < len; k++) guidata[k] = "";
				len = 0;
				guidata[len++] = dummy;

				while (!endMsgFlag)
				{
					inputChar = UART_Receive();
					guidata[len++] = inputChar;
					if (inputChar == '#') endMsgFlag = true;
				}
				endMsgFlag = false;

				int posHash = strcspn(guidata, "#");
				char temp[posHash-2];

				for (uint8_t i = 0; i < (posHash - 1); i++) temp[i] = guidata[i + 1];

				if (guidata[0] == 'S') 				solenoid  = atoi(temp);	// Solenoid
				else if (guidata[0] == 'D') 	servoVal  = atoi(temp); // Servo
				else if (guidata[0] == 'R') 	sliderPos = atoi(temp); // DC-motor referanse (slider)
				else if (guidata[0] == 'C')
				{
					PID_temp = atoi(temp);
					kp = PID_temp/100;
					ki = (PID_temp - kp*100)/10;
					kd = (PID_temp - kp*100 - ki*10);
					pid_ChangeControllerValues(kp*50, ki*50, kd*50, &pidData);
				}
				else if (guidata[0] == 'Q')
				{
					GUImode = false;
					GUIexit = true;
				}
			}

		}
		//--------------------------------------------------------------------------

		//CAN reception
		//---------------------------------------------------------------------------
		if (CAN_receive(&RXframe) && !(GUImode))
		{
			if(RXframe.id == 42){
				state = RXframe.id;
				//Difficulty level sent from node 1
				if(RXframe.data[0]) setDiff(1);
				if(RXframe.data[1]) setDiff(1);
				if(RXframe.data[2]) setDiff(1);
				if(RXframe.data[3]) setDiff(1);

				servoVal = 128;
				solenoid = 10;
				sliderPos = 0;
			}
			else if (RXframe.id == 69){
				servoVal = RXframe.data[0];
				dirVal =  RXframe.data[2];
				solenoid = RXframe.data[3];
				sliderPos = RXframe.data[4];
			}
		}
		//---------------------------------------------------------------------------

		//Reading the encoder
		//---------------------------------------------------------------------------
		//Avoiding sending negative values to the PID function
		if ((int)encoderRead() < 0)
		{
			enc = 5;
			refPos = 10;
		}
		else
		{
			//This is the values we are expecting
			//Scaling the encoder values from the range 20 - 10000 to 0 - 255
			enc = scale16(encoderRead(), 10000, 20, 255, 0);
			refPos = sliderPos;
		}
		//---------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//Switch case used for the three states in the game: PRE-GAME, IN-GAME and POST-GAME (reset)
	switch (state) {
			//-----------------------------------------------------------------------------------------------------------------
			case 42:
				//----------------------
				//PRE-GAME
				//----------------------

				motorInput = 0; //Zero motor gain
				if(RXframe.id == 69) state = 69;	//Normal mode using the multi.func card
				else if (RXframe.id == 49) { 			//Enabling GUI mode
					GUImode = true;
					state = 69;
				}
				break;
			//-----------------------------------------------------------------------------------------------------------------
			case 69:
				//----------------------
				//IN-GAME
				//----------------------

				//State machine for PID PID_controller
				//-----------------------------------------------------------------------
				if (((timeStep%2) == 0) && (oddFlag) && !(evenFlag))
				{
					//Previous encoder value, sample at odd numbers of the counter value
					tmpEnc1 = enc;
					//Go to next state flags
					oddFlag = false;
					evenFlag = true;
				}
				else if (((timeStep%2) != 0) && (evenFlag) && !(oddFlag))
				{
					//Current encoder value, sample at even numbers of the counter value
					tmpEnc2 = enc;

					//Go to next state flags
					evenFlag = false;
					calcDelta = true;
				}
				if (calcDelta){
					//Calculating delta value for the encoder, used for the derivative part in the PID controller
					deltaEnc = (int)(tmpEnc2 - tmpEnc1);
					//Go to next state flags
					calcDelta = false;
					pidFlag = true;
				}
				if (pidFlag)
				{
					//Output from the PID controller
					motorInput = PID_controller(refPos, enc, timeStep, deltaEnc, &pidData);
					//Go to next state flags
					pidFlag = false;
					oddFlag = true;
				}
				//-----------------------------------------------------------------------

				//Logic for solenoid trigering
				//-----------------------------------------------------------------------
				if (solenoid == 133) trigFlag = true;
				if (trigFlag){
					PORTE |= (1<<PE4); 		//Set output pin PE4 high
																//Go to next state flags and counters
					printf("$Fire*\n");
					trigFlag = false;
					trigCountFlag = true;
					trigCounter = 0;
				}
				if ((trigCountFlag) && (trigCounter > 10)){
					PORTE &= ~(1<<PE4); 	//Set output pin PE4 low
																//Go to next state flags and counters
					trigCountFlag = false;
					trigCounter = 0;
				}
				//-----------------------------------------------------------------------

				//Score counter and test for game over
				if (GAMEOVER)
				{
					printf("$Game over*\n");
					SCTlimit = 0;
					TXframe.data[0] = score;
					CAN_transmit(TXframe);
					score = 0;
				}
				//-----------------------------------------------------------------------

				//Go to state 0 - "End game"--------------------------------------------
				if((RXframe.id == 0) || (RXframe.id == 13) || (GUIexit)){
					//Exit in game state
					GUIframe.id = 99;
					CAN_transmit(GUIframe); //Frame used for signaling Node 1 that the game is over
					GUImode = false;

					stateCounter = 0;
					state = 0;
				}
				//----------------------------------------------------------------------
				break;
			//-----------------------------------------------------------------------------------------------------------------
			case 0:
				//----------------------
				//END-GAME
				//----------------------

				GUIexit = false;
				GAMEOVER = false;
				GUIframe.id = 94;

				//Reset motor and encoder
				while((stateCounter < 100) && !(stateFlag))
				{
					motorControl(-128);
					encoderReset();
				}
				//Reset servo and state counter
				if(stateCounter > 210)
				{
					OCR3A = 3200;
					stateCounter = 0;
					stateFlag = true;
				}
				if (stateFlag)
				{
					stateFlag = false;
					state = 42;
				}
				break;
			//-----------------------------------------------------------------------------------------------------------------
			default:
				break;
			}
		//--------------------------------------------------------------------------------------------------------------------------------------------------------------------

		//Reset the counter used for sampling the encoder
		if(timeStep > 10) timeStep = 0;
	}
	//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	return 0;
}

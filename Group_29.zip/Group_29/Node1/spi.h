#include "setup.h"
#include "memory.h"
#include "util.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>

#define SS PB4    //Slave select
#define MOSI PB5  //Master out, slave in
#define MISO PB6  //Master in, slave out
#define SCK PB7   //Clock signal

void SPI_init();
uint8_t SPI_read();
void SPI_write(uint8_t cData);
void chipSelect(bool selc);

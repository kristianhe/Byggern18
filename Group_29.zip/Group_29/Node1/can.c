#include "can.h"

bool RXflag = false;

ISR(INT1_vect)
{
  bitModify(MCP_CANINTF, 0x01, 0x00);               //Clear the CANINTF.RXnIF bit when a message is moved into either of the receive buffers
	RXflag = true;
}

void CAN_init()
{
  exInterInit_1();
  SPI_init();
  MCP_reset();                                      //Re-initialize the internal registers

  bitModify(MCP_CANCTRL, MODE_MASK, MODE_CONFIG);

  if ((MCP_read(MCP_CANSTAT) & MODE_MASK) != MODE_CONFIG)   printf("Not config mode\n");
  else                                                      printf("Config mode\n");

  bitModify(MCP_CANINTE, 0x01, 0xff);               //RX0IE: Interrupt when message received in RXB0
  bitModify(MCP_RXB0CTRL, 0x64, 0xfb);              //RXM<1:0>: Turn mask/filters off; receive any message, BUKT: Rollover Enable bit; 0 = Rollover disabled
  bitModify(MCP_CANCTRL, MODE_MASK, MODE_NORMAL);   //Normal mode

  if ((MCP_read(MCP_CANSTAT) & MODE_MASK) != MODE_NORMAL)   printf("Not normal mode\n");
  else                                                      printf("Normal mode\n");

  printf("CAN_init\n");
}

void CAN_transmit(CAN_frame frame)
{
  if (CAN_TX_comp())
  {
    MCP_write(MCP_TXB0SIDH, frame.id >> 3);
    MCP_write(MCP_TXB0SIDL, frame.id << 5);
    MCP_write(MCP_TXB0DLC, (0x0f) & (frame.length)); //Sets the number of data bytes to be transmitted (0 to 8 bytes)

    for(uint8_t i = 0; i < frame.length; i++)
    {
      MCP_write((MCP_TXB0D0 + i), frame.data[i]);
    }

    MCP_RTS(0);                                      //Requesting to send on TXB0 buffer
  }
  else
  {
    printf("TX error!\n");
    printf("Status: %x\n", MCP_read(MCP_EFLG));
  }
}

uint8_t CAN_receive(CAN_frame *RXframe)
{
  if (RXflag)
  {
    RXframe->id = ((MCP_read(MCP_RXB0SIDH) << 3) | (MCP_read(MCP_RXB0SIDL) >> 5));
    RXframe->length = (0x0f) & (MCP_read(MCP_RXB0DLC));

    for(uint8_t i = 0; i < RXframe->length; i++)
    {
      RXframe->data[i] = MCP_read((MCP_RXB0D0 + i));
    }

    RXflag = false;
    bitModify(MCP_CANINTF, 0x01, 0x00);              //clear the CANINTF.RXnIF bit when a message is moved into either of the receive buffers

    return 1;
  }
  //if (MCP_read(MCP_EFLG) != 0) printf("RX error: %x\n", MCP_read(MCP_EFLG));

  return 0;
}

bool CAN_TX_comp()
{
  return !(bool)(test_bit( MCP_read(MCP_TXB0CTRL), 3));
}

void loopbackInit()
{
  bitModify(MCP_CANCTRL, MODE_MASK, MODE_LOOPBACK); //Normal mode
  printf("COM-mode: Loopback\n");
}

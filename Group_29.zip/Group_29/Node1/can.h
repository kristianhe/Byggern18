#include "setup.h"
#include "MCP2515.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>

typedef struct CAN_frame {
  uint8_t id;
  uint8_t length;
  uint8_t data[8];
} CAN_frame;

void CAN_init();
void CAN_transmit(CAN_frame frame);
uint8_t CAN_receive(CAN_frame *RXframe);
bool CAN_TX_comp();
void loopbackInit();

#include "setup.h"

#include <stdio.h>
#include <avr/io.h>

void XMEM_init(void);
int MEM_write(uint16_t ad_start, uint16_t adress, char data);
int MEM_read(uint16_t ad_start, uint16_t adress);
//void SRAM_test();

/*==============================================================================
Solution for the lab in TTK4155 by group 29
- Extensive use of timer functionalities
- No use  util/delay for timing over ~1 ms
- Added watchdog timer
- Added functionalities for talking to a graphical user interface using UART
================================================================================*/
#include "setup.h"
#include "uart.h"
#include "memory.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "oled.h"
#include "oledMeny.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <avr/io.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include <avr/interrupt.h>

//Global boolean control variables
bool RButton = false;
bool JButton = false;

//Global counters
uint8_t DispCounter = 0;
uint8_t JoyCounter = 0;
uint8_t KeyCounter = 0;

joystick_position joyPos;
slider_position sliPos;

//Timer0 overflow interrupt
ISR(TIMER0_OVF_vect){
	DispCounter++;
	JoyCounter++;
	KeyCounter++;
}

//Timer1 overflow interrupt
ISR(TIMER1_OVF_vect){
}

ISR(INT0_vect){
	RButton = true;
}
ISR(INT2_vect){
	JButton = true;
}

void drivers()
{
	exInterInit_0();
	exInterInit_2();
	timer1_init();
	timer0_init();
	watchdogInit();
	XMEM_init();
	UART_init(MYUBRR);
	joystickInit();
	OLED_init();
	menuInit();
	CAN_init();
	//loopbackInit();
}

int main(void)
{
	//Enable global interrupts
	sei();
	drivers();

	uint8_t Pos = 0;
	uint8_t Dir = 4;
	uint8_t state = 0;
	uint8_t GAMEState = 0;

	bool chDir = false;
	bool GaOv = false;
	bool GUI = false;

	joyPos = joystickGetPosition();

	//CAN frame
	CAN_frame SCORE;
	CAN_frame GAME;
	GAME.id = 84;
	GAME.length = 5;
	GAME.data[0] = 1; //yPos
	GAME.data[1] = 2; //xPos
	GAME.data[2] = 3; //xDir
	GAME.data[3] = 4; //RButton
	GAME.data[4] = 5; //sliPosLeft

	printf("Node 1 opt\n");
	_delay_ms(500);

	while(1)
	{
		//--------------------------------------------------------------------------
			//functions that are run continuously
		//----------
		wdt_reset(); //Resetting the Watchdog timer

		//Joystick, sliders and buttons from ADC
		joyPos = joystickGetPosition();
		Dir = joystickGetDirection();
		sliPos = sliderGetPosition();

		//Display texts on OLED
		if (DispCounter > 50)
		{
			printCurrentMenu(Pos);
			DispCounter = 0;
		}

		//Using the pushbutton on the joystick to select different menus using external interrupt (INT2)
		if ((JButton) && (KeyCounter > 100) && !(GaOv) && !(GUI))
		{
			GAMEState = menuSelect(JButton, Pos);
			KeyCounter = 0;
			JButton = false;
		}

		//Increment and decrement position for the display using the joystick
		if ((state == 0) || (state == 2))
		{
			if ((JoyCounter%10) == 0)
			{
				if (Dir == 4) chDir = true;
				if ((Dir == 2) && ((chDir) || (JoyCounter > 50)))
				{
					menuIncrementPosition();
					chDir = false;
					JoyCounter = 0;
				}
				else if ((Dir == 3) && ((chDir) || (JoyCounter > 50)))
				{
					menuDecrementPosition();
					chDir = false;
					JoyCounter = 0;
				}
				Pos = menuGetPosition();
			}
		}
		//--------------------------------------------------------------------------

		//Switch case for all the GAME states; 0 = PRE-GAME, 1 = IN-GAME, 2 = POST-GAME (reset)
		switch (state) {
		//--------------------------------------------------------------------------
			case 0:
			//-----------
			//PRE-GAME
			//-----------
				//Data that are transmitted over the CAN bus
				GAME.id = 42;
				//Transmitting different values for the PID controller used for difficulty
				if (GAMEState == 1) GAME.data[0] = 1;
				else 								GAME.data[0] = 0;
				if (GAMEState == 2) GAME.data[1] = 1;
			 	else 								GAME.data[1] = 0;
				if (GAMEState == 3) GAME.data[2] = 1;
			 	else 								GAME.data[2] = 0;
				if (GAMEState == 4) GAME.data[3] = 1;
			 	else 								GAME.data[3] = 0;

				CAN_transmit(GAME);

				if (GAMEState == 21) 			state = 1; 			//Go to game using multifunction card
				else if (GAMEState == 43) state = 4;  //Go to game using GUI
				break;
		//--------------------------------------------------------------------------
			case 1:
			//-----------
			//IN-GAME
			//-----------
				GAME.id = 69;
				GAME.data[0] = joyPos.x;
				GAME.data[1] = Pos;
				GAME.data[2] = Dir;
				GAME.data[4] = sliPos.right;

				if (RButton) 								//Right button for activating the solenoid using external interrupt (INT1)
				{
					GAME.data[3] = 133; 			//On
					RButton = false;
					printf("On\n");
				}
				else GAME.data[3] = 1;			//Off
				CAN_transmit(GAME);

				if (CAN_receive(&SCORE)) 		//Receiving the score value when game ends
				{
					if(SCORE.id == 13){
						//Displaying the score on the oled
						getScore((int)SCORE.data[0]);
						state = 3;
						GaOv = true;
					}
				}
				else if ((GAMEState == 31) || (GAMEState == 32)) state = 2;
				break;
			//------------------------------------------------------------------------
			case 2:
			//-----------
			//Pause
			//-----------
				GAME.id = 2;
				if (GAMEState == 22) 		 state = 1;
				else if (GAMEState == 1) state = 5;
				break;
			//------------------------------------------------------------------------
			case 3:
			//-----------
			//Game over
			//-----------
				GAME.id = 13;
				CAN_transmit(GAME);
				state = 5;
				break;
			//------------------------------------------------------------------------
			case 4:
				printf("Playing usig GUI\n");
				GUI = true;
				GAMEState = 0;
				Pos = 0;
				GAME.id = 49;
				CAN_transmit(GAME);
				OLED_clearAll();
				state = 10;
				break;
			case 10:
				//wait state
				if (CAN_receive(&GAME))
				{
					if(GAME.id == 99){
							printf("Exit\n");
							GUI = false;
							GAME.id = 42;
							CAN_transmit(GAME);
							state = 5;
					}
				}
				break;
			case 5:
			//-----------
			//POST-GAME
			//-----------
			printf("POST-GAME\n");
				OLED_clearAll(); 						//Clear menu
				OLED_printPageMode(0, 0, "Your coffin is ready");
				GAME.id = 0;
				CAN_transmit(GAME);

				_delay_ms(1500);

				menuInit(); 								//Reset menu
				GAMEState = 0;
				GaOv = false;
				state = 0;
				break;
			//------------------------------------------------------------------------
			default:
			break;
		}
	}

	return 0;
}

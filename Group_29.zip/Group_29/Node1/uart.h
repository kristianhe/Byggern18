#include "setup.h"

#include <stdio.h>
#include <avr/io.h>

extern FILE *uart;

void UART_init(unsigned int baudrate);
int UART_transmit(char c, FILE *f);
unsigned char UART_receive(void);
void UART_flush(void);

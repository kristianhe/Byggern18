#include "oledMeny.h"

menu_page newPage;
menu_page tmp;
char buffer[5];
uint8_t event = 0;
uint8_t menuPos = 0;

static menu_page main_menu;
static menu_page play;
static menu_page options;
static menu_page score;
static menu_page game;
static menu_page GUI;
static menu_page reset;
static menu_page level;
static menu_page sound;

//Graph structure for navigating the menu
static menu_page main_menu = {.id = 1, .rowLenght = 3, .childs = {&play, &options, &score, &main_menu, &main_menu}};
static menu_page play = {.id = 11, .rowLenght = 3, .childs = {&game, &GUI, &main_menu, &main_menu, &main_menu}};
static menu_page GUI = {.id = 42, .rowLenght = 1, .childs = {&main_menu, &main_menu, &main_menu, &main_menu, &main_menu}};
static menu_page game = {.id = 21, .rowLenght = 2, .childs = {&reset, &reset, &reset, &reset, &reset}};
static menu_page reset = {.id = 31, .rowLenght = 2, .childs = {&main_menu, &game, &main_menu, &main_menu, &main_menu}};
static menu_page options = {.id = 12, .rowLenght = 2, .childs = {&level, &main_menu, &main_menu, &main_menu, &main_menu} };
static menu_page level = {.id = 22, .rowLenght = 5, .childs = {&main_menu, &main_menu, &main_menu, &main_menu, &main_menu}};
//static menu_page sound = {.id = 23, .rowLenght = 3, .childs = {&options, &options, &options, &options, &options}};
static menu_page score = {.id = 13, .rowLenght = 2, .childs = {&main_menu, &main_menu, &main_menu, &main_menu, &main_menu}};

//Text data
static char *Mainmenu[3][1] = {{(char *)("Play")}, {(char *)("Options")}, {(char *)("Score")}};                                         //Mainmenu
static char *Play[3][1] = {{(char *)("New game")}, {(char *)("GUI")}, {(char *)("Back")}};                                              //Play
//static char *Options[3][1] = {{(char *)("Difficulty")},{(char *)("Sound")}, {(char *)("Back")}};
static char *Options[2][1] = {{(char *)("Difficulty")}, {(char *)("Back")}};                                                            //Options
static char *Reset[2][1] = {{(char *)("Reset")},{"Resume"}};                                                                            //Score
static char *Diff[5][1] = {{(char *)("Easy")}, {(char *)("Medium")}, {(char *)("Hard")}, {(char *)("Nightmare")}, {(char *)("Back")}};  //In Difficulty
//static char *Sound[3][1] ={{(char *)("On")},{(char *)("Off")},{(char *)("Back")}};                                                    //In Sound


void menuInit()
{
  newPage = main_menu;
  menuPos = 0;
}

uint8_t menuSelect(bool keyPress, uint8_t eventPos)
{
  if(keyPress)
  {
    tmp = *newPage.childs[eventPos];
    if (&tmp != NULL)
    newPage = tmp;

    event = newPage.id + menuPos;
    printf("event %d\n", event);
  }

  return event;
}
void getScore(int score)
{
  itoa(score,buffer,10);
}

void printCurrentMenu(uint8_t rowPos)
{
  OLED_clearAll();
  switch (newPage.id) {
    case 1:
      printMenu(Mainmenu, rowPos, newPage.rowLenght);
      break;
    case 11:
      printMenu(Play, rowPos, newPage.rowLenght);
      break;
    case 12:
      printMenu(Options, rowPos, newPage.rowLenght);
      break;
    case 13:
      OLED_printPageMode(0, 0, "Score:");
      OLED_printPageMode(1, 0, buffer);
      break;
    case 21:
      OLED_printPageMode(1, 8, "Buckel up lads");
      break;
    case 22:
      printMenu(Diff, rowPos, newPage.rowLenght);
      break;
    /*
    case 23:
      for(uint8_t i = 0; i < newPage.rowLenght; i++)
      {
        OLED_printPageMode(0, 0, "Sound:");
        if (i == rowPos)  OLED_printPageMode((i+1), 8, Sound[i][0]);
        else              OLED_printPageMode((i+1), 0, Sound[i][0]);
      }
      break;
    */
    case 31:
      printMenu(Reset, rowPos, newPage.rowLenght);
      break;
    }
}

void printMenu(char *textlist[], uint8_t Position, uint8_t rowLenght)
{
  for(uint8_t i = 0; i < rowLenght; i++)
  {
    if (i == Position)  OLED_printPageMode((i), 8, textlist[i]);
    else                OLED_printPageMode((i), 0, textlist[i]);
  }
}

void menuSetPosition(uint8_t position)
{
  if ((position >= 0) && (position <= newPage.rowLenght)) menuPos = position;
}

void menuIncrementPosition()
{
  if (menuPos < newPage.rowLenght)  menuPos++;
  else                              menuPos = 0;
  menuSetPosition(menuPos);
}

void menuDecrementPosition()
{
  if (menuPos > 0)  menuPos--;
  else              menuPos = newPage.rowLenght;
  menuSetPosition(menuPos);
}

uint8_t menuGetPosition()
{
  uint8_t Pos = menuPos;
  return Pos;
}

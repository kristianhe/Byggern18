#include "uart.h"
#include "setup.h"
#include "memory.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"

#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

uint8_t slidL;
uint8_t slidR;
uint8_t buttonL;
uint8_t buttonR;

uint8_t a ,b;

Joystick_Position joyPos;
Joystick_Direction joyDir;
Slider_Position sliPos;

int main(void){

	DDRB |= (1<<PB0);

	UART_Init(MYUBRR);
	XMEM_Init();

	Joystick_Init();

	printf("Init finished!\n\r");
	blink();
	while(1)
	{

		joyPos = Joystick_getPosition();
		joyDir = Joystick_getDirection();
		sliPos = Slider_getPosition();
		buttonL = Slider_getLeftButton();
		buttonR = Slider_getRightButton();

		printf("x: %d \n", joyPos.x);
		printf("Y: %d \n", joyPos.y);

		printf("Direction: %d \n", joyDir);

		printf("Slider_L: %d \n", sliPos.left);
		printf("Slider_R: %d \n", sliPos.right);

		printf("Button_L: %d \n", buttonL);
		printf("Button_R: %d \n", buttonR);

		printf("----------------\n");
		_delay_ms(1000);
	}
	return 0;
}

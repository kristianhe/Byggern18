#include "setup.h"

#include <stdio.h>
#include <avr/io.h>

int UART_Init(unsigned int baudrate);
int UART_Transmit(char c, FILE *f);
unsigned char UART_Receive(void);
void USART_Flush(void);
//int UART_print(char * tekst);
extern FILE *uart;

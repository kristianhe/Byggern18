#include <stdio.h>

void XMEM_Init(void);

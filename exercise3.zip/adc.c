#include "adc.h"


void ADC_Init()
{
  // DDRE &= ~(1 << PINE0); // For interrupts. Trenger ikke, bruker heller delay
}

uint8_t ADC_Read(uint8_t Channel)
{
  volatile char *dataADC = (char*) adADC;

  if (Channel > 3) return 0;
  *dataADC = 0x04 | Channel;
  //while (test_bit(PINE, PINE0));
  _delay_us(50);
  return *dataADC;
}

/*
 * slider.c
 *
 * Created: 20.09.2018 15.43.13
 *  Author: Simon
 */

#include <avr/io.h>
#include <stdio.h>
#include "setup.h"
#include "slider.h"
#include "adc.h"

void Slider_Init()
{
	ADC_Init();		// Er denne unødvendig? Just in case? Skader det å ha den her?
	DDRB &= ~(1 << DDB1);
	DDRB &= ~(1 << DDB2);
}

Slider_Position Slider_getPosition()
{
	Slider_Position sliPos;
	sliPos.left  = ADC_Read(2);
	sliPos.right = ADC_Read(3);

	return sliPos;
}

int Slider_getLeftButton()
{
	return !(!(PINB & (1 << PINB1)));
}

int Slider_getRightButton()
{
	return !(!(PINB & (1 << PINB2)));
}

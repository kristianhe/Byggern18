#include <avr/io.h>
#include <stdio.h>
#include "setup.h"
#include "joystick.h"
#include "adc.h"

uint8_t joyX_init, joyY_init;


void Joystick_Init()
{
	ADC_Init(); // Unødvendig? Greit å ha i tilfelle?

	DDRB &= ~(1 << DDB2);	// Data Direction B2. ER DETTE RIKTIG?

	Joystick_Calibrate();
}

void Joystick_Calibrate()
{
	joyX_init = ADC_Read(0);		// Leser verdien på ADC'en sin CH1 (Joystick X)
	joyY_init = ADC_Read(1);		// Leser verdien på ADC'en sin CH2 (Joystick Y)
}

Joystick_Position Joystick_getPosition()
{
	// x og y fra 1 - 255
	// x = 1 er helt til venstre, x = 255 er helt til høyre
	// y = 1 er helt nede, y = 255 er helt oppe
	// nøytrale posisjoner er x = 129-131 og y = 126-128
	//
	// OM X HELT TIL HØYRE:   joyPosition.x = (255 - 130) = 125. 125*x = 100 => x = 100/125. Derfor *(100/125)
	// OM X HELT TIL VENSTRE: joyPosition.x = (1 - 130) = -129. (-129)*(100/125) = -103,2

	// OM Y HELT OPPE:
	Joystick_Position joyPosition;				// Struct med x- og y-verdi. Se H-filen
	joyPosition.x = (ADC_Read(0) - joyX_init)*(100/125);
	joyPosition.y = (ADC_Read(1) - joyY_init)*(100/125);

	return joyPosition;
}

Joystick_Direction Joystick_getDirection()
{
	Joystick_Position	joyPos = Joystick_getPosition();
	Joystick_Direction	joyDir;
	int threshold = 45;


	if		(joyPos.x >  threshold)	{	joyDir = RIGHT;		}
	else if (joyPos.x < -threshold) {	joyDir = LEFT;		}
	else if (joyPos.y >  threshold)	{	joyDir = UP;		}
	else if (joyPos.y < -threshold) {	joyDir = DOWN;		}
	else							{	joyDir = NEUTRAL;	}

	return joyDir;
}

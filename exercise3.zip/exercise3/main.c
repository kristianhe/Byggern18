/*
 * FungerendeKode.c
 *
 * Created: 31.08.2018 17.26.17
 *  Author: Simon
 */
#include "uart.h"
#include "setup.h"
#include "memory.h"
#include "util.h"
#include "adc.c"
#include "slider.c"
//#include "joystick.c"

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>


int main(void){

	uint8_t angleX;
	uint8_t angleY;
	uint8_t posY;
	uint8_t posX;
	uint8_t slidL;
	uint8_t slidR;
	uint8_t buttonL;
	uint8_t buttonR;

	//Joystick_Position joyPos;
	//Joystick_Direction joyDir;
	Slider_Position sliPos;

	uint16_t add = 0;
	int value;


	DDRB = 0x01;

	DDRB &= ~(1 << DDB1);	// PB1 koblet til knappVenstre
	DDRB &= ~(1 << DDB2);	// PB2 koblet til knappHøyre

	UART_Init(MYUBRR);	// Fi
	XMEM_Init();
	//Joystick_Init();
	//ADC_Init();

	printf("Init finished!\n\r");
	printf("ssdf4\n");
	blink();
	while(1)
	{
		posY = ADC_Read(0);		// Leser ut fra CH1
		posX = ADC_Read(1);		// CH2
		//joyPos = Joystick_getPosition();

		angleY = Scale(posY, 255, 0, 90, 0);
		angleX = Scale(posX, 255, 0, 90, 0);
		//joyDir = Joystick_getDirection();

		//slidL = ADC_Read(2);	// CH3
		//slidR = ADC_Read(3);	// CH4
		sliPos = Slider_getPosition();

		//buttonL = !(!(PINB & (1 << PINB1)));
		//buttonR = !(!(PINB & (1 << PINB2)));
		buttonL = Slider_getLeftButton();
		buttonR = Slider_getRightButton();


		printf("ADC_Y is: %d \n", posY);
		printf("ADC_X is: %d \n", posX);

		printf("Angle_Y: %d \n", angleY);
		printf("Angle_X: %d \n", angleX);
		//printf("Direction: %d \n", joyDir);

		printf("Slider_L: %d \n", sliPos.left);
		printf("Slider_R: %d \n", sliPos.right);

		printf("Button_L: %d \n", buttonL);
		printf("Button_R: %d \n", buttonR);


		//printf(testADC);
		printf("----------------\n");
		_delay_ms(1000);
		/*
		 value = MEM_read(adADC, 0);

		 printf("ADC: %d \n", value);
		_delay_ms(250);

		add++;
		if (add > 200) add = 0;
		*/
	}
	return 0;
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;          // Serial port

// Node 1: /dev/ttyS0
// Node 2: /dev/ttyACM0

// Every message from the MCUs are expected to start with '$' and end with '#'
// Every message we send to the MCUs starts with a string that explains what type of value we are sending (solenoid, DC-motor, ...)
// S = Solenoid, D = servo, R = DC-motor reference, C = PID controller values

namespace TTK4155___GUI
{
    public partial class Form1 : Form
    {
        bool exit;

        SerialPort sPort1, sPort2;  // Serial ports for node 1 and node 2
        string message1, message2;

        string readbuffer1, readbuffer2;
        char char1, char2;
        int lastValue, threshold;

        public Form1()
        {
            // Initialization at startup
            InitializeComponent();

            exit = false;
            message1 = "";
            message2 = "";
            readbuffer1 = "";
            readbuffer2 = "";
            char1 = '*';
            char2 = '*';
            sPort1 = null;
            sPort2 = null;
            lastValue = 0;
            threshold = 1;
        }

        private void btn_Avslutt_Click(object sender, EventArgs e)
        {
            exit = true;
            if ((sPort1 == null) && (sPort2 == null))
            {
                Application.Exit();
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            // FOR MICROCONTROLLERS ON LINUX
            //sPort1 = new SerialPort("/dev/ttyS0", 9600, Parity.None, 8, StopBits.Two);
            //sPort2 = new SerialPort("/dev/ttyACM0", 9600, Parity.None, 8, StopBits.Two);

            // FOR TESTING WITH "MOTTAKERPROGRAM". USE VIRTUAL COM-PORTS (e.g. with com0com).
            sPort1 = new SerialPort("COM6", 9600, Parity.None, 8, StopBits.Two);
            sPort2 = new SerialPort("COM5", 9600, Parity.None, 8, StopBits.Two);

            try
            {
                sPort1.Open();
                sPort2.Open();
            }
            catch (Exception ex)
            {
                sPort1 = null;
                sPort2 = null;
                MessageBox.Show("Error: " + ex.Message);
            }

            if ((sPort1 != null) && (sPort2 != null))
            {
                if ((sPort1.IsOpen) && (sPort2.IsOpen))
                {
                    btnStart.Enabled = false;
                    btnPID.Enabled = true;
                    trackBarDC.Enabled = true;
                    bwDatainnsamler1.RunWorkerAsync();   // Run background worker (a thread)
                    bwDatainnsamler2.RunWorkerAsync();
                }
            }
        }

        // When the value for the slider changes
        private void trackBarDC_ValueChanged(object sender, EventArgs e)
        {
            // Only updates the slider values if they exceed the threshold
            if ((trackBarDC.Value >= (lastValue + threshold)) || (trackBarDC.Value <= lastValue - threshold))
            {
                try
                {
                    sPort2.Write("$R" + trackBarDC.Value + "#");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                
                tbSlider.Text = trackBarDC.Value.ToString();
                tbSkyt.Text = "";
                lastValue = trackBarDC.Value;
            }
        }

        private void numGrense_ValueChanged(object sender, EventArgs e)
        {
            // Update the threshold to the numeric value chosen in the GUI
            threshold = Convert.ToInt16(numGrense.Value);
        }

        private void btnPID_Click(object sender, EventArgs e)
        {
            bool isInt = true;
            foreach(char c in (tbKp.Text + tbKi.Text + tbKd.Text))
            {
                if (!Char.IsNumber(c))
                {
                    isInt = false;
                    MessageBox.Show("Values in PID-tuning is not valid integers");
                    break;
                }
            }

            if (isInt)
            {
                // Send the chosen PID-values when the "Apply"-button is pushed
                string pidmsg = "$C";
                pidmsg += "P" + Convert.ToInt16(tbKp.Text);
                pidmsg += "I" + Convert.ToInt16(tbKi.Text);
                pidmsg += "D" + Convert.ToInt16(tbKd.Text) + "#";
                try
                {
                    sPort2.Write(pidmsg);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
               
            }
        }

        // When a button is pushed down while the trackbar is in focus
        private void trackBarDC_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Space)    // Checks if the key pushed is spacebar, which will make the solenoid shoot
                {
                    sPort2.Write("$S" + 133 + "#");
                    tbSkyt.Text = "SHOOT!";
                }
                if (e.KeyCode == Keys.A)        // Checks if the key pushed is 'A', which will turn the servo half way left
                {
                    sPort2.Write("$D" + 192 + "#");
                    tbServo.Text = "Left";
                }
                if (e.KeyCode == Keys.S)
                {
                    sPort2.Write("$D" + 127 + "#");
                    tbServo.Text = "Mid";
                }
                else if (e.KeyCode == Keys.D)   // Checks if the key pushed is 'D', which will turn the servo half way right
                {
                    sPort2.Write("$D" + 64 + "#");
                    tbServo.Text = "Right";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // When the GUI solenoid-shoot-button is clicked
        private void btnSkyt_Click(object sender, EventArgs e)
        {
            try
            {
                sPort2.Write("$S" + 133 + "#");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            tbSkyt.Text = "SHOOT!";
        }

        // Thread reading messages from node 1
        private void bwDatainnsamler_DoWork(object sender, DoWorkEventArgs e)
        {
            readbuffer1 = "";
            char1 = '*';

            // Look for the start-sign
            while (char1 != '$')
            {
                try
                {
                    char1 = Convert.ToChar(sPort1.ReadChar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                
            }
            readbuffer1 = "$";

            // The message is received here, until the stop-sign is read
            while (char1 != '#')
            {
                try
                {
                    char1 = Convert.ToChar(sPort1.ReadChar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                
                readbuffer1 += char1;
            }
            message1 = readbuffer1;
        }


        private void bwDatainnsamler_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            txtData.Text = message1;
            if (!exit) bwDatainnsamler1.RunWorkerAsync();   // If we want to continue, run the thread again
            else
            {
                if ((sPort1 != null) || (sPort2 != null))
                {
                    if (sPort1.IsOpen) sPort1.Close();
                    if (sPort2.IsOpen) sPort2.Close();
                }
                Application.Exit();
            }
        }

        // Thread reading messages from node 2
        private void bwDatainnsamler2_DoWork(object sender, DoWorkEventArgs e)
        {
            readbuffer2 = "";
            char2 = '*';

            // Look for the start-sign
            while (char2 != '$')
            {
                try
                {
                    char2 = Convert.ToChar(sPort2.ReadChar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                
            }
            readbuffer2 = "$";

            // The message is received here, until the stop-sign is read
            while (char2 != '#')
            {
                try
                {
                    char2 = Convert.ToChar(sPort2.ReadChar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                
                readbuffer2 += char2;
            }
            message2 = readbuffer2;
        }

        private void bwDatainnsamler2_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (message2.StartsWith("$score")) // Example of a message: $score6#. (-7) to not include the '#' at the end
            {
                tbScore.Text = message2.Substring(6, message2.Length - 7);
            }
            txtData2.Text = message2;
            if (!exit) bwDatainnsamler2.RunWorkerAsync();  // If we want to continue, run the thread again
            else
            {
                if ((sPort2 != null) || (sPort1 != null))
                {
                    if (sPort2.IsOpen) sPort2.Close();
                    if (sPort1.IsOpen) sPort1.Close();
                }
                Application.Exit();
            }
        }
    }
}

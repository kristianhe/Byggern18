
#include "setup.h"
#include "uart.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>


bool Deltime = false;
bool INTflag = false;
/*
Joystick_Position joyPos;
Joystick_Direction joyDir;
Slider_Position sliPos;

ISR(INT0_vect){
	INTflag = true;
}

ISR(TIMER1_OVF_vect){
	Deltime ^= true;
}

bool timerDelay() //interupt-basert delayfunksjon på 500 ms
{
	if(Deltime){
		Deltime = false;
		return true;
	}
	else{return false;}
}
*/

int main(void){
	UART_Init(MYUBRR);
	canInit();
	//loopbackInit();
	CAN_frame TXtest;
	CAN_frame RXtest;

	TXtest.id = 5;
	TXtest.length = 2;
	TXtest.data[0] = 1;
	TXtest.data[1] = 2;

	sei();
	printf("Node 2 opertional\n");
	while(1)
	{
		printf("Recived this from node 1\n");
		_delay_ms(2000);
		RXtest = canRecive();

		TXtest.data[0] = RXtest.data[0];
		TXtest.data[1] = RXtest.data[1];

		printf("Transmit this to node 1\n");
		_delay_ms(2000);
		canTransmit(TXtest);


		printf("-----------------------\n\n");
	}
	return 0;
}

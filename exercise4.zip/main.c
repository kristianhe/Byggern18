#include "setup.h"
#include "uart.h"
#include "memory.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "oled.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

uint8_t slidL;
uint8_t slidR;
uint8_t buttonL;
uint8_t buttonR;

uint8_t a ,b;

Joystick_Position joyPos;
Joystick_Direction joyDir;
Slider_Position sliPos;

int main(void){
	char i = 0;
	DDRB |= (1<<PB0);
	sei();

	UART_Init(MYUBRR);
	XMEM_Init();
	Joystick_Init();
	oled_init();
	//timer1_init();

	blink();
	printf("Init finished!\n\r");
	printf("dfgdf\n");
	while(1)
	{
		/*
		joyPos = Joystick_getPosition();
		joyDir = Joystick_getDirection();
		sliPos = Slider_getPosition();
		buttonL = Slider_getLeftButton();
		buttonR = Slider_getRightButton();

		printf("x: %d \n", joyPos.x);
		printf("Y: %d \n", joyPos.y);

		printf("Direction: %d \n", joyDir);

		printf("Slider_L: %d \n", sliPos.left);
		printf("Slider_R: %d \n", sliPos.right);

		printf("Button_L: %d \n", buttonL);
		printf("Button_R: %d \n", buttonR);

		printf("----------------\n");

		//oled_pos(1,1);
		*/
		/*
		if(i > 128){
			i = 0;
		}
		*/

		//oled_print_horizontal_mode(6,0,(char *)("Det er fullbrakt1"));
		oled_print_page_mode(6,0,(char *)("Det er fullbrakt"));
		_delay_ms(10);
		oled_clear_page(0);
		_delay_ms(10);

		/*i++;
		_delay_ms(50);
		oled_clear_page(0);
		_delay_ms(50);
		*/
	}
	return 0;
}

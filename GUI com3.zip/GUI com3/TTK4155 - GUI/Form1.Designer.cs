﻿namespace TTK4155___GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnStart = new System.Windows.Forms.Button();
            this.bwDatainnsamler2 = new System.ComponentModel.BackgroundWorker();
            this.trackBarDC = new System.Windows.Forms.TrackBar();
            this.tbSlider = new System.Windows.Forms.TextBox();
            this.tbSkyt = new System.Windows.Forms.TextBox();
            this.tbKp = new System.Windows.Forms.TextBox();
            this.tbKi = new System.Windows.Forms.TextBox();
            this.tbKd = new System.Windows.Forms.TextBox();
            this.lblKp = new System.Windows.Forms.Label();
            this.lblKi = new System.Windows.Forms.Label();
            this.lblKd = new System.Windows.Forms.Label();
            this.gbPID = new System.Windows.Forms.GroupBox();
            this.btnPID = new System.Windows.Forms.Button();
            this.pbLoose = new System.Windows.Forms.PictureBox();
            this.lblSliderValue = new System.Windows.Forms.Label();
            this.lblSkyt = new System.Windows.Forms.Label();
            this.lblServo = new System.Windows.Forms.Label();
            this.tbServo = new System.Windows.Forms.TextBox();
            this.lblScore = new System.Windows.Forms.Label();
            this.tbScore = new System.Windows.Forms.TextBox();
            this.numGrense = new System.Windows.Forms.NumericUpDown();
            this.lblGrense = new System.Windows.Forms.Label();
            this.lblSlider = new System.Windows.Forms.Label();
            this.txtData2 = new System.Windows.Forms.TextBox();
            this.gbNode2 = new System.Windows.Forms.GroupBox();
            this.lblCom2 = new System.Windows.Forms.Label();
            this.txtCom2 = new System.Windows.Forms.TextBox();
            this.timerBlink = new System.Windows.Forms.Timer(this.components);
            this.timerSong = new System.Windows.Forms.Timer(this.components);
            this.timerScore = new System.Windows.Forms.Timer(this.components);
            this.btnTap = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarDC)).BeginInit();
            this.gbPID.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLoose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGrense)).BeginInit();
            this.gbNode2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStart.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(17, 481);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(109, 60);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start serial com";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // bwDatainnsamler2
            // 
            this.bwDatainnsamler2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bwDatainnsamler2_DoWork);
            this.bwDatainnsamler2.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bwDatainnsamler2_RunWorkerCompleted);
            // 
            // trackBarDC
            // 
            this.trackBarDC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.trackBarDC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.trackBarDC.Enabled = false;
            this.trackBarDC.Location = new System.Drawing.Point(17, 317);
            this.trackBarDC.Maximum = 255;
            this.trackBarDC.Name = "trackBarDC";
            this.trackBarDC.Size = new System.Drawing.Size(766, 56);
            this.trackBarDC.SmallChange = 17;
            this.trackBarDC.TabIndex = 8;
            this.trackBarDC.TickFrequency = 5;
            this.trackBarDC.Value = 127;
            this.trackBarDC.ValueChanged += new System.EventHandler(this.trackBarDC_ValueChanged);
            this.trackBarDC.KeyUp += new System.Windows.Forms.KeyEventHandler(this.trackBarDC_KeyUp);
            // 
            // tbSlider
            // 
            this.tbSlider.Location = new System.Drawing.Point(12, 36);
            this.tbSlider.Name = "tbSlider";
            this.tbSlider.ReadOnly = true;
            this.tbSlider.Size = new System.Drawing.Size(100, 27);
            this.tbSlider.TabIndex = 9;
            this.tbSlider.Text = "127";
            // 
            // tbSkyt
            // 
            this.tbSkyt.Location = new System.Drawing.Point(122, 36);
            this.tbSkyt.Name = "tbSkyt";
            this.tbSkyt.ReadOnly = true;
            this.tbSkyt.Size = new System.Drawing.Size(100, 27);
            this.tbSkyt.TabIndex = 10;
            // 
            // tbKp
            // 
            this.tbKp.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKp.Location = new System.Drawing.Point(65, 41);
            this.tbKp.MaxLength = 1;
            this.tbKp.Name = "tbKp";
            this.tbKp.Size = new System.Drawing.Size(100, 27);
            this.tbKp.TabIndex = 11;
            this.tbKp.Text = "1";
            this.tbKp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbKi
            // 
            this.tbKi.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKi.Location = new System.Drawing.Point(65, 80);
            this.tbKi.MaxLength = 1;
            this.tbKi.Name = "tbKi";
            this.tbKi.Size = new System.Drawing.Size(100, 27);
            this.tbKi.TabIndex = 12;
            this.tbKi.Text = "0";
            this.tbKi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbKd
            // 
            this.tbKd.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKd.Location = new System.Drawing.Point(65, 119);
            this.tbKd.MaxLength = 1;
            this.tbKd.Name = "tbKd";
            this.tbKd.Size = new System.Drawing.Size(100, 27);
            this.tbKd.TabIndex = 13;
            this.tbKd.Text = "2";
            this.tbKd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblKp
            // 
            this.lblKp.AutoSize = true;
            this.lblKp.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKp.Location = new System.Drawing.Point(24, 42);
            this.lblKp.Name = "lblKp";
            this.lblKp.Size = new System.Drawing.Size(30, 20);
            this.lblKp.TabIndex = 14;
            this.lblKp.Text = "Kp:";
            // 
            // lblKi
            // 
            this.lblKi.AutoSize = true;
            this.lblKi.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKi.Location = new System.Drawing.Point(29, 83);
            this.lblKi.Name = "lblKi";
            this.lblKi.Size = new System.Drawing.Size(25, 20);
            this.lblKi.TabIndex = 15;
            this.lblKi.Text = "Ki:";
            // 
            // lblKd
            // 
            this.lblKd.AutoSize = true;
            this.lblKd.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKd.Location = new System.Drawing.Point(24, 122);
            this.lblKd.Name = "lblKd";
            this.lblKd.Size = new System.Drawing.Size(30, 20);
            this.lblKd.TabIndex = 16;
            this.lblKd.Text = "Kd:";
            // 
            // gbPID
            // 
            this.gbPID.Controls.Add(this.btnPID);
            this.gbPID.Controls.Add(this.tbKd);
            this.gbPID.Controls.Add(this.tbKp);
            this.gbPID.Controls.Add(this.lblKd);
            this.gbPID.Controls.Add(this.tbKi);
            this.gbPID.Controls.Add(this.lblKi);
            this.gbPID.Controls.Add(this.lblKp);
            this.gbPID.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbPID.Location = new System.Drawing.Point(795, 307);
            this.gbPID.Name = "gbPID";
            this.gbPID.Size = new System.Drawing.Size(210, 234);
            this.gbPID.TabIndex = 18;
            this.gbPID.TabStop = false;
            this.gbPID.Text = "Clint Eastwood Online Tuning";
            // 
            // btnPID
            // 
            this.btnPID.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPID.Enabled = false;
            this.btnPID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPID.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPID.Location = new System.Drawing.Point(65, 165);
            this.btnPID.Name = "btnPID";
            this.btnPID.Size = new System.Drawing.Size(100, 62);
            this.btnPID.TabIndex = 17;
            this.btnPID.Text = "Do you feel lucky";
            this.btnPID.UseVisualStyleBackColor = false;
            this.btnPID.Click += new System.EventHandler(this.btnPID_Click);
            // 
            // pbLoose
            // 
            this.pbLoose.Image = global::TTK4155___GUI.Properties.Resources.hehe;
            this.pbLoose.Location = new System.Drawing.Point(-2, -6);
            this.pbLoose.Name = "pbLoose";
            this.pbLoose.Size = new System.Drawing.Size(1022, 566);
            this.pbLoose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLoose.TabIndex = 32;
            this.pbLoose.TabStop = false;
            this.pbLoose.Click += new System.EventHandler(this.pbLoose_Click);
            // 
            // lblSliderValue
            // 
            this.lblSliderValue.AutoSize = true;
            this.lblSliderValue.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSliderValue.Location = new System.Drawing.Point(9, 11);
            this.lblSliderValue.Name = "lblSliderValue";
            this.lblSliderValue.Size = new System.Drawing.Size(90, 20);
            this.lblSliderValue.TabIndex = 20;
            this.lblSliderValue.Text = "Slider value:";
            // 
            // lblSkyt
            // 
            this.lblSkyt.AutoSize = true;
            this.lblSkyt.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSkyt.Location = new System.Drawing.Point(119, 11);
            this.lblSkyt.Name = "lblSkyt";
            this.lblSkyt.Size = new System.Drawing.Size(72, 20);
            this.lblSkyt.TabIndex = 21;
            this.lblSkyt.Text = "Solenoid:";
            // 
            // lblServo
            // 
            this.lblServo.AutoSize = true;
            this.lblServo.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServo.Location = new System.Drawing.Point(229, 11);
            this.lblServo.Name = "lblServo";
            this.lblServo.Size = new System.Drawing.Size(49, 20);
            this.lblServo.TabIndex = 23;
            this.lblServo.Text = "Servo:";
            // 
            // tbServo
            // 
            this.tbServo.Location = new System.Drawing.Point(232, 36);
            this.tbServo.Name = "tbServo";
            this.tbServo.ReadOnly = true;
            this.tbServo.Size = new System.Drawing.Size(100, 27);
            this.tbServo.TabIndex = 22;
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.Location = new System.Drawing.Point(907, 10);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(49, 20);
            this.lblScore.TabIndex = 25;
            this.lblScore.Text = "Score:";
            // 
            // tbScore
            // 
            this.tbScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbScore.Location = new System.Drawing.Point(874, 36);
            this.tbScore.Multiline = true;
            this.tbScore.Name = "tbScore";
            this.tbScore.ReadOnly = true;
            this.tbScore.Size = new System.Drawing.Size(124, 56);
            this.tbScore.TabIndex = 24;
            this.tbScore.Text = "0";
            // 
            // numGrense
            // 
            this.numGrense.Location = new System.Drawing.Point(342, 36);
            this.numGrense.Maximum = new decimal(new int[] {
            51,
            0,
            0,
            0});
            this.numGrense.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numGrense.Name = "numGrense";
            this.numGrense.ReadOnly = true;
            this.numGrense.Size = new System.Drawing.Size(100, 27);
            this.numGrense.TabIndex = 26;
            this.numGrense.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numGrense.ValueChanged += new System.EventHandler(this.numGrense_ValueChanged);
            // 
            // lblGrense
            // 
            this.lblGrense.AutoSize = true;
            this.lblGrense.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrense.Location = new System.Drawing.Point(338, 11);
            this.lblGrense.Name = "lblGrense";
            this.lblGrense.Size = new System.Drawing.Size(118, 20);
            this.lblGrense.TabIndex = 27;
            this.lblGrense.Text = "Slider threshold:";
            // 
            // lblSlider
            // 
            this.lblSlider.AutoSize = true;
            this.lblSlider.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSlider.Location = new System.Drawing.Point(345, 291);
            this.lblSlider.Name = "lblSlider";
            this.lblSlider.Size = new System.Drawing.Size(107, 20);
            this.lblSlider.TabIndex = 30;
            this.lblSlider.Text = "Position slider:";
            // 
            // txtData2
            // 
            this.txtData2.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData2.Location = new System.Drawing.Point(6, 32);
            this.txtData2.Name = "txtData2";
            this.txtData2.ReadOnly = true;
            this.txtData2.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtData2.Size = new System.Drawing.Size(370, 27);
            this.txtData2.TabIndex = 2;
            this.txtData2.Text = "Node 2 ...";
            this.txtData2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gbNode2
            // 
            this.gbNode2.BackColor = System.Drawing.SystemColors.Control;
            this.gbNode2.Controls.Add(this.txtData2);
            this.gbNode2.Controls.Add(this.lblCom2);
            this.gbNode2.Controls.Add(this.txtCom2);
            this.gbNode2.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbNode2.Location = new System.Drawing.Point(407, 395);
            this.gbNode2.Name = "gbNode2";
            this.gbNode2.Size = new System.Drawing.Size(382, 146);
            this.gbNode2.TabIndex = 6;
            this.gbNode2.TabStop = false;
            this.gbNode2.Text = "Node 2";
            // 
            // lblCom2
            // 
            this.lblCom2.AutoSize = true;
            this.lblCom2.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCom2.Location = new System.Drawing.Point(2, 66);
            this.lblCom2.Name = "lblCom2";
            this.lblCom2.Size = new System.Drawing.Size(59, 20);
            this.lblCom2.TabIndex = 4;
            this.lblCom2.Text = "COM #:";
            // 
            // txtCom2
            // 
            this.txtCom2.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCom2.Location = new System.Drawing.Point(6, 95);
            this.txtCom2.Name = "txtCom2";
            this.txtCom2.ReadOnly = true;
            this.txtCom2.Size = new System.Drawing.Size(139, 27);
            this.txtCom2.TabIndex = 3;
            this.txtCom2.Text = "COM3";
            this.txtCom2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timerScore
            // 
            this.timerScore.Interval = 1000;
            // 
            // btnTap
            // 
            this.btnTap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTap.Location = new System.Drawing.Point(292, 481);
            this.btnTap.Name = "btnTap";
            this.btnTap.Size = new System.Drawing.Size(109, 60);
            this.btnTap.TabIndex = 31;
            this.btnTap.Text = "End my misery";
            this.btnTap.UseVisualStyleBackColor = true;
            this.btnTap.Click += new System.EventHandler(this.btnTap_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::TTK4155___GUI.Properties.Resources.MV5BMTMxMDM1OTQxM15BMl5BanBnXkFtZTcwNDc0Mzg4Mw____V1_;
            this.ClientSize = new System.Drawing.Size(1015, 553);
            this.Controls.Add(this.pbLoose);
            this.Controls.Add(this.btnTap);
            this.Controls.Add(this.lblSlider);
            this.Controls.Add(this.lblGrense);
            this.Controls.Add(this.numGrense);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.tbScore);
            this.Controls.Add(this.lblServo);
            this.Controls.Add(this.tbServo);
            this.Controls.Add(this.lblSkyt);
            this.Controls.Add(this.lblSliderValue);
            this.Controls.Add(this.gbPID);
            this.Controls.Add(this.tbSkyt);
            this.Controls.Add(this.tbSlider);
            this.Controls.Add(this.trackBarDC);
            this.Controls.Add(this.gbNode2);
            this.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "TTK4155 - GUI";
            ((System.ComponentModel.ISupportInitialize)(this.trackBarDC)).EndInit();
            this.gbPID.ResumeLayout(false);
            this.gbPID.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLoose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGrense)).EndInit();
            this.gbNode2.ResumeLayout(false);
            this.gbNode2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnStart;
        private System.ComponentModel.BackgroundWorker bwDatainnsamler2;
        private System.Windows.Forms.TrackBar trackBarDC;
        private System.Windows.Forms.TextBox tbSlider;
        private System.Windows.Forms.TextBox tbSkyt;
        private System.Windows.Forms.TextBox tbKp;
        private System.Windows.Forms.TextBox tbKi;
        private System.Windows.Forms.TextBox tbKd;
        private System.Windows.Forms.Label lblKp;
        private System.Windows.Forms.Label lblKi;
        private System.Windows.Forms.Label lblKd;
        private System.Windows.Forms.GroupBox gbPID;
        private System.Windows.Forms.Button btnPID;
        private System.Windows.Forms.Label lblSliderValue;
        private System.Windows.Forms.Label lblSkyt;
        private System.Windows.Forms.Label lblServo;
        private System.Windows.Forms.TextBox tbServo;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.TextBox tbScore;
        private System.Windows.Forms.NumericUpDown numGrense;
        private System.Windows.Forms.Label lblGrense;
        private System.Windows.Forms.Label lblSlider;
        private System.Windows.Forms.TextBox txtData2;
        private System.Windows.Forms.GroupBox gbNode2;
        private System.Windows.Forms.Label lblCom2;
        private System.Windows.Forms.TextBox txtCom2;
        private System.Windows.Forms.Timer timerBlink;
        private System.Windows.Forms.Timer timerSong;
        private System.Windows.Forms.Timer timerScore;
        private System.Windows.Forms.Button btnTap;
        private System.Windows.Forms.PictureBox pbLoose;
    }
}


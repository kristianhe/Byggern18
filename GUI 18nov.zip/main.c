
#include "setup.h"
#include "uart.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"
#include "timer.h"
#include "Motor_driver.h"
#include "pid.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>     /* atoi */
#include <string.h>		/* strchr */
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

// PI
#define K_P		1
#define K_I 	0
#define K_D 	2
#define TIME_INTERVAL 157
struct PID_DATA pidData;

bool Deltime = false;
bool INTflag = false;

//Global counters
uint8_t trigCounter = 0;
uint8_t timeStep = 0;
uint8_t startupCounter = 0;

//Timer0 overflow interrupt
ISR(TIMER0_OVF_vect){
	trigCounter++;
	timeStep++;
	startupCounter++;
}

//Timer1 overflow interrupt
ISR(TIMER1_OVF_vect){
}

//Initialize the drivers
void drivers(){
	UART_Init(MYUBRR);
	PWM_init();
	timer0_init();
	timer1_init();
	canInit();
	IR_Init();
	MotorInit();
	pid_Init(K_P, K_I, K_D, &pidData);
}

int main(void)
{
	DDRE |= (1<<PE4);

	drivers();
	OCR3A = 3200;

	//Inputs and Outputs
	uint8_t servoVal = 0;
	uint8_t joyPos_x = 0;
	uint8_t dirVal = 0;
	uint8_t solenoid = 0;
	uint8_t sliderPos = 0;
	uint8_t IR_value = 255;

	//For PID controller
	uint16_t enc = 0;
	int motorInput = 0;
	uint16_t tmpEnc1 = 0;
	uint16_t tmpEnc2 = 0;
	int deltaEnc = 0;

	//Boolean control variables
	bool startFlag = false;
	bool trigFlag = false;
	bool trigCountFlag = false;

	//For state machine
	bool oddFlag = true;
	bool evenFlag = false;
	bool calcDelta = false;
	bool pidFlag = false;

	CAN_frame RXtest;
	RXtest.id = 0;
	RXtest.length = 5;
	RXtest.data[0] = 1;   //x pos
	RXtest.data[1] = 2;   //y pos
	RXtest.data[2] = 3; 	//x dir
	RXtest.data[3] = 4; 	//button
	RXtest.data[4] = 5; 	//sliPosLeft

	sei();

	//Reseting the position for the DC-motor and encoder
	while((startupCounter < 80) && !(startFlag)){
		PORTH |= (1 << DIR);
		DAC_Write(128);
	}
	Encoder_Reset();

	printf("Node 2 opertional\n");
	
	
	// TESTLOGIKK FOR STYRING VIA GUI
	char guidata[15];
	bool endMsgFlag = false;
	servoVal = 127;
	solenoid = 0;
	sliderPos = 127;
	
	
	while(1)
	{
		MotorContrl(motorInput);
		enc = Scale16(EncoderRead(), 10000, 200, 255, 0);
		OCR3A = Scale(servoVal, 255,0, 4600, 1800);
		IR_value = IR_Read_withFilter();
		
		
		while (UART_Receive() != '$');
		guidata[0] = "$";
		uint8_t l = 1;
		while (!endMsgFlag)
		{
			char inputChar = (char)UART_Receive();
			
			if (inputChar == '#')
			{
				endMsgFlag = true;
			}
			guidata[l++] = inputChar;	
		}

		char temp[15];
		
		for (uint8_t i = 0; i < (l - 3); i++)
		{
			temp[i] = guidata[i + 2];
		}
		
		//int guiValue = atoi(temp);
		
		if (guidata[1] == 'S')		// Solenoid
		{
			solenoid = atoi(temp);
		}
		else if (guidata[1] == 'D')	// Servo
		{
			servoVal = atoi(temp);
		}
		else if (guidata[1] == 'R')	// DC-motor referanse (slider)
		{
			sliderPos = atoi(temp);
		}
		else if (guidata[1] == 'C') // PID-verdier
		{
			
			//ALTERNATIV:							// $CP5I6D7#   length = 9			$CP90I50D1#		length = 11
			int posP = strcspn(guidata, "P");		//			   posP = 2								posP = 2
			int posI = strcspn(guidata, "I");		//			   posI = 4								posI = 5
			int posD = strcspn(guidata, "D");		//			   posD = 6								posD = 8
			
			char tempP[15];
			char tempI[15];
			char tempD[15];
			
			int j = 0;
			for (uint8_t i = (posP + 1); i < posI; i++)
			{
				tempP[j++] = guidata[i];
			}
			j = 0;
			for (uint8_t i = (posI + 1); i < posD; i++)
			{
				tempI[j++] = guidata[i];
			}
			j = 0;
			for (uint8_t i = (posD + 1); i < (l - 1); i++)
			{
				
				tempD[j++] = guidata[i];
			}
			
			int16_t KP = atoi(tempP);
			int16_t KI = atoi(tempI);
			int16_t KD = atoi(tempD);
			
			pid_ChangeControllerValues(KP, KI, KD, &pidData);
			
			
			/*
			// Gets the PID-values from the string guidata.
			
													// $CP5I6D7#   length = 9			$Cp90i50d1#		length = 11
			char fromKp[15] = strchr(guidata, 'P');	// P5I6D7#	   length = 7			p90i50d1#		length = 9
			char fromKi[15] = strchr(guidata, 'I');	// I6D7#	   length = 5			i50d1#			length = 6
			char fromKd[15] = strchr(guidata, 'D');	// D7#		   length = 3			d1#				length = 3
			
			
			char tempP[15];
			char tempI[15];
			char tempD[15];
			
			int j = 0;
			for (uint8_t i = (l - strlen(fromKp) + 1); i < (l - strlen(fromKi)); i++)
			{
				tempP[j++] = guidata[i];
			}
			j = 0;
			for (uint8_t i = (l - strlen(fromKi) + 1); i < (l - strlen(fromKd)); i++)
			{
				tempI[j++] = guidata[i];
			}
			j = 0;
			for (uint8_t i = (l - strlen(fromKd) + 1); i < (l - 1); i++)
			{
				
				tempD[j++] = guidata[i];
			}
			
			int16_t KP = atoi(tempP);
			int16_t KI = atoi(tempI);
			int16_t KD = atoi(tempD);
			
			pid_ChangeControllerValues(KP, KI, KD, &pidData);
			*/
			
		}
		
		
		
		
		
		
		//State machine ---------------------------------------
		if (((timeStep%2) == 0) && (oddFlag) && !(evenFlag)){ //Previous encoder value, sample at odd numbers of the counter value
			tmpEnc1 = enc;
			oddFlag = false;
			evenFlag = true;
		}
		else if (((timeStep%2) != 0) && (evenFlag) && !(oddFlag)){ //current encoder value, sample at even numbers of the counter value
			tmpEnc2 = enc;
			evenFlag = false;
			calcDelta = true;
		}
		if (calcDelta){
			deltaEnc = (int)(tmpEnc2 - tmpEnc1);
			calcDelta = false;
			pidFlag = true;
		}
		if (pidFlag){
			motorInput = pid_Controller(sliderPos, enc, timeStep, deltaEnc, &pidData);
			pidFlag = false;
			oddFlag = true;
		}
		//--------------------------------------------------------
		
		
		
		// Logic for solenoid trigering--------------------------
		if (solenoid == 133) trigFlag = true;
		if (trigFlag){
			PORTE |= (1<<PE4);
			//printf("jalla \n");
			trigFlag = false;
			trigCountFlag = true;
			trigCounter = 0;
		}
		if ((trigCountFlag) && (trigCounter > 10)){
			PORTE &= ~(1<<PE4);
			//printf("not jalla \n");
			trigCountFlag = false;
			trigCounter = 0;
		}
		//--------------------------------------------------------
		if(timeStep > 10)
		{
			timeStep = 0; //reseting the counter
		}
		
	}	// end While

	
	return 0;		

}	// end int Main

#include "setup.h"
#include "memory.h"
#include "util.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define SS PB4 //slave select
#define MOSI PB5 //Master out, slave in
#define MISO PB6 //Master in, slave out
#define SCK PB7 //clock signal

void spi_init();
uint8_t spiRead();
void spiWrite(uint8_t cData);
void chipSelect(bool selc);

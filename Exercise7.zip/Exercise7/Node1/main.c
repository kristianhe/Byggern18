
#include "setup.h"
#include "uart.h"
#include "memory.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "oled.h"
#include "oledMeny.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

bool Deltime = false;
bool flagMenu = false;
bool Button = false;

uint8_t slidL;
uint8_t slidR;
uint8_t buttonL;
uint8_t buttonR;
uint8_t counter = 0;
uint16_t tellerMenu = 0;

uint8_t Rvalue = 3;
char Wvalue = 42;

Joystick_Position joyPos;
Joystick_Direction joyDir;
Slider_Position sliPos;

ISR(TIMER1_OVF_vect){
	Deltime ^= true;
}
ISR(INT0_vect){
	Button = true;
}
bool timerDelay() //interupt-basert delayfunksjon på 500 ms
{
	if(Deltime){
		Deltime = false;
		return true;
	}
	else{return false;}
}

int main(void){
	DDRB |= (1<<PB0);

	exInterInit_0();
	timer1_init();
	XMEM_Init();
	UART_Init(MYUBRR);

	//SRAM_test();

	Joystick_Init();
	oled_init();
	menuInit();

	canInit();
	//loopbackInit();

	CAN_frame TXtest;
	CAN_frame RXtest;

	TXtest.id = 5;
	TXtest.length = 2;

	TXtest.data[0] = 2;
	TXtest.data[1] = 3;
	TXtest.data[2] = 203;
	TXtest.data[3] = 204;

	printf("Node 1 opertional\n");
	_delay_ms(500);
	sei();
	while(1)
	{
		joyPos = Joystick_getPosition();
		TXtest.data[0] = joyPos.x;
		TXtest.data[1] = joyPos.y;
		canTransmit(TXtest);
		printf("Joy.x = %d\n", joyPos.x);
		printf("Joy.y = %d\n", joyPos.y);

		RXtest = canRecive();
		//printf("-------------------------------\n\n");
		_delay_ms(200);
	}
	return 0;
}

/*
joyPos = Joystick_getPosition();
joyDir = Joystick_getDirection();
sliPos = Slider_getPosition();
buttonL = Slider_getLeftButton();
buttonR = Slider_getRightButton();
*/

#include "MCP2515.h"

uint8_t mcpRead(uint8_t addr) //read Instruction
{
  uint8_t Rdata;

  chipSelect(true); //lowering CS
  spiWrite(MCP_READ); // READ-Instruction sent to MCP2515
  spiWrite(addr); //8-bit addresses
  Rdata = spiRead();
  chipSelect(false); //terminate read instruction - pulling CS high

  return Rdata;
}

void mcpWrite(uint8_t addr, uint8_t data)
{
  chipSelect(true); //lowering CS

  spiWrite(MCP_WRITE); // READ-Instruction sent to MCP2515
  spiWrite(addr); //8-bit addresses
  spiWrite(data); //1-byte addresses

  chipSelect(false); //terminate write instruction - pulling CS high
}

void mcpRTS(uint8_t TXbuffer)
{
  chipSelect(true); //lowering CS

  if(TXbuffer == 0)       spiWrite(MCP_RTS_TX0);
  else if (TXbuffer == 1) spiWrite(MCP_RTS_TX1);
  else if (TXbuffer == 2) spiWrite(MCP_RTS_TX2);

  chipSelect(false);
}

void bitModify(uint8_t addr, uint8_t mask, uint8_t DataByte)
{
  chipSelect(true); //lowering CS

  spiWrite(MCP_BITMOD); // BIT MODIFY-Instruction sent to MCP2515
  spiWrite(addr); //8-bit addresses
  spiWrite(mask); //mask byte
  spiWrite(DataByte); //data byte

  chipSelect(false);
}

void mcpReset()
{
  chipSelect(true); //lowering CS
  spiWrite(MCP_RESET);
  chipSelect(false);
}

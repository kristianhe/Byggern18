#include "setup.h"
#include "util.h"
#include "MCP2515.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

typedef struct CAN_frame CAN_frame;
struct CAN_frame
{
  uint8_t   id;
  uint8_t   length;
  uint8_t   data[8];
};

void canInit();
void canTransmit(CAN_frame frame);
uint8_t canRecive(CAN_frame * RXframe);
bool canTXcomp();
void loopbackInit();
//SIDH  >> 3
//SIDL << 5


#include "setup.h"
#include "uart.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"
#include "timer.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>


bool Deltime = false;
bool INTflag = false;
/*
Joystick_Position joyPos;
Joystick_Direction joyDir;
Slider_Position sliPos;

ISR(INT0_vect){
	INTflag = true;
}

ISR(TIMER1_OVF_vect){
	Deltime ^= true;
}

bool timerDelay() //interupt-basert delayfunksjon på 500 ms
{
	if(Deltime){
		Deltime = false;
		return true;
	}
	else{return false;}
}
*/

int main(void){
	int value = 0;

	UART_Init(MYUBRR);
	PWM_init();
	canInit();
	//loopbackInit();
	CAN_frame TXtest;
	CAN_frame RXtest;

	TXtest.id = 8;
	TXtest.length = 2;
	TXtest.data[0] = 1;
	TXtest.data[1] = 2;

	sei();
	printf("Node 2 opertional\n");
	while(1)
	{
		RXtest = canRecive();

		TXtest.data[0] = RXtest.data[0];
		TXtest.data[1] = RXtest.data[1];
		canTransmit(TXtest);

		value = Scale(TXtest.data[0], 255,0, 100, -100);
		printf("Scaler: %d \n", TXtest.data[0]);

		OCR3A = Scale(value, 100,-100, 2600, 480);
		printf("Scaler: %d \n", OCR3A);
		printf("-----------------------\n\n");
		_delay_ms(200);
	}
	return 0;
}

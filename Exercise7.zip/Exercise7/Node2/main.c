
#include "setup.h"
#include "uart.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"
#include "timer.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>


bool Deltime = false;
bool INTflag = false;
/*
Joystick_Position joyPos;
Joystick_Direction joyDir;
Slider_Position sliPos;

ISR(INT0_vect){
	INTflag = true;
}

ISR(TIMER1_OVF_vect){
	Deltime ^= true;
}

bool timerDelay() //interupt-basert delayfunksjon på 500 ms
{
	if(Deltime){
		Deltime = false;
		return true;
	}
	else{return false;}
}
*/

int main(void)
{
	uint8_t value = 0;
	uint8_t score = 0;

	UART_Init(MYUBRR);
	PWM_init();
	canInit();
	IR_Init();
	//loopbackInit();
	CAN_frame RXtest;

	RXtest.id = 0;
	RXtest.length = 0;
	RXtest.data[0] = 0;
	RXtest.data[1] = 0;

	sei();
	printf("Node 2 opertional\n");
	while(1)
	{
		if (canRecive(&RXtest))
		{
			value = RXtest.data[0];
		}

		OCR3A = Scale(value, 255,0, 4600, 1800);
		_delay_ms(200);
		uint8_t IR_value = IR_Read_withFilter();
		printf("IR_filtered: %d \n", IR_value);
		if (IR_value < 5)
		{
			score++;
			printf("Score %d \n", score);
			_delay_ms(500);
		}
	}

	return 0;
}

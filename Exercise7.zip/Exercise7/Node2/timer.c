#include "timer.h"

void PWM_init()
{
  //Make pin PE3 as output
  DDRE |= (1<<PE3);
  //Initialize timer3 in Fast PWM mode (non-inverting)
  TCCR3A |= (1<<WGM31) | (1<<COM3A1) | (0<<COM3A0);
  TCCR3B |= (1<<WGM33) | (1<<WGM32) | (1<<CS31);
  //Set TOP count
  ICR3 = 39999;
}

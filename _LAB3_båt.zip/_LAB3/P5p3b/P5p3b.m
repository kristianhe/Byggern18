clear all
s = tf('s');

Tf = 8.39;
Kpd = 0.77;
K = 0.16;
T = 72.63;
Td = T;

Hpd = Kpd*((1 + Td*s)/(1 + Tf*s));
Hship = K/(Td*s^2 + s);
H0 = Hpd*Hship;

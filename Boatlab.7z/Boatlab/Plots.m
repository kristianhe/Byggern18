figure(1)
plot(x(1,1:20000),x(2,1:20000),y(1,1:20000),y(2,1:20000))
figure(2)
plot(north_east(2,1:20000),north_east(3,1:20000));
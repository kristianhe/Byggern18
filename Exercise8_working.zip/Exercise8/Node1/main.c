
#include "setup.h"
#include "uart.h"
#include "memory.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "oled.h"
#include "oledMeny.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

bool Deltime0 = false;
bool Deltime1 = false;
bool flagMenu = false;
bool Button = false;

uint8_t slidL;
uint8_t slidR;
uint8_t buttonL;
uint8_t buttonR;
uint16_t counter = 0;
uint16_t counter2 = 0;
uint16_t tellerMenu = 0;

Joystick_Position joyPos;
Joystick_Direction joyDir;
Slider_Position sliPos;

ISR(TIMER0_OVF_vect){
	counter++;
	counter2++;
}

ISR(TIMER1_OVF_vect){
	Deltime1 ^= true;
}

ISR(INT0_vect){
	Button = true;
}

bool timerDelay() //interupt-basert delayfunksjon på 500 ms
{
	if(Deltime1){
		Deltime1 = false;
		return true;
	}
	else{return false;}
}

//function for ofset to the joystick x-position
//for use in node 2: dir = 0, pos 0 -128 = 255 - 0, dir = 1, pos 128 - 255 = 0 - 255
uint8_t offsetPos(uint8_t dir, int joyPosX){
	uint8_t ofPos = 0;
	if (dir == 4) ofPos = 0;
	else if (dir == 1) ofPos = Scale(joyPosX, 128, 0, 255, 0);
	else if (dir == 0) ofPos = Scale(joyPosX, 0, 128, 255, 0);

	return ofPos;
}



void drivers(){
	exInterInit_0();
	timer1_init();
	timer0_init();
	XMEM_Init();
	UART_Init(MYUBRR);
	Joystick_Init();
	oled_init();
	menuInit();

	canInit();
	//loopbackInit();
}

int main(void){
	drivers();
	DDRB |= (1<<PB0);

	uint8_t Pos = 0;

	CAN_frame TXtest;
	CAN_frame RXtest;

	TXtest.id = 5;
	TXtest.length = 5;
	TXtest.data[0] = 1; //y pos
	TXtest.data[1] = 2; //x pos
	TXtest.data[2] = 3; //x -dir
	TXtest.data[3] = 4; //Button
	TXtest.data[4] = 5; //sliPosLeft

	printf("Node 1 opertional\n");
	sei();
	while(1)
	{
		joyPos = Joystick_getPosition();
		joyDir = Joystick_getDirection();
		sliPos = Slider_getPosition();

		Pos = offsetPos(joyDir, joyPos.x);

		TXtest.data[0] = joyPos.y;
		TXtest.data[1] = Pos;
		TXtest.data[2] = joyDir;
		TXtest.data[4] = sliPos.right;

		canTransmit(TXtest);

		if (Button)
		{
			TXtest.data[3] = 133;
			Button = false;
		}
		else TXtest.data[3] = 1;
	}
	return 0;
}

/*
joyPos = Joystick_getPosition();
joyDir = Joystick_getDirection();
sliPos = Slider_getPosition();
buttonL = Slider_getLeftButton();
buttonR = Slider_getRightButton();
*/

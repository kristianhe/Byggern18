#include "joystick.h"

uint8_t joyX_init, joyY_init;

void Joystick_Init()
{
	DDRB &= ~(1 << DDB3);
	DDRB &= ~(1 << DDB2);
	Joystick_Calibrate();
}

void Joystick_Calibrate()
{
	joyX_init = ADC_Read(0);		// Leser verdien på ADC'en sin CH1 (Joystick X)
	joyY_init = ADC_Read(1);		// Leser verdien på ADC'en sin CH2 (Joystick Y)
}

Joystick_Position Joystick_getPosition()
{
	Joystick_Position joyPosition;
	joyPosition.x = ADC_Read(0);
	joyPosition.y = ADC_Read(1);

	return joyPosition;
}


Joystick_Direction Joystick_getDirection()
{
	Joystick_Position	joyPos = Joystick_getPosition();
	Joystick_Direction	joyDir;
	int threshold = 5;

	if (joyPos.x >  (128 + threshold))				joyDir = RIGHT;
	else if (joyPos.x < (128 - threshold)) 		joyDir = LEFT;
	else if (joyPos.y > (128 + threshold))		joyDir = UP;
	else if (joyPos.y < (128 - threshold)) 		joyDir = DOWN;
	else																			joyDir = NEUTRAL;

	return joyDir;
}

int Joystick_GetButton()
{
	return !(!(PINB & (1 << PINB3)));
}

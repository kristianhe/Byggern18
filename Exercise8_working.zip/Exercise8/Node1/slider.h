#include "setup.h"
#include "adc.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>


#ifndef SLIDER_H_
#define SLIDER_H_

typedef struct
{
	uint8_t	left;
	uint8_t right;
}Slider_Position;

void Slider_Init();
Slider_Position Slider_getPosition();
int Slider_getLeftButton();
int Slider_getRightButton();

#endif /* SLIDER_H_ */

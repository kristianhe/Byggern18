#include "fonts.h"
#include "oled.h"

volatile char *commandOLED = (char*) adCWOLED;	// For skriving til command-registeret
volatile char *dataOLED = (char*) adDWOLED;		// For skriving til data-registeret
uint8_t font_width = 8;	// Om vi bruker 8x8-fonten. GJ�R DETTE LITT FLOTTERE! Lage .width i fonts.h og bruke den her?
char colm = 0;
// 9.4 Recommended Software Initialization  (s. 15 OLED-datablad)
void oled_init()
{
	*commandOLED = 0xae; // display off
	*commandOLED = 0xa1; //segment remap
	*commandOLED = 0xda; //common pads hardware: alternative
	*commandOLED = 0x12;
	*commandOLED = 0xc8; //common output scan direction:com63~com0
	*commandOLED = 0xa8; //multiplex ration mode:63
	*commandOLED = 0x3f;
	*commandOLED = 0xd5; //display divide ratio/osc. freq. mode
	*commandOLED = 0x80;
	*commandOLED = 0x81; //contrast control
	*commandOLED = 0x50;
	*commandOLED = 0xd9; //set pre-charge period
	*commandOLED = 0x21;
	*commandOLED = 0x20; //Set Memory Addressing Mode
	*commandOLED = 0x02; //10xb = 0010 = 2 hex = Page Adressing Mode (kap 9.1.3 s. 33 OLED-datablad)
	*commandOLED = 0xdb; //VCOM deselect level mode
	*commandOLED = 0x30;
	*commandOLED = 0xad; //master configuration
	*commandOLED = 0x00;
	*commandOLED = 0xa4; //out follows RAM content
	*commandOLED = 0xa6; //set normal display
	*commandOLED = 0xaf; // display on

	oled_home();	// Går til første side, første øvre kolonneadresse og første nedre kolonneadresse
	oled_clear_all();									// Clearer all data p� alle OLED-sidene
}

// fra 9.1.3 Set Memory Addressing Mode (s. 33 OLED-datablad)
void oled_home()
{
	// Her kan vi ogsø bruke egne funksjoner dersom det er �nskelig:
	// oled_goto_page(0);
	// oled_goto_column(0);

	*commandOLED = 0xB0;	// Set the page start address of the target display location by command B0h to B7h. (8 gyldige pages/sider)
	*commandOLED = 0x00;	// Set the lower start column address of pointer by command 00h~0Fh. (F = 15 -> 16 gyldige �vre kolonneadresser)
	*commandOLED = 0x10;	// Set the upper start column address of pointer by command 10h~1Fh. (F = 15 -> 16 gyldige nedre kolonneadresser)
}

void oled_clear_all()
{
	for (uint8_t i = 0; i < 8; i++){oled_clear_page(i);} // Vi har 8 sider, s� vi clearer dataregisteret til alle sidene
}

void oled_clear_page(uint8_t page)
{
	// Gå til ønsket side
	oled_goto_page(page); // 8 bits * 16 kolonner = 128 bits
	for (uint8_t i = 0; i < 128; i++) {*dataOLED = 0x00;}	// Setter alle databitene til null
}

void oled_goto_page(uint8_t page)
{
	if ((page < 8) && (page >= 0)) {*commandOLED = 0xB0 | page;}		// Sidene spenner fra 0xB0 -> 0xB7 (8 sider)
}

void oled_goto_column(uint8_t column)
{
	if ((column < 16) && (column >= 0))
	{
		// Setter både øvre og nedre kolonneadresse
		*commandOLED = 0x00 | (column);	// Set the lower start column address of pointer by command 00h~0Fh. (F = 15 -> 16 gyldige �vre kolonneadresser)  --- 00001111
		*commandOLED = 0x10 | (column);
	}
}

void oledSetpos(uint8_t page, uint8_t column)
{
	oled_goto_page(page);		// Sjekker i disse funksjonene om page og column har gyldige verdier (hhv. 0-7 og 0-15)
	oled_goto_column(column);
}


void oled_print_page_mode(char r, char c, char *character)
{
	while(*character){
		oledSetpos(r,c);
		for (uint8_t i = 0; i < font_width; i++)
		{
			*dataOLED = pgm_read_byte((char*)font8 + (*character - 32)*font_width + i); //- 32
		}
		// Nå skriver vi ikke lengre enn antall kolonner.

		if (c > font_width*14)	// Hva om vi endrer font?????
		{
			r++;
			c = 0;
		}
		else c += font_width;

		*character++;
	}
}


void oled_print_horizontal_mode(char r, char c, char *character)
{

}

void oled_data(uint8_t data)
{
	*dataOLED = data;
}

void oled_command(uint8_t data)
{
	*commandOLED = data;
}

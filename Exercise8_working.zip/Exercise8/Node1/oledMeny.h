#include "oled.h"
#include "joystick.h"


void menuInit();
void printMenu();
void menuSetPosition(uint8_t position);
void menuIncrementPosition();
void menuDecrementPosition();
uint8_t menuGetPosition();
void menuEnter();

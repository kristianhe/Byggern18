#include "setup.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

void blink();
int Scale(uint8_t In, int  MaxIn, int  MinIn, int  MaxOut, int  MinOut);
int  Scale16(uint16_t In, int  MaxIn, int  MinIn, int  MaxOut, int  MinOut);
void exInterInit();

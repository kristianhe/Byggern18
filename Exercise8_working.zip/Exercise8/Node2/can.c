#include "can.h"

bool RXflag = false;

ISR(INT3_vect)
{
  bitModify(MCP_CANINTF, 0x01, 0x00); //clear the CANINTF.RXnIF bit when a message is moved into either of the receive buffers
	RXflag = true;
}

void canInit()
{
  exInterInit_3();  //initialize external interupt
  spi_init();       //initialize spi
  mcpReset();       //re-initialize the internal registers

  bitModify(MCP_CANCTRL, MODE_MASK, MODE_CONFIG); //set controller in Config mode

  if ((mcpRead(MCP_CANSTAT) & MODE_MASK) != MODE_CONFIG) printf("Not in Config mode\n");
  else printf("In Config mode\n");

  bitModify(MCP_CANINTE, 0x01, 0xff); //RX0IE: Interrupt when message received in RXB0
  bitModify(MCP_RXB0CTRL, 0x64, 0xfb); //RXM<1:0>: Turn mask/filters off; receive any message,  BUKT: Rollover Enable bit; 0 = Rollover disabled
  bitModify(MCP_CANCTRL, MODE_MASK, MODE_NORMAL); //set controller in Normal mode
  
  if ((mcpRead(MCP_CANSTAT) & MODE_MASK) != MODE_NORMAL) printf("Not in normal mode\n");
  else printf("In normal mode\n");

  printf("canInit comp\n");
}

void canTransmit(CAN_frame frame)
{
  if (canTXcomp())
  {
    mcpWrite(MCP_TXB0SIDH, frame.id >> 3);
    mcpWrite(MCP_TXB0SIDL, frame.id << 5);
    mcpWrite(MCP_TXB0DLC, (0x0f) & (frame.length)); //Sets the number of data bytes to be transmitted (0 to 8 bytes)

    for(uint8_t i = 0; i < frame.length; i++) mcpWrite((MCP_TXB0D0 + i), frame.data[i]);

    mcpRTS(0);  // Requesting to send on TXB0 buffer
  }

  else
  {
    printf("Transmit error!\n");
    printf("TX error status node 2: %x\n", mcpRead(MCP_EFLG));
  }
}

uint8_t canRecive(CAN_frame * RXframe)
{

  if (RXflag)
  {
    RXframe->id = ((mcpRead(MCP_RXB0SIDH) << 3) | (mcpRead(MCP_RXB0SIDL) >> 5));
    RXframe->length = (0x0f) & (mcpRead(MCP_RXB0DLC));

    for(uint8_t i = 0; i < RXframe->length; i++) RXframe->data[i] = mcpRead((MCP_RXB0D0 + i));

    RXflag = false;
    bitModify(MCP_CANINTF, 0x01, 0x00); //clear the CANINTF.RXnIF bit when a message is moved into either of the receive buffers

    return 1;
  }
  //if (mcpRead(MCP_EFLG) != 0) printf("RX error status node 2: %x\n", mcpRead(MCP_EFLG));
  return 0;
}

bool canTXcomp(){
  return !(bool)(test_bit( mcpRead(MCP_TXB0CTRL), 3)>>3);
}

void loopbackInit()
{
  bitModify(MCP_CANCTRL, MODE_MASK, MODE_LOOPBACK); //Normal mode
  printf("CAN COM-mode: Loopback\n");
}

% FOR HELICOPTER NR 3-10
% This file contains the initialization for the helicopter assignment in
% the course TTK4115. Run this file before you execute QuaRC_ -> Build 
% to build the file heli_q8.mdl.

% Oppdatert h�sten 2006 av Jostein Bakkeheim
% Oppdatert h�sten 2008 av Arnfinn Aas Eielsen
% Oppdatert h�sten 2009 av Jonathan Ronen
% Updated fall 2010, Dominik Breu
% Updated fall 2013, Mark Haring
% Updated spring 2015, Mark Haring


%%%%%%%%%%% Calibration of the encoder and the hardware for the specific
%%%%%%%%%%% helicopter
Joystick_gain_x = 1;
Joystick_gain_y = -1;


%%%%%%%%%%% Physical constants
g = 9.81; % gravitational constant [m/s^2]
l_c = 0.46; % distance elevation axis to counterweight [m]
l_h = 0.66; % distance elevation axis to helicopter head [m]
l_p = 0.175; % distance pitch axis to motor [m]
m_c = 1.92; % Counterweight mass [kg]
m_p = 0.72; % Motor mass [kg]


%%%%%%%%%%% Fra Part 1 - Problem 1-4
%%%%%%%%%%% Egne konstanter, m�linger og utregninger
V_s = 7.15;                                 % Motorspenning sum: M�lt og justert flere ganger
K_f = -(g*(m_c*l_c-2*m_p*l_h))/(V_s*l_h);   % Motorkraftkonstant Kf

J_p = 2*m_p*l_p^2;                          % Ligning (5a) side 14 i oppgavetekst
J_e = m_c*l_c^2+2*m_p*l_h^2;                % Ligning (5b) side 14 i oppgavetekst
J_lambda = (m_c*l_c^2)+2*m_p*(l_h^2+l_p^2);   % Ligning (5c) side 14 i oppgavetekst

L_1 = K_f*l_p;                              % Funnet ved utregning i Part 1 - Problem 1
L_2 = g*(m_c*l_c - 2*m_p*l_h);              % Funnet ved utregning i Part 1 - Problem 1
L_3 = K_f*l_h;                              % Funnet ved utregning i Part 1 - Problem 1
L_4 = -(K_f*l_h);                           % DENNE ER ENDRET HER! SER AT JEG GJORDE FEIL!

K_1 = L_1/J_p;
K_2 = L_3/J_e;
K_3 = (L_4*V_s)/J_lambda;


%%%%%%%%%%% Part 2 - Problem 1
omega_n = 2.7;      % En f�rste gjetning p� omega. H�yere omega -> kjappere respons
zeta = 1;         % Zeta = 1 gir et kritisk dempet system. Kan pr�ve litt forskjellig (under 1)

K_pp = (omega_n*omega_n)/K_1;       % Funnet via utregning problem 1
K_pd = (2*zeta*omega_n)/K_1;        % Funnet via utregning problem 1

h_1 = tf(K_1*K_pp, [1, K_1*K_pd, K_1*K_pp]);  % Transferfunksjon pitch
%step(h_1);                                    % Stegresponsen til pitch tf (BRUK FOR TUNING OMEGA)

%%%%%%%%%%% Part 2 - Problem 2
K_rp = -0.6;      % EN F�RSTE GJETNING P� K_rp! Denne skal v�re negativ. Jo mer negativ, jo kjappere
                  % P-kontroller-konstant for travel-rate

h_2 = tf(K_3*K_rp, [1, K_3*K_rp]);  % Transferfunksjon travel-rate
%step(h_2);                          % Stegresponsen til transferfunksjonen

%%%%%%%%%%% Part 3 - Problem 2
A = [0 1 0; 0 0 0; 0 0 0];
B = [0 0; 0 K_1; K_2 0];
C = [1 0 0; 0 0 1];
D = 0;
Q = [9 0 0; 0 3 0; 0 0 1];
R = [200 0; 0 200];
K = lqr(A, B, Q, R);
P = inv(C*inv(B*K - A)*B);

damp(A-B*K);

%%%%%%%%%%% Part 4 - Problem 2
A_42 = [   0 1 0 0 0 0;
           0 0 0 0 0 0;
           0 0 0 1 0 0;
           0 0 0 0 0 0;
           0 0 0 0 0 1;
         K_3 0 0 0 0 0]

B_42 = [0   0;
        0   K_1;
        0   0;
        K_2 0;
        0   0;
        0   0]

C_42 = [  0 0 1 0 0 0;
          0 0 0 0 1 0;]

% Kilde: https://se.mathworks.com/help/control/ref/obsv.html
Ob = obsv(A_42,C_42)            % Observerbarhetsmatrisen
rangOb = rank(Ob)               % Hvilken rang har observerbarhetsmatrisen? Full rang? (=6)
unob = length(A_42)-rank(Ob)    % Hvor mange tilstander er ikke observerbare?

r_start = -3;
r_gain = 25;
tau = [pi/5, pi/15, pi/50];

r = r_start*r_gain;

pObs = zeros(1,6);
%pObs2 = [-3 -6 -10 -14 -18 -22];
%pObs2 = [-3 -8 -16 -26 -37 -48];   % NOISY? Men krasjet ikke nedi bordet. Bedre kontroll i starten.
pObs2 = [-3 -5 -8 -12 -24 -32];     % CLEAN. Men n� var helikopteret nedi bakken i starten
for i = 1:3
    pObs(i) = r*(cos(tau(i)) + j*sin(tau(i)));
    pObs(i+3) = r*(cos(tau(i)) - j*sin(tau(i)));
end    

L = place(A_42', C_42', pObs2)';

eig(A_42' - (C_42')*L')

%sp = eig(A-K*B)

%eig(A_42-L*C_42)






#include "spi.h"

void SPI_init()
{
  DDRB |= (1<<MOSI) | (1<<SCK) | (1<<SS) | (1 << PB0);  //Output
  DDRB &= ~(1<<MISO);                                   //Input
  SPCR = (1<<SPE) | (1<<MSTR) | (1<<SPR0);              //SPE: SPI Enable, MSTR: Master/Slave Select, SPR1, SPR0: SPI Clock Rate Select 1 and 0 - Fosc/16
}

uint8_t SPI_read()
{
  SPI_write(0);                                         //Dummy data to enable slave to send data to master
  while(!(SPSR & (1<<SPIF)));                           //Waits for reception to complete
  return SPDR;                                          //Returns data register
}

void SPI_write(uint8_t cData)
{
  SPDR = cData;                                         //Start transmission
  while(!(SPSR & (1<<SPIF)));                           //Waits for transmission to complete
}

void chipSelect(bool selc)
{
  if(selc) PORTB &= ~(1<<SS);
  else PORTB |= (1<<SS);
}

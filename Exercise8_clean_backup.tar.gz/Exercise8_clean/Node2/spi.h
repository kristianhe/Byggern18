#include "setup.h"
#include "util.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define SS PB7    //Slave select
#define SCK PB1   //Clock signal
#define MOSI PB2  //Master out, slave in
#define MISO PB3  //Master in, slave out

void SPI_init();
uint8_t SPI_read();
void SPI_write(uint8_t cData);
void chipSelect(bool selc);

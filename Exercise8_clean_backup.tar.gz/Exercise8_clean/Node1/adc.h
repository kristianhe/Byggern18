#include "setup.h"

#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>

uint8_t ADC_read(uint8_t Channel);

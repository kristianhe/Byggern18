#include "util.h"

#include <avr/wdt.h>

void watchdogInit()
{
	//WDE: Watchdog Enable
	wdt_enable(WDTO_2S); 	//Watchdog Timer Prescale Select: WDP 0,1,2 = 1: reset at 2.2s
	wdt_reset();
}

//Init functions for timer0 and timer1
void timer0_init()
{
	TCCR0 |= (0<<CS02) |(1<<CS01) | (1<<CS00); 		//Prescale 64
	TIMSK |= (1<<TOIE0); 													//Interrupt at Timer/Counter0 Overflow
}

void timer1_init()
{
	TCCR1B |= (0<<CS12) | (1<<CS11) | (1<<CS10); 	//Prescale 64 ~ ovf pr 0.85 s
	TIMSK |= (1<<TOIE1); 													//Interrupt at Timer/Counter1 Overflow
}

//Init functions for external interrupts
void exInterInit_0()
{
	MCUCR |= (1<<ISC01) | (0<<ISC00);
	GICR |= (1<<INT0);
}

void exInterInit_1()
{
	MCUCR |= (1<<ISC11) | (0<<ISC10);
	GICR |= (1<<INT1);
}

void exInterInit_2()
{
	EMCUCR |= (0<<ISC2);
	GICR |= (1<<INT2);
}

uint8_t scale(uint8_t In, int  MaxIn, int  MinIn, int  MaxOut, int  MinOut) //Generic scale function
{
	float k;
	uint8_t Out;
	k = (float)(MaxOut-MinOut)/(float)(MaxIn-MinIn);
  Out = (uint8_t)(k*In-k*MinIn+MinOut);
  return Out;
}

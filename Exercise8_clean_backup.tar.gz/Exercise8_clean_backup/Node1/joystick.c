#include "joystick.h"

uint8_t joyX_init, joyY_init;

void joystickInit()
{
	DDRB &= ~(1 << DDB3);
	DDRB &= ~(1 << DDB2);
	joystickCalibrate();
}

void joystickCalibrate()
{
	joyX_init = ADC_read(0);		// Leser verdien på ADC'en sin CH1 (Joystick X)
	joyY_init = ADC_read(1);		// Leser verdien på ADC'en sin CH2 (Joystick Y)
}

joystick_position joystickGetPosition()
{
	joystick_position joyPosition;
	joyPosition.x = ADC_read(0);
	joyPosition.y = ADC_read(1);

	return joyPosition;
}

uint8_t joystickGetDirection()
{
	joystick_position	joyPos = joystickGetPosition();
	uint8_t joyDir;
	uint8_t threshold = 100;

	if (joyPos.x >  (128 + threshold))				joyDir = 0;
	else if (joyPos.x < (128 - threshold)) 		joyDir = 1;
	else if (joyPos.y > (128 + threshold))		joyDir = 3;
	else if (joyPos.y < (128 - threshold)) 		joyDir = 2;
	else																			joyDir = 4;

	return joyDir;
}

int joystickGetButton()
{
	return !(!(PINB & (1 << PINB3)));
}

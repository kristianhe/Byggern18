#include "adc.h"
uint8_t deltime = 1;

uint8_t ADC_read(uint8_t Channel)
{
  volatile char *dataADC = (char*) adADC;

  if (Channel > 3) return 0;
  *dataADC = (0x04 | Channel);
  _delay_us(50);

  return *dataADC;
}

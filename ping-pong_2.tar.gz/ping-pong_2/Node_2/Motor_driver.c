#include "Motor_driver.h"
#define _OE PH5
#define DIR PH1
#define SEL PH3
#define _RST PH6
#define EN PH4
#define ABS(x) ((x)<0?(-(x)):(x))
//--PID--//

//volatile int8_t referenceValue;
volatile uint16_t measurementValue;
volatile uint16_t referenceValue;
volatile uint8_t inputValue;
//-------//
extern bool flag_enc;
extern bool flag_enc_full;
extern bool PID_timer;
extern volatile uint8_t var_motor;
volatile uint16_t max_enc;
//volatile uint16_t min_enc;
//volatile uint8_t val_enc;

volatile uint16_t range;


// function to subtract two values
// using 2's complement method
/*uint16_t Subtract(uint16_t a, uint16_t b)
{
    uint16_t c;

    // ~b is the 1's Complement of b
    // adding 1 to it make it 2's Complement
    c = a + (~b + 1);

    return c;
}*/


void motor_init(){
  DDRH|=(1<<DDH1)|(1<<DDH3)|(1<<DDH4)|(1<<DDH5)|(1<<DDH6); //H1->DIR, H3->SEL, H4->EN, H5->!OE, H6->RST outputs for arduino
  DDRK=0b00000000; // All K pins are inputs from decoder
  PORTH|=(1<<EN); // Enable motor
  PORTH|=(1<<_RST); //Enable encoder counting



}

uint16_t enc_out(){
  volatile uint8_t auxL;
  volatile uint8_t auxH;
  volatile uint16_t aux;
  PORTH&=(~(1<<_OE)); // !OE high, output encoder Enable
  PORTH&=(~(1<<EN)); // SEL high, MSB
  _delay_us(20);
  auxH=PINK; // Read MSB
  PORTH|=(1<<EN); // SEL high, MSB
  _delay_us(20);
  auxL=PINK; //Read MSB
  PORTH|=(1<<_OE);
  aux=auxH;
  aux=aux<<8;
  aux+=auxL;
  //printf("%04X\n\r",aux );
  return aux;
//  printf("%04X\n\r", range);
}

uint16_t Get_Measurement(){
    uint16_t val;
    val=-enc_out();
    if(val<0){
      val=0;
    }
    if (val>max_enc){
      val=max_enc;
    }
    val/=range;
    //printf("%d\n\r",val );
    return val;
}

void sweep_direction(uint8_t data){
  if(data<0x80){
    PORTH&=(~(1<<DIR)); //To the left
  }
  else{
    PORTH|=(1<<DIR); //To the right
  }
}

void calibrate_motor(){
  //cli();
  sweep_direction(0x40);
  send_I2C(0x40);
  _delay_ms(3000);
  //send_I2C(0x80);
  //_delay_ms(1000);
  //min_enc=Get_Measurement();
  PORTH&=(~(1<<_RST)); //Toggle Reset
  _delay_ms(5);
  PORTH|=(1<<_RST);
  sweep_direction(0xC0);
  send_I2C(0xC0);
  _delay_ms(3000);
  //send_I2C(0x80);
  max_enc=-enc_out();
  _delay_ms(1000);
  //max_enc=enc_out();
/*  if(flag_enc_full){
    //flag_enc_full=false;
    PORTH&=(~(1<<_RST)); //Toggle Reset
    _delay_ms(5);
    PORTH|=(1<<_RST);
    printf("Calibrating again...\n\r");
    calibrate_motor();
  }*/
  printf("%04X\n\r", max_enc );
  range=max_enc/0x00FF;
  printf("%d\n\r", range);
  //sei();
}

/*uint16_t Get_Reference(){ // Value from the joystick corresponding to a num range encoder 0x00->min_enc 0xFF->max_encoder
   measurementValue=max_enc-var_motor*range;
   printf("0x04X\n\r", measurementValue);
}*/

void stop_motor(){  PORTH&=(~(1<<EN));}
void en_motor(){   PORTH|=(1<<EN);}


//-------PID--------//


void Init(void)
{
	//pid_Init(&pidData);
  //printf("P:%d I:\n" );
  //	PRR &= ~(1 << PRTIM0);
}

void Set_Input(uint8_t inputValue) // Value from the Encoder corresponding to a num range 0-255
{
  sweep_direction(inputValue);
  send_PID(inputValue);
}

void PID_control(pidData_t * pidData){
  if(PID_timer){
    PID_timer=false;
    measurementValue=Get_Measurement();
    referenceValue=var_motor;
    //printf("setpoint:%d, Encoder: %d\n\r",var_motor, measurementValue );
    inputValue=pid_Controller(referenceValue, measurementValue, pidData);
    //printf("salida:%d\n\r", inputValue);
    //Set_Input(inputValue);
  }
}

#ifndef PID_H
#define PID_H

#include "stdint.h"

#define SCALING_FACTOR 128
#define K_P 0.7
#define K_I 0.10
#define K_D 0.02

/*! \brief PID Status
 *
 * Setpoints and data used by the PID control algorithm
 */
typedef struct {
	//! Last process value, used to find derivative of process value.
	uint16_t lastProcessValue;
	//! Summation of errors, used for integrate calculations
	uint32_t sumError;
	//! The Proportional tuning constant, multiplied with SCALING_FACTOR
	uint16_t P_Factor;
	//! The Integral tuning constant, multiplied with SCALING_FACTOR
	uint16_t I_Factor;
	//! The Derivative tuning constant, multiplied with SCALING_FACTOR
	uint16_t D_Factor;
	//! Maximum allowed error, avoid overflow
	uint16_t maxError;
	//! Maximum allowed sumerror, avoid overflow
	uint16_t maxSumError;
} pidData_t;

/*! \brief Maximum values
 *
 * Needed to avoid sign/overflow problems
 */
// Maximum value of variables
#define MAX_INT INT16_MAX
#define MAX_LONG INT32_MAX
#define MAX_I_TERM (MAX_LONG / 2)

// Boolean values
#define FALSE 0
#define TRUE 1

void    pid_Init(pidData_t *pid);
uint16_t pid_Controller(uint8_t setPoint, uint8_t processValue, pidData_t *pid_st);
void    pid_Reset_Integrator(pidData_t *pid_st);
/*
void    pid_Init( volatile struct PID_DATA *pid);
uint16_t pid_Controller(uint16_t setPoint, uint16_t processValue, volatile struct PID_DATA *pid_st);
void    pid_Reset_Integrator(volatile pidData_t *pid_st);
*/
#endif

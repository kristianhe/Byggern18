#include "flex_driver.h"
#define MAX 0
uint8_t count_Flex=0;
extern bool flag_timer_flex;

void Flex_init(){
  DDRF&=(~(1<<DDF1));
  ADCSRA|=(1<<ADEN); // ADC Enable
  ADMUX&=0b00000001;  //AVCC with external capacitor at AREF pin . Info to the right. input ADC01
//  ADMUX|=(1<<REFS0); //AVCC with external capacitor at AREF pin
//  ADMUX&=(~(1<<REF1)); //AVCC with external capacitor at AREF pin
  ADCSRB&=(~(1<<MUX5)); // Info from port ADC01
  //ADCSRA|=(1<<ADIF); // When ADIF low, finished with the conversion
  ADCSRA&=(~(1<<ADPS1)&(~(1<<ADPS0))); // Division Factor 32
  ADCSRA|=(1<<ADPS2);//|(1<<ADPS0);
}

uint16_t Flex_read(){
  uint16_t a;
  ADCSRA|=(1<<ADSC);
  while(ADCSRA&(1<<ADSC)){};
  //ADCSRA|=(1<<ADIF);
  cli();
  a = ADC;
  sei();
  return a;
}

void Flex_check(){
  if(flag_timer_flex){
    flag_timer_flex=false;
    if(count_Flex<MAX){
      count_Flex++;
    }
    else{
      count_Flex=0;
/*      if(IR_average<=(0x003F*25)){
        //printf("HUeeee\n\r");
      }
      IR_average=0x0000;*/
      printf("%d\n\r", Flex_read() );
    }
  }
}

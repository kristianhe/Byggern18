#include "pid.h"
#include "stdint.h"

#define MAX_INT_ 32767
#define MAX_I_TERM_ 2147483647

/*! \brief Initialization of PID controller parameters.
 *
 *  Initialize the variables used by the PID algorithm.
 *
 *  \param p_factor  Proportional term.
 *  \param i_factor  Integral term.
 *  \param d_factor  Derivate term.
 *  \param pid  Struct with PID status.
*/
void pid_Init(pidData_t *pid)
{
	// Start values for PID controller
	pid->sumError         = 0;
	pid->lastProcessValue = 0;
	// Tuning constants for PID loop
	pid->P_Factor = K_P * SCALING_FACTOR;
	pid->I_Factor = K_I * SCALING_FACTOR;
	pid->D_Factor = K_D * SCALING_FACTOR;
	// Limits to avoid overflow
	pid->maxError    = MAX_INT_ / (pid->P_Factor + 1);
	pid->maxSumError = MAX_INT_ / (pid->I_Factor+1);
}

/*! \brief PID control algorithm.
 *
 *  Calculates output from setpoint, process value and PID status.
 *
 *  \param setPoint  Desired value.
 *  \param processValue  Measured value.
 *  \param pid_st  PID status struct.
 */
uint16_t pid_Controller(uint8_t setPoint, uint8_t processValue, pidData_t *pid_st)
{
	uint16_t errors;
	uint16_t p_term, d_term;
	uint32_t i_term, ret, temp;

	errors = setPoint - processValue;
	printf("error:%d\n\r",errors );

	if ((errors<10) && (errors>-10) ) {
			pid_st->sumError = 0;
	}

	// Calculate Pterm and limit error overflow
	/*if (errors>(32767/(pid_st->I_Factor+1))) {
		p_term = MAX_INT_;
	} else if (errors<(-(32767/(pid_st->I_Factor+1)))) {
		p_term = -MAX_INT_;
	} else {*/
		p_term = pid_st->P_Factor * errors;
	//}
	printf("p_term:%d max_error:%d\n\r", p_term, pid_st->maxError);
	// Calculate Iterm and limit integral runaway
	temp = pid_st->sumError + errors;
	if (temp > 2374) {
		i_term           = MAX_INT;
		pid_st->sumError = 2374;
	} else if (temp < -2374) {
		i_term           = -MAX_INT;
		pid_st->sumError = -2374;
	} else {
		pid_st->sumError = temp;
		i_term           = pid_st->I_Factor * pid_st->sumError;
	}
	printf("temp:%d sumError%d\n\r",temp, pid_st->sumError );

	// Calculate Dterm
	d_term = pid_st->D_Factor * (pid_st->lastProcessValue - processValue);

	pid_st->lastProcessValue = processValue;

	ret = (p_term + i_term + d_term) / SCALING_FACTOR;
	//printf("p_term:%d, i_term:%d, d_term:%d\n\r", p_term, i_term, d_term);
	if (ret > 126) {
		ret = 126;
	} else if (ret < -126) {
		ret = -126;
	} /*else if ((ret < 0x40) && (ret > 0x20)) {
		ret = 0x40;
	} else if ((ret < -0x40) && (ret > -0x20)) {
		ret = -0x40;
	}*/

	return ((uint16_t)ret);
}

#ifndef _FLEX_
#define _FLEX_
#include <stdio.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#define F_CPU 16000000
#include <util/delay.h>
#include <stdbool.h>

void Flex_init();
uint16_t Flex_read();
void Flex_check();

#endif

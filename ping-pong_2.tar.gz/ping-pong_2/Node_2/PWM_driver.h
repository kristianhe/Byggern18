#ifndef _PWM_
#define _PWM_
#include "Timer_driver.h"

void var_PWM(uint8_t);

#endif

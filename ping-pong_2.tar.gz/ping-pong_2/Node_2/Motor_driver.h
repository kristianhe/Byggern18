#ifndef _MOTOR_
#define _MOTOR_

#include <stdio.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#define F_CPU 16000000
#include <util/delay.h>
#include <stdbool.h>

#include "TWI_Master.h"
#include "pid.h"

//uint16_t Subtract(uint16_t, uint16_t);
void motor_init();
void calibrate_motor();
void sweep_direction(uint8_t);
void en_motor();
void stop_motor();
uint16_t Get_Measurement();
//uint16_t Get_Referece();
void Init();
void Set_Input(uint8_t);
void PID_control(pidData_t*);



#endif

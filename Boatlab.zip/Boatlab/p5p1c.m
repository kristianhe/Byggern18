%Settings
Gwidth = 1500;
Gheight = 600;

figure('Units','pixels','Position',[2500,10,Gwidth,Gheight]); 
figure(1);
plot(comp_deg(1,1:10000),comp_deg(2,1:10000),'linewidth',0.8,'Color',[0 0.5 1]);
grid;
set(gca,'fontsize',15);
xlabel('Time [ms]','fontsize',15);
ylabel('Compass [deg]','fontsize',15);
title('Sine input with \omega_2 = 0.005 rad/s (with disturbance)','fontsize',18);
set(gca,'FontName','times');

%Save plot
%print('p5p1c_w2', '-depsc');
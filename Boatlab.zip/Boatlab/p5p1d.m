%Settings
Gwidth = 1500;
Gheight = 600;

figure('Units','pixels','Position',[2500,10,Gwidth,Gheight]); 
figure(1);
plot(TF_comp(1,1:10000),TF_comp(2,1:10000),'linewidth',1.2,'Color',[0 0.5 1]);
hold on;
plot(comp_deg(1,1:10000),comp_deg(2,1:10000),'linewidth',1.2,'Color',[1 0.5 0]);
grid;
set(gca,'fontsize',15);
xlabel('Time [ms]','fontsize',15);
ylabel('Compass [deg]','fontsize',15);
title('Response with step input of 1 deg (without disturbance)','fontsize',18);
legend('Transfer function','Cargo ship');
set(gca,'FontName','times');

%Save plot
print('p5p2d', '-depsc');
%Settings
Gwidth = 1500;
Gheight = 600;

figure('Units','pixels','Position',[2500,10,Gwidth,Gheight]); 
figure(1);
plot(comp_deg(1,1:10000),comp_deg(2,1:10000),'linewidth',1.5,'Color',[1 0.5 0]);
grid;
set(gca,'fontsize',15);
xlabel('Time [ms]','fontsize',15);
ylabel('Compass [deg]','fontsize',15);
title('Sine input with \omega_1 = 0.05 rad/s (no disturbance)','fontsize',18);
set(gca,'FontName','times');

%Save plot
%print('p5p1b_w1', '-depsc');
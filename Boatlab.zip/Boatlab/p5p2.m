%Settings
fs = 10;
window = 4096;
Gwidth = 1000;
Gheight = 600;

%Estimate PSD
[pxx,f] = pwelch(psi_w(2,:)*(1/2*pi),window,[],[],fs*(2*pi));

%Resonance frequency
[pxxMax, ind] = max(pxx);
w_0 = f(ind);

%Variance/Intensity
variance = var(pxx);
std_div = sqrt(variance);

%Damping factor
lambda = 1;
K_w = 2*lambda*w_0*std_div;
w = 1;
P_psi_w = (K_w^2*w)/(w^4 + 2*w_0^w*w^2*(2*lambda^2-1) + w_0^4);
startpt = 1;
%x = lsqcurvefit(P_psi_w,startpt,xdata,ydata);

%Plot
figure('Units','pixels','Position',[3000,10,Gwidth,Gheight]); 
figure(1);
plot(f(1:105,1),pxx(1:105,1),'linewidth',2,'Color',[1 0.5 0]);
hold on;
plotw_0 = plot(w_0,pxxMax,'o','MarkerEdgeColor',[1 0 0],'MarkerFaceColor',[1 0 0],'MarkerSize',5);
grid;
set(gca,'TickLabelInterpreter','latex','XTickLabel',{0,'$\frac{\pi}{8}$','$\frac{\pi}{4}$','$\frac{3\pi}{8}$','$\frac{\pi}{2}$','$\frac{5\pi}{8}$'},'fontsize',20);
xticks(0:pi/8:pi/2);
xlabel('Frequency [rad/s]','fontsize',15);
ylabel('Intensity [power s/rad]','fontsize',15);
%title('Estimation of PSD function','fontsize',15);
legend(plotw_0,{'Resonance frequency \omega_0'},'FontSize',11);
set(gca,'FontName','times');


%Save plot
%print('p5p2_w0', '-depsc');


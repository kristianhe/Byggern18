/*
 * FungerendeKode.c
 *
 * Created: 31.08.2018 17.26.17
 *  Author: Simon
 */
#include "uart.h"
#include "setup.h"
#include "memory.h"
#include "util.h"
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>


int main(void){

	DDRB = 0x01;

	UART_Init(MYUBRR);	// Finner MYUBRR i setup.h
	XMEM_Init();

	printf("Init finished!\n\r");
	printf("PRØVER igjen^8\n\r");
	blink();
	while(1)
	{
		_delay_ms(5000);
		SRAM_test();
	}
	return 0;
}

#include <stdio.h>
//#define OFFSET 0x1000                    // Markerer staren på de eksterne minneadressene

void XMEM_Init(void);

//void XRAM_memory_masking(void);

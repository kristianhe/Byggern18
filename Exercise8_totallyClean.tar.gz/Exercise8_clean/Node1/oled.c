#include "fonts.h"
#include "oled.h"

volatile char *commandOLED = (char*) adCWOLED;	//For writing to the command register
volatile char *dataOLED = (char*) adDWOLED;			//For writing to the data register
uint8_t font_width = 8;													//If 8x8-font is used
char colm = 0;

// 9.4 Recommended Software Initialization  (p.15 from datasheet)
void OLED_init()
{
	*commandOLED = 0xae; //Display off
	*commandOLED = 0xa1; //Segment remap
	*commandOLED = 0xda; //Common pads hardware: alternative
	*commandOLED = 0x12;
	*commandOLED = 0xc8; //Common output scan direction:com63~com0
	*commandOLED = 0xa8; //Multiplex ration mode:63
	*commandOLED = 0x3f;
	*commandOLED = 0xd5; //Display divide ratio/osc. freq. mode
	*commandOLED = 0x80;
	*commandOLED = 0x81; //Contrast control
	*commandOLED = 0x50;
	*commandOLED = 0xd9; //Set pre-charge period
	*commandOLED = 0x21;
	*commandOLED = 0x20; //Set Memory Addressing Mode
	*commandOLED = 0x02; //10xb = 0010 = 2 hex = Page Adressing Mode (kap 9.1.3 s. 33 OLED-datablad)
	*commandOLED = 0xdb; //VCOM deselect level mode
	*commandOLED = 0x30;
	*commandOLED = 0xad; //Master configuration
	*commandOLED = 0x00;
	*commandOLED = 0xa4; //Out follows RAM content
	*commandOLED = 0xa6; //Set normal display
	*commandOLED = 0xaf; //Display on

	OLED_home();				//First page, first upper row address and first lower column address
	OLED_clearAll();		//Clears all data on the OLED pages
}

// 9.1.3 Set Memory Addressing Mode (p.33 in datasheet)
void OLED_home()
{
	*commandOLED = 0xB0;	// Set the page start address of the target display location by command B0h to B7h. (8 gyldige pages/sider)
	*commandOLED = 0x00;	// Set the lower start column address of pointer by command 00h~0Fh. (F = 15 -> 16 gyldige �vre kolonneadresser)
	*commandOLED = 0x10;	// Set the upper start column address of pointer by command 10h~1Fh. (F = 15 -> 16 gyldige nedre kolonneadresser)
}

void OLED_clearAll()
{
	for (uint8_t i = 0; i < 8; i++){OLED_clearPage(i);} 						//We have 8 pages, so we clear the data registers for all the 8 pages
}

void OLED_clearPage(uint8_t page) 																//Go to a spesific page
{
	OLED_goToPage(page); 																						//8 bits * 16 kolonner = 128 bits
	for (uint8_t i = 0; i < 128; i++) {*dataOLED = 0x00;}						//Sets all databits to zero
}

void OLED_goToPage(uint8_t page)
{
	if ((page < 8) && (page >= 0)) {*commandOLED = 0xB0 | page;}		// Sidene spenner fra 0xB0 -> 0xB7 (8 sider)
}

void OLED_goToColumn(uint8_t column)
{
	if ((column < 16) && (column >= 0))
	{
		*commandOLED = 0x00 | (column);																//Set the lower start column address of pointer by command 00h~0Fh. (F = 15 -> 16 valid upper column addresses)  --- 00001111
		*commandOLED = 0x10 | (column); 															//Set the upper start column address
	}
}

void OLED_setPos(uint8_t page, uint8_t column)
{
	OLED_goToPage(page); 																						//Check for valid values within these functions (that is, 0-7 og 0-15)
	OLED_goToColumn(column);
}

void OLED_printPageMode(char r, char c, char *character)
{
	while(*character)
	{
		OLED_setPos(r,c);

		for (uint8_t i = 0; i < font_width; i++)
		{
			*dataOLED = pgm_read_byte((char*)font8 + (*character - 32)*font_width + i);
		}

		if (c > font_width*14)
		{
			r++;
			c = 0;
		}
		else c += font_width;

		*character++;
	}
}

bool OLED_status(bool sleepFlag, bool sleepStatus, bool wakeFlag)
{
	if (sleepFlag)
	{
		sleepFlag = false;
		OLED_clearAll();
		*commandOLED = 0xae; //Display off
		sleepStatus = true;
	}

	if (wakeFlag && sleepStatus)
	{
		sleepStatus = false;
		*commandOLED = 0xaf; //Display on
		OLED_clearAll();
		wakeFlag = false;
	}

	return sleepStatus;
}

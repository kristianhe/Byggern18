#include "setup.h"
#include "adc.h"

#include <stdio.h>
#include <avr/io.h>

typedef struct slider_position {
	uint8_t	left;
	uint8_t right;
} slider_position;

void sliderInit();
slider_position sliderGetPosition();
int sliderGetLeftButton();
int sliderGetRightButton();


#include "setup.h"
#include "uart.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"
#include "timer.h"
#include "Notes.h"
#include "Motor_driver.h"
#include "pid.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>     		//atoi
#include <string.h>					//strchr
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

//Difficulties on PID:
	//Medium: 		Kp = 1.5, Ki = 0.01, Kd = 0.9
	//						Kp = 3.0, Ki = 0.01, Kd = 1.3
	//Nightmare: 	Kp = 1.0, Ki = 0.01, Kd = 5.3

#define K_P   1
#define K_I 	0.0
#define K_D 	1.3

#define SCALING 100
struct PID_DATA pidData;

bool Deltime = false;
bool INTflag = false;

//Global counters
uint8_t stateCounter = 0;
uint8_t trigCounter = 0;
uint8_t timeStep = 0;
uint8_t startupCounter = 0;

uint8_t SCTlimit = 0;
uint16_t scorecount = 0;

uint8_t muCount = 0;
uint16_t freq = 0;

//Timer0 overflow interrupt
ISR(TIMER0_OVF_vect){
	trigCounter++;
	timeStep++;
	startupCounter++;
	stateCounter++;
	SCTlimit++;
}

//Timer1 overflow interrupt
ISR(TIMER1_OVF_vect){
	scorecount++;
}

//Initialize the drivers
void drivers()
{
	UART_init(MYUBRR);
	PWM_init();
	timer0_init();
	timer1_init();
	CAN_init();
	IR_init();
	motorInit();
	PID_init(K_P*SCALING, K_I*SCALING, K_D*SCALING, &pidData);
}

int main(void)
{
	//Drivers and global interrupt
	drivers();
	sei();
	DDRE |= (1<<PE4);
	OCR3A = 3200;

	//State variables for the game
	uint8_t state = 0;
	bool stateFlag = false;

	//Inputs and outputs
	uint8_t servoVal = 0;
	uint8_t joyPos_x = 0;
	uint8_t dirVal = 0;
	uint8_t solenoid = 0;
	uint8_t sliderPos = 0;
	uint8_t IR_value = 255;

	//For PID controller
	uint8_t refPos = 128;
	uint16_t enc = 0;
	int motorInput = 0;
	uint16_t tmpEnc1 = 0;
	uint16_t tmpEnc2 = 0;
	int deltaEnc = 0;

	//Boolean control variables
	bool startFlag = false;
	bool trigFlag = false;
	bool trigCountFlag = false;

	//For state machine
	bool oddFlag = true;
	bool evenFlag = false;
	bool calcDelta = false;
	bool pidFlag = false;

	//CAN frame
	CAN_frame RXframe;
	CAN_frame TXframe;
	TXframe.id = 13;
	TXframe.length = 1;
	TXframe.data[0] = 0;
	//Pregame ID 62
	//Ingame ID 42

	//TESTLOGIKK FOR STYRING VIA GUI
	char guidata[15];
	char inputChar = 0;
	bool endMsgFlag = false;
	servoVal = 127;
	solenoid = 0;
	sliderPos = 127;

	while((startupCounter < 100) && !(startFlag)) 																	//Resetting the motor and encoder
	{
		motorControl(-128);
		encoderReset();
	}
	printf("Node 2 opertional\n");
	_delay_ms(500);

	while(1)
	{
		//-----------------------------------------------------------------------------
		//Ikke fjern, fungerende kode for å kommunisere med node 1 (linje 150 til 290).
		// Test kode for GUI ligger nederst på siden (linje 290 til 393)
		//-----------------------------------------------------------------------------

		//DC motor, servo motor and IR
		motorControl(motorInput); 																										//Gain for the DC motor
		OCR3A = scale(servoVal, 255,0, 4600, 1800); 																	//PWM values for the servo motor, In: 0 - 255. out: 1800 - 4600 ~ Translates to duty cycle 0.9 - 2.1 ms
		IR_value = IR_readWithFilter(); 																							//Reading the values from the ADC. Can be in the range 0 - ~50

		//CAN reception
		if (CAN_receive(&RXframe))
		{
			if(RXframe.id == 42){
				state = RXframe.id;
				servoVal = 128;
				solenoid = 10;
				sliderPos = 0;
			}
			else if (RXframe.id == 69){
				servoVal = RXframe.data[0];
				dirVal =  RXframe.data[2];
				solenoid = RXframe.data[3];
				sliderPos = RXframe.data[4];
			}
		}

		if ((int)encoderRead() < 0) 																									//The encoder can read negative values, we don't want that. This code makes the PID controller to jump off this bad position
		{
			enc = 5;
			refPos = 10;
		}
		else																																					//This is the values we are expecting
		{
			enc = scale16(encoderRead(), 10000, 20, 255, 0); 														//Scaling the encoder values from the range 20 - 10000 to 0 - 255
			refPos = sliderPos;
		}

		//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		switch (state) {																															//Switch case used for the three states in the game: PRE-GAME, IN-GAME and POST-GAME (reset)
			case 42:
				//----------------------
				//PRE-GAME
				//----------------------

				motorInput = 0; //Zero motor gain
				if(RXframe.id == 69) state = 69;
				break;
			case 69:
				//----------------------
				//IN-GAME
				//----------------------

				//State machine for PID controller
				if (((timeStep%2) == 0) && (oddFlag) && !(evenFlag))											//Previous encoder value, sample at odd numbers of the counter value
				{
					tmpEnc1 = enc;
					//Go to next state flags
					oddFlag = false;
					evenFlag = true;
				}
				else if (((timeStep%2) != 0) && (evenFlag) && !(oddFlag))									//Current encoder value, sample at even numbers of the counter value
				{
					tmpEnc2 = enc;
					//Go to next state flags
					evenFlag = false;
					calcDelta = true;
				}
				if (calcDelta){
					deltaEnc = (int)(tmpEnc2 - tmpEnc1); 																		//Calculating delta value for the encoder, used for the derivative part in the PID controller
					//Go to next state flags
					calcDelta = false;
					pidFlag = true;
				}
				if (pidFlag)
				{
					motorInput = PID_controller(refPos, enc, timeStep, deltaEnc, &pidData); //Output from the PID controller
					//Go to next state flags
					pidFlag = false;
					oddFlag = true;
				}

				//Logic for solenoid trigering
				if (solenoid == 133) trigFlag = true;
				if (trigFlag){
					PORTE |= (1<<PE4); 																											//Set output pin PE4 high

					//Go to next state flags and counters
					trigFlag = false;
					trigCountFlag = true;
					trigCounter = 0;
				}
				if ((trigCountFlag) && (trigCounter > 10)){
					PORTE &= ~(1<<PE4); 																										//Set output pin PE4 low

					//Go to next state flags and counters
					trigCountFlag = false;
					trigCounter = 0;
				}

				//Score counter and test for game over
				if ((IR_value < 10) && (SCTlimit > 100))
				{
					printf("Game over\n");
					scorecount = 0;
					SCTlimit = 0;
					TXframe.data[0] = scorecount;
					CAN_transmit(TXframe);
					scorecount = 0;
				}

				if((RXframe.id == 0) || (RXframe.id == 13)){
					stateCounter = 0;
					state = 0;
				}
				break;
			case 0:
				//----------------------
				//POST-GAME
				//----------------------

				while((stateCounter < 100) && !(stateFlag))																//Reset motor and encoder
				{
					motorControl(-128);
					encoderReset();
				}
				if(stateCounter > 210)
				{
					OCR3A = 3200;
					stateCounter = 0;
					stateFlag = true;
				}
				if (stateFlag)
				{
					stateFlag = false;
					state = 42;
				}
				break;
			default:
				break;
			}

		if(timeStep > 10) timeStep = 0;																								//Reset the counter used for sampling the encoder
	}

	return 0;
}

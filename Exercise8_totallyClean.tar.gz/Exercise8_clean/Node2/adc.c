#include "adc.h"

uint8_t ADC_read(uint8_t Channel)
{
  volatile char *dataADC = (char*) adADC;

  if (Channel > 3) return 0;
  *dataADC = (0x04 | Channel);
  _delay_us(50);
  return *dataADC;
}

void IR_init()                                              //Reads the value from the IR sensor on F0... ADCSRA – ADC Control and Status Register A (p. 285)
{
	DDRF &= ~(1 << PF0);	                                    //Sets PF0 as input
	ADCSRA |= (1 << ADEN);                                    //Enable ADC, Mux = 0000000, uses ADC0
	ADCSRA |= (1 << ADPS2) || (1 << ADPS1) || (1 << ADPS0);   //ADC must have a working frequency between 50kHz and 200kHz: Division factor / prescale = 128.  - working frequency = 16mHz/128 = 125kHz
	ADMUX |= (1 << REFS0);                                    //ADMUX – ADC Multiplexer Selection Register:  Use AVCC as reference (AVCC with external capacitor at AREF pin (!!!)) There are no external capacitor at AREF pin
	ADMUX |= (1 << ADLAR);                                    //ADLAR: ADC Left Adjust Result: The result is left-shifted. This enables reading only from the ADCH register, if we only need 8-bit resolution
}

uint8_t IR_read() 	                                        // A single conversion is started by writing a logical one to the ADC Start Conversion bit, ADSC. This bit stays high as long as the conversion is in progress and will be cleared by hardware when the conversion is completed
{
	ADCSRA |= (1 << ADSC);	                                  // ADSC: ADC Start Conversion. In Single Conversion mode, write this bit to one to start each conversion (p. 285)
	while(ADCSRA & (1 << ADSC));	                            // When conversion is finished, ADSC is set low by hardware. The result lands in the 10-bit register ADCH + ADCL. It is right-shifted by default, but we set it to left-shifted in init(). If the result is left adjusted and no more than 8-bit precision is required, it is sufficient to read ADCH
	return ADCH; 	                                            //ADC = (Vin * 1024) / Vref
}

uint16_t IR_readWithFilter()
{
	uint16_t sum = 0;
	uint8_t numberReadings = 4;

	for (int i = 0; i < numberReadings; i++) sum += IR_read();

	return (sum / numberReadings);
}

#include "setup.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

void exInterInit_3();
void blink();
int scale(uint8_t In, int  MaxIn, int  MinIn, int  MaxOut, int  MinOut);
int scale16(uint16_t In, int  MaxIn, int  MinIn, int  MaxOut, int  MinOut);

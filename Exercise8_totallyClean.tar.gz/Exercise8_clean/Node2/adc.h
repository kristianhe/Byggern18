#include "setup.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

void IR_init();
uint8_t IR_read();
uint16_t IR_readWithFilter();
uint8_t ADC_read(uint8_t Channel);

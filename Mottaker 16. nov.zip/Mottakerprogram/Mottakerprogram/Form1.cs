﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;          // For serial ports
using System.Threading;         // For background worker Thread.Sleep()

// Node 1: /dev/ttyS0
// Node 2: /dev/ttyACM0

// Every message from the MCUs are expected to start with '$' and end with '#'

// Every message we send to the MCUs starts with a string that explains what type of value we are sending:
// S = Solenoid, D = servo, R = DC-motor reference, C = PID controller values

namespace Mottakerprogram
{
    public delegate void MyDelegateType();  

    public partial class Form1 : Form
    {
        bool exit;

        SerialPort sPort1, sPort2;  // Serial ports for node 1 and node 2
        string message1, message2;

        string readbuffer1, readbuffer2;
        char char1, char2;

        int score;
        MyDelegateType md;          // Delegate, to update the GUI from background worker

        public Form1()
        {
            InitializeComponent();

            exit = false;
            message1 = "";
            message2 = "";
            readbuffer1 = "";
            readbuffer2 = "";
            char1 = '*';
            char2 = '*';
            sPort1 = null;
            sPort2 = null;
            score = 0;
            md = new MyDelegateType(UpdateGUIfromBW);
        }

        private void UpdateGUIfromBW()
        {
            tbScore.Text = Convert.ToString(score++);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {

            sPort1 = new SerialPort("COM4", 9600, Parity.None, 8, StopBits.Two);
            sPort2 = new SerialPort("COM3", 9600, Parity.None, 8, StopBits.Two);

            try
            {
                sPort1.Open();
                sPort2.Open();
            }
            catch (Exception ex)
            {
                sPort1 = null;
                sPort2 = null;
                MessageBox.Show("Error: " + ex.Message);
            }

            if ((sPort1 != null) && (sPort2 != null))
            {
                if ((sPort1.IsOpen) && (sPort2.IsOpen))
                {
                    btnStart.Enabled = false;
                    btnSendNode1.Enabled = true;
                    btnSendNode2.Enabled = true;
                    bwListenNode2.RunWorkerAsync(); // Run background worker (a thread)
                    bwSendNode2.RunWorkerAsync();
                }
            }
        }

        private void btnAvslutt_Click(object sender, EventArgs e)
        {
            exit = true;
            if ((sPort1 == null) && (sPort2 == null))
            {
                Application.Exit();
            }
        }

        private void btnSendNode1_Click(object sender, EventArgs e)
        {
            try
            {
                sPort1.Write(tbSendNode1.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            
        }

        private void btnSendNode2_Click(object sender, EventArgs e)
        {
            try
            {
                sPort2.Write(tbSendNode2.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            
        }

        private void bwLytteNode2_DoWork(object sender, DoWorkEventArgs e)
        {
            readbuffer2 = "";
            char2 = '*';

            // Look for the start-sign
            while (char2 != '$')
            {
                try
                {
                    char2 = Convert.ToChar(sPort2.ReadChar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            readbuffer2 = "$";

            // The message is received here, until the stop-sign is read
            while (char2 != '#')
            {
                try
                {
                    char2 = Convert.ToChar(sPort2.ReadChar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                readbuffer2 += char2;
            }
            message2 = readbuffer2;
        }

        private void bwLytteNode2_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // METODE FRA C:
            string temp = "";
            for (int i = 0; i < (message2.Length - 3); i++)
            {
                temp += message2[i + 2];
            }

            if (message2[1] == 'S')         // Solenoid
            {
                tbSolenoid.Text = temp;
            }
            else if (message2[1] == 'D')    // Servo
            {
                tbServo.Text = temp;
            }
            else if (message2[1] == 'R')    // DC-motor reference (slider)
            {
                tbSlider.Text = temp;
            }
            else if (message2[1] == 'C')    // PID-values
            {
                int posP = message2.IndexOf('P');
                string fromKp = message2.Substring(posP);
                int posI = message2.IndexOf('I');
                string fromKi = message2.Substring(posI);
                int posD = message2.IndexOf('D');
                string fromKd = message2.Substring(posD);

                string tempP = "";
                string tempI = "";
                string tempD = "";

                // $CP10I5D5#   length = 10
                // p10i5d5#     length = 8
                // i5d5#        length = 5
                // d5#          length = 3
                        

                for (int i = (message2.Length - fromKp.Length + 1); i < (message2.Length - fromKi.Length); i++)
                {
                    tempP += message2[i];
                }
                for (int i = (message2.Length - fromKi.Length + 1); i < (message2.Length - fromKd.Length); i++)
                {
                    tempI += message2[i];
                }
                for (int i = (message2.Length - fromKd.Length + 1); i < (message2.Length - 1); i++)
                {
                    tempD += message2[i];
                }

                tbKp.Text = tempP;
                tbKi.Text = tempI;
                tbKd.Text = tempD;
            }

            /*
            // METODE I C#:
            if (message2[1] == 'S')         // Solenoid
            {
                tbSolenoid.Text = message2.Substring(2, message2.Length - 3);
            }
            else if (message2[1] == 'D')    // Servo
            {
                tbServo.Text = message2.Substring(2, message2.Length - 3);
            }
            else if (message2[1] == 'R')    // DC-motor referanse (slider)
            {
                tbSlider.Text = message2.Substring(2, message2.Length - 3);
            }
            else if (message2[1] == 'C')    // PID-verdier
            {
                int posP = message2.IndexOf('P');
                int posI = message2.IndexOf('I');
                int posD = message2.IndexOf('D');

                tbKp.Text = message2.Substring(posP + 1, posI - posP - 1);
                tbKi.Text = message2.Substring(posI + 1, posD - posI - 1);
                tbKd.Text = message2.Substring(posD + 1, message2.Length - posD - 2);
            }
            */

            tbMottaNode2.Text = message2;
            if (!exit) bwListenNode2.RunWorkerAsync();  // If we want to continue, run the thread again
            else
            {
                if ((sPort2 != null) || (sPort1 != null))
                {
                    if (sPort2.IsOpen) sPort2.Close();
                    if (sPort1.IsOpen) sPort1.Close();
                }
                Application.Exit();
            }
        }

        private void bwSendeNode2_DoWork(object sender, DoWorkEventArgs e)
        {
            Thread.Sleep(1000);     // Sleep for 1 second
            try
            {
                //sPort2.Write("$score" + score + "#");
                this.Invoke(md);    // Invoke delegate to update the GUI (score) (cant be done from backgroundworker)
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void bwSendeNode2_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!exit) bwSendNode2.RunWorkerAsync();  // If we havent pressed exit, run the thread again
            else
            {
                if ((sPort2 != null) || (sPort1 != null))
                {
                    if (sPort2.IsOpen) sPort2.Close();
                    if (sPort1.IsOpen) sPort1.Close();
                }
                Application.Exit();
            }
        }
    }
}

﻿namespace Mottakerprogram
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbMottaNode1 = new System.Windows.Forms.TextBox();
            this.tbSendNode1 = new System.Windows.Forms.TextBox();
            this.tbSendNode2 = new System.Windows.Forms.TextBox();
            this.tbMottaNode2 = new System.Windows.Forms.TextBox();
            this.btnSendNode1 = new System.Windows.Forms.Button();
            this.btnSendNode2 = new System.Windows.Forms.Button();
            this.tbSlider = new System.Windows.Forms.TextBox();
            this.tbServo = new System.Windows.Forms.TextBox();
            this.tbSolenoid = new System.Windows.Forms.TextBox();
            this.lblServo = new System.Windows.Forms.Label();
            this.lblSkyt = new System.Windows.Forms.Label();
            this.lblSliderValue = new System.Windows.Forms.Label();
            this.tbKd = new System.Windows.Forms.TextBox();
            this.tbKp = new System.Windows.Forms.TextBox();
            this.lblKd = new System.Windows.Forms.Label();
            this.tbKi = new System.Windows.Forms.TextBox();
            this.lblKi = new System.Windows.Forms.Label();
            this.lblKp = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.tbScore = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnAvslutt = new System.Windows.Forms.Button();
            this.bwListenNode2 = new System.ComponentModel.BackgroundWorker();
            this.bwSendNode2 = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // tbMottaNode1
            // 
            this.tbMottaNode1.Location = new System.Drawing.Point(25, 53);
            this.tbMottaNode1.Multiline = true;
            this.tbMottaNode1.Name = "tbMottaNode1";
            this.tbMottaNode1.ReadOnly = true;
            this.tbMottaNode1.Size = new System.Drawing.Size(239, 297);
            this.tbMottaNode1.TabIndex = 0;
            // 
            // tbSendNode1
            // 
            this.tbSendNode1.Location = new System.Drawing.Point(25, 373);
            this.tbSendNode1.Name = "tbSendNode1";
            this.tbSendNode1.Size = new System.Drawing.Size(239, 22);
            this.tbSendNode1.TabIndex = 2;
            // 
            // tbSendNode2
            // 
            this.tbSendNode2.Location = new System.Drawing.Point(294, 373);
            this.tbSendNode2.Name = "tbSendNode2";
            this.tbSendNode2.Size = new System.Drawing.Size(239, 22);
            this.tbSendNode2.TabIndex = 4;
            // 
            // tbMottaNode2
            // 
            this.tbMottaNode2.Location = new System.Drawing.Point(294, 53);
            this.tbMottaNode2.Multiline = true;
            this.tbMottaNode2.Name = "tbMottaNode2";
            this.tbMottaNode2.ReadOnly = true;
            this.tbMottaNode2.Size = new System.Drawing.Size(239, 297);
            this.tbMottaNode2.TabIndex = 3;
            // 
            // btnSendNode1
            // 
            this.btnSendNode1.Enabled = false;
            this.btnSendNode1.Location = new System.Drawing.Point(25, 401);
            this.btnSendNode1.Name = "btnSendNode1";
            this.btnSendNode1.Size = new System.Drawing.Size(127, 40);
            this.btnSendNode1.TabIndex = 5;
            this.btnSendNode1.Text = "Send Node 1";
            this.btnSendNode1.UseVisualStyleBackColor = true;
            this.btnSendNode1.Click += new System.EventHandler(this.btnSendNode1_Click);
            // 
            // btnSendNode2
            // 
            this.btnSendNode2.Enabled = false;
            this.btnSendNode2.Location = new System.Drawing.Point(294, 401);
            this.btnSendNode2.Name = "btnSendNode2";
            this.btnSendNode2.Size = new System.Drawing.Size(123, 40);
            this.btnSendNode2.TabIndex = 6;
            this.btnSendNode2.Text = "Send Node 2";
            this.btnSendNode2.UseVisualStyleBackColor = true;
            this.btnSendNode2.Click += new System.EventHandler(this.btnSendNode2_Click);
            // 
            // tbSlider
            // 
            this.tbSlider.Location = new System.Drawing.Point(688, 168);
            this.tbSlider.Name = "tbSlider";
            this.tbSlider.Size = new System.Drawing.Size(100, 22);
            this.tbSlider.TabIndex = 7;
            // 
            // tbServo
            // 
            this.tbServo.Location = new System.Drawing.Point(688, 207);
            this.tbServo.Name = "tbServo";
            this.tbServo.Size = new System.Drawing.Size(100, 22);
            this.tbServo.TabIndex = 8;
            // 
            // tbSolenoid
            // 
            this.tbSolenoid.Location = new System.Drawing.Point(688, 247);
            this.tbSolenoid.Name = "tbSolenoid";
            this.tbSolenoid.Size = new System.Drawing.Size(100, 22);
            this.tbSolenoid.TabIndex = 9;
            // 
            // lblServo
            // 
            this.lblServo.AutoSize = true;
            this.lblServo.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServo.Location = new System.Drawing.Point(633, 207);
            this.lblServo.Name = "lblServo";
            this.lblServo.Size = new System.Drawing.Size(49, 20);
            this.lblServo.TabIndex = 26;
            this.lblServo.Text = "Servo:";
            // 
            // lblSkyt
            // 
            this.lblSkyt.AutoSize = true;
            this.lblSkyt.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSkyt.Location = new System.Drawing.Point(610, 247);
            this.lblSkyt.Name = "lblSkyt";
            this.lblSkyt.Size = new System.Drawing.Size(72, 20);
            this.lblSkyt.TabIndex = 25;
            this.lblSkyt.Text = "Solenoid:";
            // 
            // lblSliderValue
            // 
            this.lblSliderValue.AutoSize = true;
            this.lblSliderValue.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSliderValue.Location = new System.Drawing.Point(592, 170);
            this.lblSliderValue.Name = "lblSliderValue";
            this.lblSliderValue.Size = new System.Drawing.Size(90, 20);
            this.lblSliderValue.TabIndex = 24;
            this.lblSliderValue.Text = "Slider value:";
            // 
            // tbKd
            // 
            this.tbKd.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKd.Location = new System.Drawing.Point(688, 403);
            this.tbKd.Name = "tbKd";
            this.tbKd.Size = new System.Drawing.Size(100, 27);
            this.tbKd.TabIndex = 29;
            this.tbKd.Text = "2";
            this.tbKd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbKp
            // 
            this.tbKp.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKp.Location = new System.Drawing.Point(688, 325);
            this.tbKp.MaxLength = 2;
            this.tbKp.Name = "tbKp";
            this.tbKp.Size = new System.Drawing.Size(100, 27);
            this.tbKp.TabIndex = 27;
            this.tbKp.Text = "1";
            this.tbKp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblKd
            // 
            this.lblKd.AutoSize = true;
            this.lblKd.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKd.Location = new System.Drawing.Point(647, 406);
            this.lblKd.Name = "lblKd";
            this.lblKd.Size = new System.Drawing.Size(30, 20);
            this.lblKd.TabIndex = 32;
            this.lblKd.Text = "Kd:";
            // 
            // tbKi
            // 
            this.tbKi.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKi.Location = new System.Drawing.Point(688, 364);
            this.tbKi.Name = "tbKi";
            this.tbKi.Size = new System.Drawing.Size(100, 27);
            this.tbKi.TabIndex = 28;
            this.tbKi.Text = "0";
            this.tbKi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblKi
            // 
            this.lblKi.AutoSize = true;
            this.lblKi.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKi.Location = new System.Drawing.Point(652, 367);
            this.lblKi.Name = "lblKi";
            this.lblKi.Size = new System.Drawing.Size(25, 20);
            this.lblKi.TabIndex = 31;
            this.lblKi.Text = "Ki:";
            // 
            // lblKp
            // 
            this.lblKp.AutoSize = true;
            this.lblKp.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKp.Location = new System.Drawing.Point(647, 326);
            this.lblKp.Name = "lblKp";
            this.lblKp.Size = new System.Drawing.Size(30, 20);
            this.lblKp.TabIndex = 30;
            this.lblKp.Text = "Kp:";
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.Location = new System.Drawing.Point(707, 27);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(49, 20);
            this.lblScore.TabIndex = 34;
            this.lblScore.Text = "Score:";
            // 
            // tbScore
            // 
            this.tbScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbScore.Location = new System.Drawing.Point(674, 53);
            this.tbScore.Multiline = true;
            this.tbScore.Name = "tbScore";
            this.tbScore.ReadOnly = true;
            this.tbScore.Size = new System.Drawing.Size(124, 56);
            this.tbScore.TabIndex = 33;
            this.tbScore.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft NeoGothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(101, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 22);
            this.label1.TabIndex = 35;
            this.label1.Text = "Node 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft NeoGothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(381, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 22);
            this.label2.TabIndex = 36;
            this.label2.Text = "Node 2";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(25, 502);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(100, 40);
            this.btnStart.TabIndex = 37;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnAvslutt
            // 
            this.btnAvslutt.Location = new System.Drawing.Point(131, 502);
            this.btnAvslutt.Name = "btnAvslutt";
            this.btnAvslutt.Size = new System.Drawing.Size(100, 40);
            this.btnAvslutt.TabIndex = 38;
            this.btnAvslutt.Text = "Avslutt";
            this.btnAvslutt.UseVisualStyleBackColor = true;
            this.btnAvslutt.Click += new System.EventHandler(this.btnAvslutt_Click);
            // 
            // bwListenNode2
            // 
            this.bwListenNode2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bwLytteNode2_DoWork);
            this.bwListenNode2.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bwLytteNode2_RunWorkerCompleted);
            // 
            // bwSendNode2
            // 
            this.bwSendNode2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bwSendeNode2_DoWork);
            this.bwSendNode2.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bwSendeNode2_RunWorkerCompleted);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 583);
            this.Controls.Add(this.btnAvslutt);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.tbScore);
            this.Controls.Add(this.tbKd);
            this.Controls.Add(this.tbKp);
            this.Controls.Add(this.lblKd);
            this.Controls.Add(this.tbKi);
            this.Controls.Add(this.lblKi);
            this.Controls.Add(this.lblKp);
            this.Controls.Add(this.lblServo);
            this.Controls.Add(this.lblSkyt);
            this.Controls.Add(this.lblSliderValue);
            this.Controls.Add(this.tbSolenoid);
            this.Controls.Add(this.tbServo);
            this.Controls.Add(this.tbSlider);
            this.Controls.Add(this.btnSendNode2);
            this.Controls.Add(this.btnSendNode1);
            this.Controls.Add(this.tbSendNode2);
            this.Controls.Add(this.tbMottaNode2);
            this.Controls.Add(this.tbSendNode1);
            this.Controls.Add(this.tbMottaNode1);
            this.Name = "Form1";
            this.Text = "Mikrokontroller simulator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbMottaNode1;
        private System.Windows.Forms.TextBox tbSendNode1;
        private System.Windows.Forms.TextBox tbSendNode2;
        private System.Windows.Forms.TextBox tbMottaNode2;
        private System.Windows.Forms.Button btnSendNode1;
        private System.Windows.Forms.Button btnSendNode2;
        private System.Windows.Forms.TextBox tbSlider;
        private System.Windows.Forms.TextBox tbServo;
        private System.Windows.Forms.TextBox tbSolenoid;
        private System.Windows.Forms.Label lblServo;
        private System.Windows.Forms.Label lblSkyt;
        private System.Windows.Forms.Label lblSliderValue;
        private System.Windows.Forms.TextBox tbKd;
        private System.Windows.Forms.TextBox tbKp;
        private System.Windows.Forms.Label lblKd;
        private System.Windows.Forms.TextBox tbKi;
        private System.Windows.Forms.Label lblKi;
        private System.Windows.Forms.Label lblKp;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.TextBox tbScore;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnAvslutt;
        private System.ComponentModel.BackgroundWorker bwListenNode2;
        private System.ComponentModel.BackgroundWorker bwSendNode2;
    }
}


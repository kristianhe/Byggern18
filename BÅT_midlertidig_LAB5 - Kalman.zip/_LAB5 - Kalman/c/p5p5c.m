                    %% NOMOTO CNSTANTS FROM 5.1 %%
K = 0.169;
T = 72.63; 
                    %% VARIABLES FROM 5.2 %%
load wave.mat
fs = 10;
window = 4096;

%Estimate PSD
[pxx,f] = pwelch(psi_w(2,:)*(1/2*pi),window,[],[],fs*(2*pi));

%Resonance frequency
[pxxMax, ind] = max(pxx); %ser ut til at "intensity" er lik maksverdien til pxx
w_0 = f(ind);
std_div = sqrt(pxxMax); 

lambda = 0.08; % Funnet i p5p2
K_w = 2*lambda*w_0*std_div;


                    %% MATRIXES FROM 5.4a %%
A = [0          1               0   0      0;
     (-w_0^2) (-2*lambda*w_0)   0   0      0; 
     0          0               0   1      0; 
     0          0               0   -(1/T) -(K/T); 
     0          0               0   0      0        ];
 B = [  0; 
        0; 
        0; 
        K/T; 
        0     ];
C = [0 1 1 0 0];
D = 0;
E = [0   0; 
     K_w 0; 
     0   0; 
     0   0; 
     0   1];
 
                    %% 5.5a - Discretization %%
                    
[Ad, Bd] = c2d(A, B, 0.1);  % Sample frequency = 10 Hz => Sample interval Ts = 1/10 = 0.1
[Ad, Ed] = c2d(A, B, 0.1);
Cd = C;
Dd = D;


                    %% 5.5b - Estimate of the variance %%

noise = load("compass_course_noise");

estimate_var_noise = var(noise.ans(2, :)*pi/180) % noise is in deg, so converts to rad via pi/180
                  
 

                    %% 5.5c - Implementation of the discrete Kalman-filter %%
                    
R = estimate_var_noise / 0.1;   % Sample frequency = 10 Hz => Sample interval Ts = 1/10 = 0.1
Q = [ 30 0; 
      0 10e-6 ];
P_0 = [ 1 0      0    0 0; 
        0 0.013  0    0 0; 
        0 0      pi^2 0 0; 
        0 0      0    1 0; 
        0 0      0    0 2.5*10e-4 ];
xHat_0 = [ 0; 
           0; 
           0; 
           0; 
           0 ];

matrices = struct('Ad', Ad, 'Bd', Bd, 'Cd', Cd, 'Ed', Ed, 'R', R, 'Q', Q, 'P_0', P_0, 'xHat_0', xHat_0);

                    
                    
function [heading_est, bias_est] = Kalman(compass_measured, rudder_input)

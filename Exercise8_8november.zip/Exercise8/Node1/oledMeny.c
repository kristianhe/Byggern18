#include "oledMeny.h"

uint8_t rowLenght = 3;
uint8_t menuPosition;
uint8_t menuNr, menuSW;

uint8_t menSelc;

char *meny[4][1] = {{(char *)("Play")}, {(char *)("Options")}, {(char *)("Score")}, {(char *)("Exit")}};                            //menu nr 1
char *menyOptions[4][1] = {{(char *)("Difficulty")},{(char *)("Font")}, {(char *)("Sound")}, {(char *)("Back")}};                   //menu nr 2
char *menyPlay[5][1] = {{(char *)("Easy")}, {(char *)("Medium")}, {(char *)("Hard")}, {(char *)("Nightmare")}, {(char *)("Back")}}; //menu nr 3
char *menyScore[1][1] = {{(char *)("Back")}};                                                                                       //menu nr 4


void menuInit()
{
  menuSetPosition(0);  // Setter menyposisjonen til 0 (første element) og printer menyen
  menSelc = 0;
  menuNr = 0;
  menuSW = 0;
}

void menuEnter()
{

  menSelc = menuPosition;
  menuPosition = 0;

  switch (menuSW) {
    case 0:

      if (menSelc == 0) menuNr = 0;
      else if (menSelc == 1) menuNr = 1; //go to option, meny -> option
      else if (menSelc == 2) menuNr = 3; //go to Score ------- går nå bare til Back meny -> Score -> Back -> meny
      else if (menSelc == 3) menuNr = 0;
      printf("%d\n",menSelc);
      printf("%d\n",menuNr);
      break;

    case 1:

      if (menSelc == 0) menuNr = 2; //Difficulty
      else if (menSelc == 1) menuNr = 3; //go to Font ------- går nå bare til Back
      else if (menSelc == 2) menuNr = 3; //go to sound ------- går nå bare til Back
      else if (menSelc == 3) menuNr = 0; //go to meny
      printf("%d\n",menSelc);
      printf("%d\n",menuNr);
      break;

    case 2:

      if (menSelc == 0) menuNr = 3; // meny -> optin -> Difficulty -> back -> meny
      else if (menSelc == 1) menuNr = 3; // meny -> optin -> Difficulty -> back -> meny
      else if (menSelc == 2) menuNr = 3; // meny -> optin -> Difficulty -> back -> meny
      else if (menSelc == 3) menuNr = 3; // meny -> optin -> Difficulty -> back -> meny
      else if (menSelc == 4) menuNr = 0;
      printf("%d\n",menSelc);
      printf("%d\n",menuNr);
      break;

    case 3:
      menuNr = 0;
      printf("%d\n",menSelc);
      printf("%d\n",menuNr);
      break;
    default:
      break;
  }

  printMenu();
}

void printMenu()
{
  oled_clear_all(); // Clearer hele OLEDen.

  switch (menuNr) {
		case 0:
      rowLenght = 3;
      for(uint8_t i = 0; i < (rowLenght+1); i++)
      {
        if (i == menuPosition)oled_print_page_mode(i, 8, meny[i][0]);
        else oled_print_page_mode(i, 0, meny[i][0]);
      }
      menuSW = 0;
			break;
    case 1:
        rowLenght = 3;
        for(uint8_t i = 0; i < (rowLenght+1); i++)
        {
          if (i == menuPosition)oled_print_page_mode(i, 8, menyOptions[i][0]);
          else oled_print_page_mode(i, 0, menyOptions[i][0]);
        }
        menuSW = 1;
  		  break;
		case 2:
      rowLenght = 4;
      for(uint8_t i = 0; i < (rowLenght+1); i++)
      {
        if (i == menuPosition)oled_print_page_mode(i, 8, menyPlay[i][0]);
        else oled_print_page_mode(i, 0, menyPlay[i][0]);
      }
      menuSW = 2;
			break;
    case 3:
      rowLenght = 0;
      for(uint8_t i = 0; i < (rowLenght+1); i++)
      {
        oled_print_page_mode(i, 0, menyScore[i][0]);
      }
      menuSW = 3;
  		break;
    default:
      break;
	}
}

void menuSetPosition(uint8_t position)
{
  if ((position >= 0) && (position <= rowLenght))
  {
    menuPosition = position;
    printMenu();
  }
}

void menuIncrementPosition()
{
  if (menuPosition < rowLenght) menuPosition++;
  else menuPosition = 0;
  menuSetPosition(menuPosition);
}

void menuDecrementPosition()
{
  if (menuPosition > 0) menuPosition--;
  else menuPosition = rowLenght;
  menuSetPosition(menuPosition);
}

uint8_t menuGetPosition()
{
  return menuPosition;
}

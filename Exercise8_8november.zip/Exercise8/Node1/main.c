
#include "setup.h"
#include "uart.h"
#include "memory.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "oled.h"
#include "oledMeny.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

bool Deltime0 = false;
bool Deltime1 = false;
bool flagMenu = false;
bool Button = false;

uint8_t slidL;
uint8_t slidR;
uint8_t buttonL;
uint8_t buttonR;
uint16_t counter = 0;
uint16_t tellerMenu = 0;

Joystick_Position joyPos;
Joystick_Direction joyDir;
Slider_Position sliPos;

ISR(TIMER0_OVF_vect){

}

ISR(TIMER1_OVF_vect){
	Deltime1 ^= true;
}

ISR(INT0_vect){
	Button = true;
}
bool timerDelay() //interupt-basert delayfunksjon på 500 ms
{
	if(Deltime1){
		Deltime1 = false;
		return true;
	}
	else{return false;}
}


void drivers(){
	exInterInit_0();
	timer1_init();
	timer0_init();
	XMEM_Init();
	UART_Init(MYUBRR);
	Joystick_Init();
	oled_init();
	menuInit();

	canInit();
	//loopbackInit();
}

int main(void){
	drivers();
	DDRB |= (1<<PB0);



	CAN_frame TXtest;
	CAN_frame RXtest;

	TXtest.id = 5;
	TXtest.length = 4;
	TXtest.data[0] = 1; //x pos
	TXtest.data[1] = 2; //y pos
	TXtest.data[2] = 3; //x -dir
	TXtest.data[3] = 4; //Button

	joyPos = Joystick_getPosition();
	joyDir = Joystick_getDirection();

	printf("Node 1 opertional\n");
	sei();
	while(1)
	{
		joyPos = Joystick_getPosition();
		joyDir = Joystick_getDirection();

		//printf("Joy.x = %d\n", joyPos.x);
		printf("%d\n", Slider_getRightButton());

		TXtest.data[0] = joyPos.x;
		TXtest.data[1] = joyPos.y;
		TXtest.data[2] = joyDir;

		canTransmit(TXtest);

		if (Button)
		{
			TXtest.data[3] = 255;
			Button = false;
		}
		else TXtest.data[3] = 1;
	}
	return 0;
}

/*
joyPos = Joystick_getPosition();
joyDir = Joystick_getDirection();
sliPos = Slider_getPosition();
buttonL = Slider_getLeftButton();
buttonR = Slider_getRightButton();
*/

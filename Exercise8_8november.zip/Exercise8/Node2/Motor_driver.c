#include "Motor_driver.h"

void MotorInit()
{
  TWI_Master_Initialise();

	// Setter alle portene vi vil bruke til motorstyring som outputs (MJ1)
	DDRH |= (1 << OE) | (1 << RST) | (1 << SEL) | (1 << EN) | (1 << DIR);
	// Setter alle portene vi vil bruke til lesing av enkoderen til inputs (MJ2)
	DDRK = 0;
	PORTH |= (1 << EN);		// Enable motor
	PORTH &= ~(1 << OE);	// Output enable (encoder) (active low)
	Encoder_Reset();		// Reset encoder
}

void MotorContrl(int direc, uint8_t speed)
{
	// Setter retningen til motoren etter fortegn på ønsket motorspenning

  if (direc == 4) DAC_Write(0);

  else if (direc == 1) {
    PORTH |= (1 << DIR);
    DAC_Write((speed - 129));
    printf("VOLT: %d\n", (speed - 129));
  }
  else if (direc == 0) {
    PORTH &= ~(1 << DIR);
    DAC_Write((129 - speed));
    printf("VOLT: %d\n", (129 - speed));
  }
}

void Encoder_Reset()
{
	// Toggle !RST to reset encoder
	PORTH &= ~(1 << RST);		// Reset encoder (active low)
	_delay_ms(10);				// Wait
	PORTH |= (1 << RST);		// Toggle back
}


uint16_t EncoderRead()
{
  //PORTH &= ~(1 << OE);	// Output enable (encoder) (active low)
	PORTH &= ~(1 << SEL);		// Setter SEL lav for å få de høye bittene
	_delay_us(30);				// Vent ~20 mikrosekunder
	uint8_t encoderH = PINK;		// Leser de høyeste bittene
	PORTH |= (1 << SEL);		// Setter SEL høy for å få de lave bittene
	_delay_us(30);				// Vent ~20 mikrosekunder
	uint8_t encoderL = PINK;		// Leser de laveste bittene
	//Encoder_Reset();			// Resetter enkoderen
  //PORTH |= (1 << OE);	// Output disable (encoder) (active low)

  // This 16-bit counter uses two’s complement form to represent negative numbers.??????
  uint16_t res = (encoderH << 8) | (encoderL);
  return res;
}

#include "DAC_driver.h"

// Skriver fra MCU til DAC-IC (MAX520) vha I2C/TWI-bussen. Vi styrer motorspenning med utgangen til DACen.
void DAC_Write(uint8_t motorVoltage)
{
	uint8_t data[3];

	data[0] = 0x50;			// Slave adress byte (uendret, de første 0101 er fabrikk-kodet. Resten er 0000).
	// data[0] = 0x00;		// Prøv begge deler. Skal gi det samme, siden 0101 er fabrikk-kodet.
	data[1] = 0x00;			// Command byte (ikke gjør noe, vi skal bare sette DAC-outputs)
	data[2] = motorVoltage;	// Output byte

  TWI_Start_Transceiver_With_Data(data, 3);	// 3 er meldingslengden. Logikk for START og STOPP skjer i denne funksjonen

}

#include "setup.h"
#include "timer.h"
#include "util.h"
#include "TWI_Master.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

/*
#define OE PF3
#define RST PF4
#define SEL PF5
#define EN PF6
#define DIR PF7
*/
#define OE PH5
#define RST PH6
#define SEL PH3
#define EN PH4
#define DIR PH1

void MotorInit();
void MotorContrl(int direc, uint8_t speed);
void Encoder_Reset();
uint16_t EncoderRead();

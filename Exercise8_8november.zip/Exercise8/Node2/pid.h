#include "setup.h"
#include "util.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define SCALING_FACTOR  128

typedef struct PID_DATA{
  int32_t sumError;
  int16_t Kp;
  int16_t Ki;
} pidData_t;

void pid_Init(int16_t Kp, int16_t Ki, struct PID_DATA *pid);
int16_t pid_Controller(int16_t setPoint, int16_t processValue, struct PID_DATA *pid_st);
void pid_Reset_Integrator(pidData_t *pid_st);

#include "pid.h"

void pid_Init(int16_t Kp_in, int16_t Ki_in, struct PID_DATA *pid)
{
  pid->sumError = 0;
  pid->Kp = Kp_in;
  pid->Ki = Ki_in;
}

int16_t pid_Controller(int16_t setPoint, int16_t processValue, struct PID_DATA *pid_st)
{
  int16_t error, p;
  int32_t i, ret;

  error = setPoint - processValue;
  pid_st->sumError += error;

  p = pid_st->Kp * error;
  i = pid_st->Ki * pid_st->sumError;

  return((int16_t)((p + i) / SCALING_FACTOR));
}

void pid_Reset_Integrator(pidData_t *pid_st)
{
  pid_st->sumError = 0;
}

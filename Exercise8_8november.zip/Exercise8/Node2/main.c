
#include "setup.h"
#include "uart.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"
#include "timer.h"
#include "pid.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

// PI
#define K_P   1.00
#define K_I 	0.00
#define TIME_INTERVAL 157
struct PID_DATA pidData;

bool Deltime = false;
bool INTflag = false;

uint8_t counter = 0;
uint16_t maxEncoder = 255;

uint8_t time_interval = 0;

ISR(TIMER0_OVF_vect){
	counter++;
	time_interval++;
}

ISR(TIMER1_OVF_vect){
}

void drivers(){
	//loopbackInit();
	UART_Init(MYUBRR);
	PWM_init();
	timer0_init();
	timer1_init();

	canInit();
	IR_Init();

	MotorInit();
	pid_Init(K_P * SCALING_FACTOR, K_I * SCALING_FACTOR, &pidData);
}


//MotorDir(int motorVoltage);
//MotorSpeed(uint8_t speed);
//EncoderRead();

int main(void)
{
	DDRE |= (1<<PE4);

	drivers();

	uint8_t servo_val = 0;
	uint8_t motor_val = 0;
	uint8_t solenoid = 0;
	uint8_t dirval = 0;
	uint8_t IR_value = 255;
	int16_t referenceValue = 0;
	int16_t measurementValue = 0;
	int16_t inputValue = 0;
	int16_t biggestEncoder = 0;
	int16_t lowestEncoder  = 0;


	uint8_t score = 0;
	bool scoreFlag = false;
	bool setflag = false;
	bool scount = false;
	bool pidflag = false;

	CAN_frame RXtest;
	RXtest.id = 0;
	RXtest.length = 4;
	RXtest.data[0] = 128; //x-pos
	RXtest.data[1] = 128; 	//y-pos
	RXtest.data[2] = 4; 	//x-dir
	RXtest.data[3] = 0; 	//solenoid

	printf("Node 2 opertional\n");
	sei();
	while(1)
	{
		if (canRecive(&RXtest))
		{
			motor_val = RXtest.data[0];
			servo_val = RXtest.data[1];
			dirval =  RXtest.data[2];
			solenoid = RXtest.data[3];
		}

		//printf("dirval %d\n", dirval);
		OCR3A = Scale(servo_val, 255,0, 4600, 1800);
		IR_value = IR_Read_withFilter();

		if (solenoid > 240){
			setflag = true;
		}

		if (setflag){
			printf("jalla\n");
			PORTE |= (1<<PE4);
			setflag = false;
			scount = true;
			counter = 0;
		}
		if ((scount) && (counter > 10)){
			printf("not jalla\n");
			PORTE &= ~(1<<PE4);
			scount = false;
			counter = 0;
		}

		MotorContrl(dirval, referenceValue);	// Leser bare inn verdi fra joystick

		// Run PID calculations once every PID timer timeout
    if(time_interval > 2)
    {
			//printf("jalla\n");

      referenceValue = motor_val;		// Hent joystickverdi: ØNSKET HASTIGHET
      measurementValue = EncoderRead();		// Hent enkoderverdi

			/*
			if (measurementValue >= maxEncoder)
			{
				measurementValue = maxEncoder;
			}
			else if (measurementValue < 0)
			{
				measurementValue = 0;
			}
			*/

      inputValue = pid_Controller(referenceValue, measurementValue, &pidData);
			//printf("SPEED_WANT:    %d\n", referenceValue);
			//printf("SPEED_READ:    %d\n", measurementValue);
			//printf("SPEED_RESULT:  %d\n", inputValue);
			//printf("\n\n");
      //MotorContrl(dirval, inputValue);					// Send verdi til motoren

			time_interval = 0;
		}
	}

	return 0;
}

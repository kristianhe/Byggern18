
#include "setup.h"
#include "uart.h"
#include "memory.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "oled.h"
#include "oledMeny.h"


#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

uint8_t slidL;
uint8_t slidR;
uint8_t buttonL;
uint8_t buttonR;
uint8_t counter = 0;
uint16_t tellerMenu = 0;

bool flagMenu = false;

Joystick_Position joyPos;
Joystick_Direction joyDir;
Slider_Position sliPos;


int main(void){
	char i = 0;
	DDRB |= (1<<PB0);
	sei();

	UART_Init(MYUBRR);
	XMEM_Init();
	Joystick_Init();
	oled_init();
	timer1_init();
	//exInterInit();
	menuInit();

	blink();
	printf("Init finished!\n\r");
	printf("Starter time\n");
	while(1)
	{
		joyDir = Joystick_getDirection();

		if (joyDir == 2) // UP
		{
			if ((flagMenu == false) || (tellerMenu == 500))
			{
				menuDecrementPosition();
				flagMenu = true;
				tellerMenu = 0;
			}
			else
			{
				tellerMenu++;
			}
		}
		else if (joyDir == 3) // DOWN
		{
			if ((flagMenu == false) || (tellerMenu == 500))
			{
				menuIncrementPosition();
				flagMenu = true;
				tellerMenu = 0;
			}
			else
			{
				tellerMenu++;
			}
		}
		else if (joyDir == 4)	// NEUTRAL
		{
			if (timerDelay()){
				flagMenu = false;
			}
		}

		if (Joystick_GetButton() == 0)
		{
			_delay_ms(150);
			menuEnter();
		}

	}
	return 0;
}
/*
joyPos = Joystick_getPosition();
joyDir = Joystick_getDirection();
sliPos = Slider_getPosition();
buttonL = Slider_getLeftButton();
buttonR = Slider_getRightButton();

printf("x: %d \n", joyPos.x);
printf("Y: %d \n", joyPos.y);

printf("Direction: %d \n", joyDir);

printf("Slider_L: %d \n", sliPos.left);
printf("Slider_R: %d \n", sliPos.right);

printf("Button_L: %d \n", buttonL);
printf("Button_R: %d \n", buttonR);
*/

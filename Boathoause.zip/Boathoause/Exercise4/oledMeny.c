#include "oledMeny.h"

uint8_t rowLenght = 3;
uint8_t menuPosition;
uint8_t menuNr = 0;
char *meny[4][1] = {{(char *)("Play")}, {(char *)("Options")}, {(char *)("Score")}, {(char *)("Exit")}};
char *menyPlay[5][1] = {{(char *)("Easy")}, {(char *)("Medium")}, {(char *)("Hard")}, {(char *)("Nightmare")}, {(char *)("Back")}};
char *menyOptions[3][1] = {{(char *)("Font")}, {(char *)("Sound")}, {(char *)("Back")}};
char *menyScore[1][1] = {{(char *)("Back")}};


void menuInit()
{
  menuSetPosition(0);  // Setter menyposisjonen til 0 (første element) og printer menyen
}

void menuEnter()
{
  menuNr = menuPosition;
  menuPosition = 0;
  printMenu();
}

void printMenu()
{
  oled_clear_all(); // Clearer hele OLEDen.

  switch (menuNr) {
		case 0:
      rowLenght = 3;
      for(uint8_t i = 0; i < (rowLenght+1); i++)
      {
        if (i == menuPosition)oled_print_page_mode(i, 8, meny[i][0]);
        else oled_print_page_mode(i, 0, meny[i][0]);
      }
			break;
		case 1:
      rowLenght = 4;
      for(uint8_t i = 0; i < (rowLenght+1); i++)
      {
        if (i == menuPosition)oled_print_page_mode(i, 8, menyPlay[i][0]);
        else oled_print_page_mode(i, 0, menyPlay[i][0]);
      }
			break;
		case 2:
      rowLenght = 2;
      for(uint8_t i = 0; i < (rowLenght+1); i++)
      {
        if (i == menuPosition)oled_print_page_mode(i, 8, menyOptions[i][0]);
        else oled_print_page_mode(i, 0, menyOptions[i][0]);
      }
		  break;
    case 3:
      rowLenght = 0;
      for(uint8_t i = 0; i < (rowLenght+1); i++)
      {
        if (i == menuPosition)oled_print_page_mode(i, 8, menyScore[i][0]);
        else oled_print_page_mode(i, 0, menyScore[i][0]);
      }
  		break;
    default:
      break;
	}



}

void menuSetMenu()
{

}

void menuSetPosition(uint8_t position)
{
  if ((position >= 0) && (position <= rowLenght))
  {
    menuPosition = position;
    printMenu();
  }
}

void menuIncrementPosition()
{
  if (menuPosition < rowLenght) menuPosition++;
  else menuPosition = 0;
  menuSetPosition(menuPosition);
}

void menuDecrementPosition()
{
  if (menuPosition > 0) menuPosition--;
  else menuPosition = rowLenght;
  menuSetPosition(menuPosition);
}

uint8_t menuGetPosition()
{
  return menuPosition;
}

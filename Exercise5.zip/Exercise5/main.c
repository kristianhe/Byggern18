
#include "setup.h"
#include "uart.h"
#include "memory.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "oled.h"
#include "oledMeny.h"
#include "spi.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

bool Deltime = false;
bool flagMenu = false;
bool Button = false;

uint8_t slidL;
uint8_t slidR;
uint8_t buttonL;
uint8_t buttonR;
uint8_t counter = 0;
uint16_t tellerMenu = 0;

Joystick_Position joyPos;
Joystick_Direction joyDir;
Slider_Position sliPos;

ISR(TIMER1_OVF_vect){
	Deltime ^= true;
}

ISR(INT0_vect){
	Button = true;
}

bool timerDelay() //interupt-basert delayfunksjon på 500 ms
{
	if(Deltime){
		Deltime = false;
		return true;
	}
	else{return false;}
}

/*
joyPos = Joystick_getPosition();
joyDir = Joystick_getDirection();
sliPos = Slider_getPosition();
buttonL = Slider_getLeftButton();
buttonR = Slider_getRightButton();
*/

int main(void){
	DDRB |= (1<<PB0);

	uint8_t jalla = 42;
	uint8_t boathoase;

	UART_Init(MYUBRR);
	XMEM_Init();
	Joystick_Init();
	oled_init();
	timer1_init();
	menuInit();
	exInterInit_0();
	spi_init();

	sei();

	printf("Boathoase finished d!\n");
	while(1)
	{

		_delay_ms(250);
		chipSelect(true);
		spiWrite(jalla);
		_delay_ms(250);
		boathoase = spiRead();
		printf("%d\n", boathoase);
		chipSelect(false);

		/*
		joyDir = Joystick_getDirection();
		if(timerDelay()){counter++;}

		if ((joyDir == 2) && ((flagMenu == false) || (counter > 2))) // UP
		{
			menuDecrementPosition();
			flagMenu = true;
			counter = 0;
		}
		else if ((joyDir == 3) && ((flagMenu == false) || (counter > 2))) // DOWN
		{
			menuIncrementPosition();
			flagMenu = true;
			counter = 0;
		}
		else if (joyDir == 4)	// NEUTRAL
		{
			if (timerDelay()){flagMenu = false;}
		}

		if (Button)
		{
			printf("Go to boathoase\n");
			menuEnter();
			Button = false;
		}
		*/
	}
	return 0;
}

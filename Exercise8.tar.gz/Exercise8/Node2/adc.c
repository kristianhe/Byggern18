#include "adc.h"

uint8_t ADC_Read(uint8_t Channel)
{
  volatile char *dataADC = (char*) adADC;

  if (Channel > 3) return 0;
  *dataADC = (0x04 | Channel);
  _delay_us(50);
  return *dataADC;
}

void IR_Init()
{
  // ADCSRA – ADC Control and Status Register A (s. 285)
	// Les inn verdien fra IR-sensor på port F0
	DDRF &= ~(1 << PF0);	// Setter PF0 til input
	ADCSRA |= (1 << ADEN);// Enable ADC.  Mux = 0000000 - Bruker ADC0
	ADCSRA |= (1 << ADPS2) || (1 << ADPS1) || (1 << ADPS0); //ADC må ha en arbeidsfrekvens på mellom 50kHz til 200kHz: Division factor / prescale = 128.  - arbeidsfrekvens = 16mHz/128 = 125kHz
	ADMUX |= (1 << REFS0); // ADMUX – ADC Multiplexer Selection Register:  Bruker AVCC som referanse		(AVCC with external capacitor at AREF pin (!!!)) There are no external capacitor at AREF pin
	ADMUX |= (1 << ADLAR);// ADLAR: ADC Left Adjust Result: Resultatet blir left-shifted. Dette gjør at vi kan lese fra bare ADCH om vi ikke trenger mer enn 8-bit oppløsning
}

uint8_t IR_Read()
{
	// A single conversion is started by writing a logical one to the ADC Start Conversion bit, ADSC. This bit stays high as
	// long as the conversion is in progress and will be cleared by hardware when the conversion is completed.
	ADCSRA |= (1 << ADSC);	// ADSC: ADC Start Conversion. In Single Conversion mode, write this bit to one to start each conversion (s. 285)
	while(ADCSRA & (1 << ADSC));	// Når konverteringen er ferdig, settes ADSC lav av hardware.
	// Resultatet havner i 10-bit registeret ADCH + ADCL. Right-shifted by default, men vi har satt til left-shifted i init.
	// If the result is left adjusted and no more than 8-bit precision is required, it is sufficient to read ADCH
	return ADCH;
	// ADC = (Vin * 1024) / Vref
}

uint16_t IR_Read_withFilter()
{
	uint16_t sum = 0;
	uint8_t numberReadings = 4;

	for (int i = 0; i < numberReadings; i++) sum += IR_Read();
	return (sum / numberReadings);
}

#include "setup.h"
#include "util.h"
#include "TWI_Master.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

void DAC_Write(uint8_t motorVoltage);

#define slaveAddr 0x50;

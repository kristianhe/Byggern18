#include "setup.h"
#include "uart.h"
#include "memory.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "oled.h"
#include "oledMeny.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include <avr/interrupt.h>

bool RButton = false;
bool JButton = false;

uint8_t DispCounter = 0;
uint8_t JoyCounter = 0;
uint8_t KeyCounter = 0;

Joystick_Position joyPos;
Slider_Position sliPos;

ISR(TIMER0_OVF_vect){
	DispCounter++;
	JoyCounter++;
	KeyCounter++;
}

ISR(TIMER1_OVF_vect){

}

ISR(INT0_vect){
	RButton = true;
}
ISR(INT2_vect){
	JButton = true;
}

void drivers(){
	exInterInit_0();
	exInterInit_2();
	timer1_init();
	timer0_init();
	Watchdog_init();
	XMEM_Init();
	UART_Init(MYUBRR);
	Joystick_Init();
	oled_init();
	menuInit();
	canInit();
	//loopbackInit();
}

int main(void){
	sei();
	drivers();
	uint8_t Pos = 0;
	uint8_t Dir = 4;
	uint8_t state = 0;
	uint8_t GAMEState = 0;
	bool chDir = false;
	bool GaOv = false;

	joyPos = Joystick_getPosition();

	CAN_frame SCORE;
	CAN_frame GAME;
	GAME.id = 84;
	GAME.length = 5;
	GAME.data[0] = 1; //y pos
	GAME.data[1] = 2; //x pos
	GAME.data[2] = 3; //x -dir
	GAME.data[3] = 4; //RButton
	GAME.data[4] = 5; //sliPosLeft

	printf("Node 1 opt\n");
	_delay_ms(500);

	while(1)
	{
		wdt_reset(); //reseting the Watchdog timer

		//Joystick, sliders and buttons from ADC
		joyPos = Joystick_getPosition();
		Dir = Joystick_getDirection();
		sliPos = Slider_getPosition();

		//Display texts on oled
		if (DispCounter > 50){
			printCurrentMenu(Pos);
			DispCounter = 0;
		}
		//--------------------------------------------------------------

		//Using the pushbutton on the joystick to select different menus using external interrupt. INT2
		if ((JButton) && (KeyCounter > 100) && !(GaOv)){
			GAMEState = menuSelect(JButton, Pos);
			KeyCounter = 0;
			JButton = false;
		}
		//------------------------------------------------------------

		// In -and decrement position for the display using the joystick
		if ((state == 0) || (state == 2))
			if ((JoyCounter%10) == 0){
				if (Dir == 4) chDir = true;
				if ((Dir == 2) && ((chDir) || (JoyCounter > 50))){
					menuIncrementPosition();
					chDir = false;
					JoyCounter = 0;
				}
				else if ((Dir == 3) && ((chDir) || (JoyCounter > 50))){
					menuDecrementPosition();
					chDir = false;
					JoyCounter = 0;
				}
				Pos = menuGetPosition();
			}
		//------------------------------

		//Switch case for different GAME states; 0 = PreGAME, 1 = in GAME, 2 = end GAME/reset
		switch (state) {
			case 0:
			//PreGAME------------------------------------------------------------------------------

				//Pre GAME data that are transmitted over the CAN bus
				GAME.id = 42;
				GAME.data[0] = 45; //y pos
				GAME.data[1] = 99; //x pos
				GAME.data[2] = 84; //x -dir
				//------------------------------
				canTransmit(GAME);
				//-----------------------------
				if (GAMEState == 21) state = 1;
				break;
			//-------------------------------------------------------------------------------------
			case 1: //GAME
			//In GAME-------------------------------------------------------------------------------
				GAME.id = 69;
				GAME.data[0] = joyPos.y;
				GAME.data[1] = Pos;
				GAME.data[2] = Dir;
				GAME.data[4] = sliPos.right;

				//Right button for activating the solenoid using external interrupt. INT1
				if (RButton)
				{
					GAME.data[3] = 133; //On
					RButton = false;
				}
				else GAME.data[3] = 1;//Off
				//--------------------------
				canTransmit(GAME);

				if (canRecive(&SCORE)) //receiving the score value
				{
					if(SCORE.id == 13){
						printf("SCORE.data %d\n", SCORE.data[0]);
						state = 3;
						GaOv = true;
					}
					//TODO score = SCORE.data[0] og lag noe mer stash til dette
				}
				else if ((GAMEState == 31) || (GAMEState == 32)) state = 2;
				//-------------------------
				break;
			//-------------------------------------------------------------------------------------
			case 2:
			//Pause--------------------------------------------------------------------------------
				GAME.id = 2;
				if (GAMEState == 22) state = 1;
				else if (GAMEState == 1) state = 4;
				break;
			//-------------------------------------------------------------------------------------
			case 3:
			//Game over----------------------------------------------------------------------------
				GAME.id = 13;
				canTransmit(GAME);
				state = 4;
				break;
			case 4:
			//End GAME-----------------------------------------------------------------------------
				oled_clear_all(); //clear menu
				oled_print_page_mode(0, 8, "Shiiit");
				GAME.id = 0;
				canTransmit(GAME);

				_delay_ms(1500);

				menuInit(); //reset menu
				GAMEState = 0;
				GaOv = false;
				state = 0;
				break;
			//End GAME-----------------------------------------------------------------------------
			default:
				break;
		}
		//-----------------------------------------------------------------
	}

	return 0;
}

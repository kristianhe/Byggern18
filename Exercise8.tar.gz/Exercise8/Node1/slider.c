#include "slider.h"

void Slider_Init()
{
	DDRB &= ~(1 << DDB1);
	DDRB &= ~(1 << DDB2);
	//DDRD &= ~(1 << DDD2);
}

Slider_Position Slider_getPosition()
{
	Slider_Position sliPos;
	sliPos.left  = ADC_Read(2);
	sliPos.right = ADC_Read(3);
	return sliPos;
}

int Slider_getLeftButton()
{
	return !(!(PINB & (1 << PINB1)));
}

int Slider_getRightButton()
{
	return !(!(PINB & (1 << PINB2)));
}

#include "oled.h"
#include <stdbool.h>
#include <stdio.h>


typedef struct menu_page menu_page;
struct menu_page{
  uint8_t id;
  char * child_names[5];
  uint8_t rowLenght;
  menu_page *childs[5];
};

void  menuInit();
void printMenu(char *textlist[] , uint8_t Position, uint8_t rowLenght);
void printCurrentMenu(uint8_t rowPos);
uint8_t menuSelect(bool keyPress, uint8_t eventPos);
void menuSetPosition(uint8_t position);
void menuIncrementPosition();
void menuDecrementPosition();
uint8_t menuGetPosition();

#include "setup.h"

#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>

void ADC_Init();
uint8_t ADC_Read(uint8_t Channel);

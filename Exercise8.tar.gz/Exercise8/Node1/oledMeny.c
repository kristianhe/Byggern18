#include "oledMeny.h"

menu_page newPage;
menu_page tmp;
uint8_t event = 0;
uint8_t menuPos = 0;

char dot = '.';

static menu_page main_menu;
static menu_page play;
static menu_page options;
static menu_page score;
static menu_page game;
static menu_page reset;

static menu_page level;
static menu_page sound;

static menu_page main_menu = {.id = 1, .rowLenght = 3, .childs = {&play, &options, &score, &main_menu, &main_menu}};
static menu_page play = {.id = 11, .rowLenght = 2, .childs = {&game, &main_menu, &main_menu, &main_menu, &main_menu}};
static menu_page game = {.id = 21, .rowLenght = 2, .childs = {&reset, &reset, &reset, &reset, &reset}};
static menu_page reset = {.id = 31, .rowLenght = 2, .childs = {&main_menu, &game, &main_menu, &main_menu, &main_menu}};
static menu_page options = {.id = 12, .rowLenght = 3, .childs = {&level, &sound, &main_menu, &main_menu, &main_menu} };
static menu_page level = {.id = 22, .rowLenght = 5, .childs = {&main_menu, &main_menu, &main_menu, &main_menu, &main_menu}};
static menu_page sound = {.id = 23, .rowLenght = 3, .childs = {&options, &options, &options, &options, &options}};
static menu_page score = {.id = 13, .rowLenght = 2, .childs = {&main_menu, &main_menu, &main_menu, &main_menu, &main_menu}};

static char *Mainmenu[3][1] = {{(char *)("Play")}, {(char *)("Options")}, {(char *)("Score")}}; //Mainmenu
static char *Play[2][1] = {{(char *)("New game")}, {(char *)("Back")}}; //Play:
static char *Options[3][1] = {{(char *)("Difficulty")},{(char *)("Sound")}, {(char *)("Back")}}; //Options
static char *Reset[2][1] = {{(char *)("Reset")},{"Resume"}}; //Score
static char *Diff[5][1] = {{(char *)("Easy")}, {(char *)("Medium")}, {(char *)("Hard")}, {(char *)("Nightmare")}, {(char *)("Back")}}; //In Difficulty
static char *Sound[3][1] ={{(char *)("On")},{(char *)("Off")},{(char *)("Back")}}; //In Sound


void  menuInit(){
  newPage = main_menu;
  menuPos = 0;
}

uint8_t menuSelect(bool keyPress, uint8_t eventPos)
{
  if(keyPress){
    tmp = *newPage.childs[eventPos];
    if (&tmp != NULL)
    newPage = tmp;

    event = newPage.id + menuPos;
    printf("event %d\n", event);
  }

  return event;
}

void printCurrentMenu(uint8_t rowPos){
  oled_clear_all();
  switch (newPage.id) {
    case 1:
      printMenu(Mainmenu, rowPos, newPage.rowLenght);
      break;
    case 11:
      printMenu(Play, rowPos, newPage.rowLenght);
      break;
    case 12:
      printMenu(Options, rowPos, newPage.rowLenght);
      break;
    case 13:
      //printMenu(Score, rowPos, newPage.rowLenght);
      oled_print_page_mode(0, 0, "Score:");
      oled_print_page_mode(1, 0, "420");
      break;
    case 21:
      oled_print_page_mode(1, 8, "All man on deck");
      break;
    case 22:
      printMenu(Diff, rowPos, newPage.rowLenght);
      break;
    case 23:
      for(uint8_t i = 0; i < newPage.rowLenght; i++)
      {
        oled_print_page_mode(0, 0, "Sound:");
        if (i == rowPos)oled_print_page_mode((i+1), 8, Sound[i][0]);
        else oled_print_page_mode((i+1), 0, Sound[i][0]);
      }
      break;
    case 31:
      printMenu(Reset, rowPos, newPage.rowLenght);
      break;
    }
}

void printMenu(char *textlist[], uint8_t Position, uint8_t rowLenght)
{
  for(uint8_t i = 0; i < rowLenght; i++)
  {
    if (i == Position)oled_print_page_mode((i), 8, textlist[i]);
    else oled_print_page_mode((i), 0, textlist[i]);
  }
}

void menuSetPosition(uint8_t position)
{
  if ((position >= 0) && (position <= newPage.rowLenght)) menuPos = position;
}

void menuIncrementPosition()
{
  if (menuPos < newPage.rowLenght) menuPos++;
  else menuPos = 0;
  menuSetPosition(menuPos);
}

void menuDecrementPosition()
{
  if (menuPos > 0) menuPos--;
  else menuPos = newPage.rowLenght;
  menuSetPosition(menuPos);
}

uint8_t menuGetPosition()
{
  uint8_t Pos = menuPos;
  return Pos;
}

/*
void menuSelect(menu_Position Position){

  switch (menuSW) {
    case 0:

      if (menSelc == 0) menuNr = 0;
      else if (menSelc == 1) menuNr = 1; //go to option, meny -> option
      else if (menSelc == 2) menuNr = 3; //go to Score ------- går nå bare til Back meny -> Score -> Back -> meny
      else if (menSelc == 3) menuNr = 0;
      printf("%d\n",menSelc);
      printf("%d\n",menuNr);
      break;

    case 1:

      if (menSelc == 0) menuNr = 2; //Difficulty
      else if (menSelc == 1) menuNr = 3; //go to Font ------- går nå bare til Back
      else if (menSelc == 2) menuNr = 3; //go to sound ------- går nå bare til Back
      else if (menSelc == 3) menuNr = 0; //go to meny
      printf("%d\n",menSelc);
      printf("%d\n",menuNr);
      break;

    case 2:

      if (menSelc == 0) menuNr = 3; // meny -> optin -> Difficulty -> back -> meny
      else if (menSelc == 1) menuNr = 3; // meny -> optin -> Difficulty -> back -> meny
      else if (menSelc == 2) menuNr = 3; // meny -> optin -> Difficulty -> back -> meny
      else if (menSelc == 3) menuNr = 3; // meny -> optin -> Difficulty -> back -> meny
      else if (menSelc == 4) menuNr = 0;
      printf("%d\n",menSelc);
      printf("%d\n",menuNr);
      break;

    case 3:
      menuNr = 0;
      printf("%d\n",menSelc);
      printf("%d\n",menuNr);
      break;
    default:
      break;
  }

  printMenu();

}

void printMenu(char *textlist[], uint8_t Position, uint8_t rowLenght)
{
  switch (menuNr) {
		case 0:
      rowLenght = 3;
      for(uint8_t i = 0; i < (rowLenght+1); i++)
      {
        if (i == menuPos)oled_print_page_mode(i, 8, meny[i][0]);
        else oled_print_page_mode(i, 0, meny[i][0]);
      }
      menuSW = 0;
			break;
    case 1:
        rowLenght = 3;
        for(uint8_t i = 0; i < (rowLenght+1); i++)
        {
          if (i == menuPos)oled_print_page_mode(i, 8, menyOptions[i][0]);
          else oled_print_page_mode(i, 0, menyOptions[i][0]);
        }
        menuSW = 1;
  		  break;
		case 2:
      rowLenght = 4;
      for(uint8_t i = 0; i < (rowLenght+1); i++)
      {
        if (i == menuPos)oled_print_page_mode(i, 8, menyPlay[i][0]);
        else oled_print_page_mode(i, 0, menyPlay[i][0]);
      }
      menuSW = 2;
			break;
    case 3:
      rowLenght = 0;
      for(uint8_t i = 0; i < (rowLenght+1); i++)
      {
        oled_print_page_mode(i, 0, menyScore[i][0]);
      }
      menuSW = 3;
  		break;
    default:
      break;
	}

}


void menuSetPosition(uint8_t position)
{
  if ((position >= 0) && (position <= rowLenght))
  {
    menuPos = position;
  }
}

void menuIncrementPosition()
{
  if (menuPos < rowLenght) menuPos++;
  else menuPos = 0;
  menuSetPosition(menuPos);
}

void menuDecrementPosition()
{
  if (menuPos > 0) menuPos--;
  else menuPos = rowLenght;
  menuSetPosition(menuPos);
}

uint8_t menuGetPosition()
{
  return menuPos;
}
*/

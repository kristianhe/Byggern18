#include "setup.h"
#include "MCP2515.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>


typedef struct CAN_frame CAN_frame;
struct CAN_frame
{
  uint8_t   id;
  uint8_t   length;
  uint8_t   data[8];
};

void canInit();
void canTransmit(CAN_frame frame);
uint8_t canRecive(CAN_frame * RXframe);
bool canTXcomp();

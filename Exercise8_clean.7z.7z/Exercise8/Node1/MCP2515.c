#include "MCP2515.h"

uint8_t MCP_read(uint8_t addr) //Read instruction
{
  uint8_t Rdata;

  chipSelect(true);         //Lowering CS
  SPI_write(MCP_READ);      //Read instruction sent to MCP2515
  SPI_write(addr);          //8-bit addresses
  Rdata = SPI_read();
  chipSelect(false);        //Terminate read instruction - pulling CS high

  return Rdata;
}

void MCP_write(uint8_t addr, uint8_t data)
{
  chipSelect(true);         //Lowering CS
  SPI_write(MCP_WRITE);     //Read instruction sent to MCP2515
  SPI_write(addr);          //8-bit addresses
  SPI_write(data);          //1-byte addresses
  chipSelect(false);        //Terminate write instruction, pulling CS high
}

void MCP_RTS(uint8_t TXbuffer)
{
  chipSelect(true);
  if(TXbuffer == 0)       SPI_write(MCP_RTS_TX0);
  else if (TXbuffer == 1) SPI_write(MCP_RTS_TX1);
  else if (TXbuffer == 2) SPI_write(MCP_RTS_TX2);
  chipSelect(false);
}

void bitModify(uint8_t addr, uint8_t mask, uint8_t DataByte)
{
  chipSelect(true);         //Lowering CS
  SPI_write(MCP_BITMOD);    //BitModify instruction sent to MCP2515
  SPI_write(addr);          //8-bit addresses
  SPI_write(mask);          //Mask byte
  SPI_write(DataByte);      //Data byte
  chipSelect(false);        //Terminate bitModify instruction, pulling CS high
}

void MCP_reset()
{
  chipSelect(true);
  SPI_write(MCP_RESET);
  chipSelect(false);
}

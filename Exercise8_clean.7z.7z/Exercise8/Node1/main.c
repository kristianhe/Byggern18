#include "setup.h"
#include "uart.h"
#include "memory.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "oled.h"
#include "oledMeny.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include <avr/interrupt.h>

bool RButton = false;
bool JButton = false;

uint8_t DispCounter = 0;
uint8_t JoyCounter = 0;
uint8_t KeyCounter = 0;

joystick_position joyPos;
slider_position sliPos;

ISR(TIMER0_OVF_vect){
	DispCounter++;
	JoyCounter++;
	KeyCounter++;
}

ISR(TIMER1_OVF_vect){

}

ISR(INT0_vect){
	RButton = true;
}
ISR(INT2_vect){
	JButton = true;
}

void drivers()
{
	exInterInit_0();
	exInterInit_2();
	timer1_init();
	timer0_init();
	watchdogInit();
	XMEM_Init();
	UART_init(MYUBRR);
	joystickInit();
	OLED_init();
	menuInit();
	CAN_init();
	//loopbackInit();
}

int main(void)
{
	sei();
	drivers();
	uint8_t Pos = 0;
	uint8_t Dir = 4;
	uint8_t state = 0;
	uint8_t GAMEState = 0;
	bool chDir = false;
	bool GaOv = false;

	joyPos = joystickGetPosition();

	//CAN frame
	CAN_frame SCORE;
	CAN_frame GAME;
	GAME.id = 84;
	GAME.length = 5;
	GAME.data[0] = 1; //yPos
	GAME.data[1] = 2; //xPos
	GAME.data[2] = 3; //xDir
	GAME.data[3] = 4; //RButton
	GAME.data[4] = 5; //sliPosLeft

	printf("Node 1 opt\n");
	_delay_ms(500);

	while(1)
	{
		wdt_reset(); //Resetting the Watchdog timer

		//Joystick, sliders and buttons from ADC
		joyPos = joystickGetPosition();
		Dir = joystickGetDirection();
		sliPos = sliderGetPosition();

		//Display texts on OLED
		if (DispCounter > 50)
		{
			printCurrentMenu(Pos);
			DispCounter = 0;
		}

		//Using the pushbutton on the joystick to select different menus using external interrupt (INT2)
		if ((JButton) && (KeyCounter > 100) && !(GaOv))
		{
			GAMEState = menuSelect(JButton, Pos);
			KeyCounter = 0;
			JButton = false;
		}

		//Increment and decrement position for the display using the joystick
		if ((state == 0) || (state == 2))
		{
			if ((JoyCounter%10) == 0)
			{
				if (Dir == 4) chDir = true;
				if ((Dir == 2) && ((chDir) || (JoyCounter > 50)))
				{
					menuIncrementPosition();
					chDir = false;
					JoyCounter = 0;
				}
				else if ((Dir == 3) && ((chDir) || (JoyCounter > 50)))
				{
					menuDecrementPosition();
					chDir = false;
					JoyCounter = 0;
				}
				Pos = menuGetPosition();
			}
		}

		//Switch case for all the GAME states; 0 = PRE-GAME, 1 = IN-GAME, 2 = POST-GAME (reset)
		switch (state) {
			case 0:
			//-----------
			//PRE-GAME
			//-----------
				//Data that are transmitted over the CAN bus
				GAME.id = 42;
				GAME.data[0] = 45; 					//yPos
				GAME.data[1] = 99; 					//xPos
				GAME.data[2] = 84; 					//xDir

				CAN_transmit(GAME);

				if (GAMEState == 21) state = 1;
				break;
			case 1:
			//-----------
			//IN-GAME
			//-----------
				GAME.id = 69;
				GAME.data[0] = joyPos.y;
				GAME.data[1] = Pos;
				GAME.data[2] = Dir;
				GAME.data[4] = sliPos.right;

				if (RButton) 								//Right button for activating the solenoid using external interrupt (INT1)
				{
					GAME.data[3] = 133; 			//On
					RButton = false;
				}
				else GAME.data[3] = 1;			//Off
				CAN_transmit(GAME);

				if (CAN_receive(&SCORE)) 		//Receiving the score value
				{
					if(SCORE.id == 13){
						printf("SCORE.data %d\n", SCORE.data[0]);
						state = 3;
						GaOv = true;
					}
																		//TODO score = SCORE.data[0] og lag noe mer stash til dette
				}
				else if ((GAMEState == 31) || (GAMEState == 32)) state = 2;
				break;
				//-------------------------
				case 2: 										//Pause
				GAME.id = 2;
				if (GAMEState == 22) state = 1;
				else if (GAMEState == 1) state = 4;
				break;
				//-------------------------
			case 3: 											//Game over
				GAME.id = 13;
				CAN_transmit(GAME);
				state = 4;
				break;
			case 4:
			//-----------
			//POST-GAME
			//-----------
				OLED_clearAll(); 						//Clear menu
				OLED_printPageMode(0, 8, "Shiiit");
				GAME.id = 0;
				CAN_transmit(GAME);

				_delay_ms(1500);

				menuInit(); 								//Reset menu
				GAMEState = 0;
				GaOv = false;
				state = 0;
				break;
			default:
		}
	}

	return 0;
}

#include "setup.h"
#include "util.h"
#include "adc.h"

#include <stdio.h>
#include <avr/io.h>

typedef struct joystick_position {
	uint8_t x;
	uint8_t y;
} joystick_position;

void joystickInit();
void joystickCalibrate();
joystick_position joystickGetPosition();
uint8_t joystickGetDirection();
int joystickGetButton();

#include "setup.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>

void OLED_init();
void OLED_home();
void OLED_clearAll();
void OLED_clearPage(uint8_t page);
void OLED_goToPage(uint8_t page);
void OLED_goToColumn(uint8_t column);
void OLED_setPos(uint8_t page, uint8_t column);
void OLED_printPageMode(char r, char c, char *character);
bool OLED_status(bool sleepFlag, bool sleepStatus, bool wakeFlag);

#include "setup.h"

#include <stdio.h>
#include <avr/io.h>

#define WDTO_2S

void watchdogInit();
void timer0_init();
void timer1_init();
void exInterInit_0();
void exInterInit_1();
void exInterInit_2();
uint8_t Scale(uint8_t In, int  MaxIn, int  MinIn, int  MaxOut, int  MinOut);

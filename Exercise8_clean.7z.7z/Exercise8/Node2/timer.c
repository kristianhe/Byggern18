#include "timer.h"

void PWM_init()
{
  DDRE |= (1<<PE3);                                   //Set PE3 as output
  TCCR3A |= (1<<WGM31) | (1<<COM3A1) | (0<<COM3A0);   //Initialize timer3 in Fast PWM mode (non-inverting)
  TCCR3B |= (1<<WGM33) | (1<<WGM32) | (1<<CS31);      //(same as above)
  ICR3 = 39999;                                       //Set TOP count
  printf("Initialize timer3 in Fast PWM mode\n");
}

void timer0_init(){
	TCCR0B |= (1<<CS02) |(0<<CS01) | (1<<CS00);          //Clk I/O /1024 (From prescaler)
	TIMSK0 |= (1<<TOIE0);                                //Interrupt at Timer/Counter0 Overflow
  printf("Timer/Counter0, prescaler: %0.2X\n", TCCR0B);
}

void timer1_init(){
	TCCR1A = 0x00;                                        //Top value = 0xFFFF
  TCCR1B |= (0<<CS12) | (1<<CS11) | (1<<CS10);          //Prescale 64 ~ ovf pr 0.85 s
	TIMSK1 |= (1<<TOIE1);                                 //Interrupt at Timer/Counter1 Overflow
  printf("Timer/Counter1, prescaler: %0.2X\n", TCCR1B);
}

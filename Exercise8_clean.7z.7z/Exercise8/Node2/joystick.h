#include "setup.h"
#include "util.h"
#include "adc.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#ifndef JOYSTICK_H_
#define JOYSTICK_H_

typedef enum
{
	LEFT,
	RIGHT,
	UP,
	DOWN,
	NEUTRAL
} joystick_direction;

typedef struct joystick_position {
	int x;
	int y;
} joystick_position;

void joystickInit();
void joystickCalibrate();
joystick_position joystickGetPosition();
joystick_direction joystickGetDirection();
int joystickGetButton();

#endif

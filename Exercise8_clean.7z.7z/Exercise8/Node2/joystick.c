#include "joystick.h"

uint8_t joyX_init, joyY_init;

void joystickInit()
{
	DDRB &= ~(1 << DDB3);
	DDRB &= ~(1 << DDB2);
	joystickCalibrate();
}

void joystickCalibrate()
{
	joyX_init = ADC_read(0);		//Reads the value on CH1 on the ADC (Joystick X)
	joyY_init = ADC_read(1);		//Reads the value on CH2 on the ADC (Joystick Y)
}

joystick_position joystickGetPosition()
{
	joystick_position joyPosition;
	joyPosition.x = Scale(ADC_read(0),255,0,100,-100);
	joyPosition.y = Scale(ADC_read(1),255,0,100,-100);

	return joyPosition;
}

joystick_direction joystickGetDirection()
{
	joystick_position	joyPos = joystickGetPosition();
	joystick_direction	joyDir;
	int threshold = 45;

	if (joyPos.x >  threshold)				joyDir = RIGHT;
	else if (joyPos.x < -threshold) 	joyDir = LEFT;
	else if (joyPos.y >  threshold)		joyDir = UP;
	else if (joyPos.y < -threshold) 	joyDir = DOWN;
	else															joyDir = NEUTRAL;

	return joyDir;
}

int joystickGetButton()
{
	return !(!(PINB & (1 << PINB3)));
}

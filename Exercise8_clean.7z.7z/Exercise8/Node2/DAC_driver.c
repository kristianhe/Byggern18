#include "DAC_driver.h"

void DAC_write(uint8_t motorVoltage) 				//Writes from the MCU to the DAC-IC (MAX520) through the I2C bus. We control the motor voltage with the output of the DAC
{
	uint8_t data[3];

	data[0] = 0x50;														//Slave adress byte (unchanged, the first 0101 is default. The rest is 0000)
	data[1] = 0x00;														//Command byte (dont do anything, we are just setting the DAC outputs)
	data[2] = motorVoltage;										//Output byte

  TWI_Start_Transceiver_With_Data(data, 3);	//3 is the message length. Logic for START and STOPP is in this function
}

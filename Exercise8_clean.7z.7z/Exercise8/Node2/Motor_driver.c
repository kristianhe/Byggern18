#include "Motor_driver.h"

void motorInit()
{
  TWI_Master_Initialise();

	DDRH |= (1 << OE) | (1 << RST) | (1 << SEL) | (1 << EN) | (1 << DIR); 	//Sets all desired ports for motor control as outputs (MJ1)
	DDRK = 0;	                                                              //Sets all desired ports for encoder reading as input (MJ2)
	PORTH |= (1 << EN);		                                                  //Enable motor
	PORTH &= ~(1 << OE);	                                                  //Output enable (encoder) (active low)

  EC_enable();
	encoderReset();
}

void motorControl(int input)
{
  uint8_t motorGain = (uint8_t)abs(input);

  if (input < 0){
    PORTH |= (1 << DIR);
    DAC_write(motorGain);
  }
  else{
    PORTH &= ~(1 << DIR);
    DAC_write(motorGain);
  }
}

void encoderReset()
{
	PORTH &= ~(1 << RST);		//Toggle !RST to reset encoder (active low)
	_delay_ms(10);				  //Wait
	PORTH |= (1 << RST);		//Toggle back
}

uint16_t encoderRead()
{
  //PORTH &= ~(1 << OE);	 //Output enable (encoder) (active low)
	PORTH &= ~(1 << SEL);		 //Sets SEL low to reach the MSB's
	_delay_us(30);				   //Wait ~20 microsec
	uint8_t encoderH = PINK; //Reads the MSB's
	PORTH |= (1 << SEL);		 //Sets SEL low to reach the LSB's
	_delay_us(30);				   //Wait ~20 microsec
	uint8_t encoderL = PINK; //Reads the LSB's

  uint16_t res = (-1)*(uint16_t)((encoderH << 8) | encoderL);
  return res;
}

void EC_disable()
{
  PORTH |= (1 << OE);	    //Output disable (encoder) (active low)
}

void EC_enable()
{
  PORTH &= ~(1 << OE);	  //Output enable (encoder) (active low)
}

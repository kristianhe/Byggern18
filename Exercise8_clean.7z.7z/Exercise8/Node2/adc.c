#include "adc.h"

uint8_t ADC_read(uint8_t Channel)
{
  volatile char *dataADC = (char*) adADC;

  if (Channel > 3) return 0;
  *dataADC = (0x04 | Channel);
  _delay_us(50);
  return *dataADC;
}

void IR_init()																							//Initialize the IR receiver on port F0... ADCSRA – ADC Control and Status Register A (p. 285)
{
	DDRF &= ~(1 << PF0);																			//Sets PF0 as input
	ADCSRA |= (1 << ADEN);																		//Enable ADC. Mux = 0000000, uses ADC0
	ADCSRA |= (1 << ADPS2) || (1 << ADPS1) || (1 << ADPS0); 	//ADC must have a working frequency between 50 kHz and 200kHz: Division factor / prescale = 128.  - working frequency = 16mHz/128 = 125kHz
	ADMUX |= (1 << REFS0); 																		//ADMUX – ADC Multiplexer Selection Register: Using AVCC as reference	(AVCC with external capacitor at AREF pin (!!!)) There are no external capacitor at AREF pin
	ADMUX |= (1 << ADLAR);																		//ADLAR: ADC Left Adjust Result: The result becomes left-shifted. This enables only reading from ADCH if we dont need more than 8-bit resolution
}

uint8_t IR_read()																						//A single conversion is started by writing a logical one to the ADC Start Conversion bit, ADSC. This bit stays high as long as the conversion is in progress and will be cleared by hardware when the conversion is completed.

{
	ADCSRA |= (1 << ADSC);																		//ADSC: ADC Start Conversion. In Single Conversion mode, write this bit to one to start each conversion (p. 285)
	while(ADCSRA & (1 << ADSC));															//When the conversion is complete, ADSC is set to low by hardware
																														//The result ends up in the 10-bit register ADCH + ADCL. Right-shifted by default, but we have set it to left-shifted in IR_init... If the result is left adjusted and no more than 8-bit precision is required, it is sufficient to read ADCH
	return ADCH;																							// ADC = (Vin * 1024) / Vref
}

uint16_t IR_readWithFilter()
{
	uint16_t sum = 0;
	uint8_t numberReadings = 4;

	for (int i = 0; i < numberReadings; i++) sum += IR_read();

	return (sum / numberReadings);
}

#include "setup.h"
#include "util.h"
#include "adc.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#ifndef JOYSTICK_H_
#define JOYSTICK_H_

typedef enum
{
	LEFT,
	RIGHT,
	UP,
	DOWN,
	NEUTRAL
}Joystick_Direction;

typedef struct
{
	int x;
	int y;
}Joystick_Position;

void Joystick_Init();
void Joystick_Calibrate();
Joystick_Position Joystick_getPosition();
Joystick_Direction Joystick_getDirection();
int Joystick_GetButton();

#endif /* JOYSTICK_H_ */

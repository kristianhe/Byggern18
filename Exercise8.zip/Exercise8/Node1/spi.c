#include "spi.h"

void spi_init()
{
  DDRB |= (1<<MOSI) | (1<<SCK) | (1<<SS); //output
  DDRB &= ~(1<<MISO); //input
  SPCR = (1<<SPE) | (1<<MSTR) | (1<<SPR0); //SPE: SPI Enable, MSTR: Master/Slave Select, SPR1, SPR0: SPI Clock Rate Select 1 and 0 - Fosc/16
}

uint8_t spiRead()
{
  spiWrite(0);  // Dummy-data for å få slave til å sende data til oss :)
  while(!(SPSR & (1<<SPIF))); /* Wait for reception complete */
  return SPDR;   /* Return data register */
}

void spiWrite(uint8_t cData)
{
  SPDR = cData; /* Start transmission */
  while(!(SPSR & (1<<SPIF))); /* Wait for transmission complete */
}

void chipSelect(bool selc)
{
  if(selc) PORTB &= ~(1<<PB4);
  else PORTB |= (1<<PB4);
}

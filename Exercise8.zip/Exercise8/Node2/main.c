
#include "setup.h"
#include "uart.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"
#include "timer.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

bool Deltime = false;
bool INTflag = false;

uint8_t counter = 0;

ISR(TIMER0_OVF_vect){
	counter++;
	printf("%d\n", counter);
}

ISR(TIMER1_OVF_vect){
}

void drivers(){
	UART_Init(MYUBRR);
	PWM_init();
	timer0_init();
	timer1_init();

	canInit();
	IR_Init();
	//loopbackInit();
}


int main(void)
{
	drivers();

	uint8_t RXvalue = 0;
	uint8_t IR_value = 255;

	uint8_t score = 0;
	bool scoreFlag = false;
	bool maskflag = false;


	CAN_frame RXtest;
	RXtest.id = 0;
	RXtest.length = 0;
	RXtest.data[0] = 0;
	RXtest.data[1] = 0;

	printf("Node 2 opertional\n");
	sei();
	while(1)
	{

		if (canRecive(&RXtest))
		{
			RXvalue = RXtest.data[0];
		}

		OCR3A = Scale(RXvalue, 255,0, 4600, 1800);
		IR_value = IR_Read_withFilter();

		if ((IR_value < 30) && !(scoreFlag))
		{
			scoreFlag ^= maskflag;
			score++;
		}
		else if ((IR_value > 50) && !(scoreFlag)){
			scoreFlag = false;
		}

		if(counter > 300000){
			counter = 0;
		}

	}

	return 0;
}

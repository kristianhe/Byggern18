#include "setup.h"
#include "util.h"
#include "adc.h"

#include <stdio.h>
#include <avr/io.h>

/*
typedef enum
{
	LEFT,
	RIGHT,
	UP,
	DOWN,
	NEUTRAL
}Joystick_Direction;
*/

typedef struct
{
	uint8_t x;
	uint8_t y;
}Joystick_Position;

void Joystick_Init();
void Joystick_Calibrate();
Joystick_Position Joystick_getPosition();
uint8_t Joystick_getDirection();
int Joystick_GetButton();

#include "setup.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>

void oled_init();
void oled_home();
void oled_clear_all();
void oled_clear_page(uint8_t page);
void oled_goto_page(uint8_t page);
void oled_goto_column(uint8_t column);
void oledSetpos(uint8_t page, uint8_t column);
void oled_print_page_mode(char r, char c, char *character);
bool oled_status(bool sleepFlag, bool sleepStatus, bool wakeFlag);

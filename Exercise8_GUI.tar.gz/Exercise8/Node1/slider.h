#include "setup.h"
#include "adc.h"

#include <stdio.h>
#include <avr/io.h>

typedef struct
{
	uint8_t	left;
	uint8_t right;
}Slider_Position;

void Slider_Init();
Slider_Position Slider_getPosition();
int Slider_getLeftButton();
int Slider_getRightButton();

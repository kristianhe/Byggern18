#include "util.h"

void exInterInit_3(){
	EICRA |= (1<<ISC31) | (0<<ISC30);
	EIMSK |= (1<<INT3);
}

void blink(){
	pinB |= (0b00000001);
	_delay_ms(250);
	pinB &= ~(0b00000001);
	_delay_ms(250);
	pinB |= (0b00000001);
}

int  Scale(uint8_t  In, int  MaxIn, int  MinIn, int  MaxOut, int  MinOut)
{
	float k;
  int in = (int)In;
	int Out;

	k = (float)(MaxOut-MinOut)/(float)(MaxIn-MinIn);
  Out = (int)(k*in-k*MinIn+MinOut);

  return Out;
}

int  Scale16(uint16_t In, int  MaxIn, int  MinIn, int  MaxOut, int  MinOut)
{
	float k;
	int Out;
	int in = (int)In;

	k = (float)(MaxOut-MinOut)/(float)(MaxIn-MinIn);
  Out = (k*In-k*MinIn+MinOut);

  return Out;
}

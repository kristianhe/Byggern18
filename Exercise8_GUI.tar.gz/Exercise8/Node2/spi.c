#include "spi.h"

void spi_init()
{
  DDRB |= (1<<MOSI) | (1<<SCK) | (1<<SS) | (1 << PB0); //output
  DDRB &= ~(1<<MISO); //input
  SPCR = (1<<SPE) | (1<<MSTR) | (1<<SPR0); //SPE: SPI Enable, MSTR: Master/Slave Select, SPR1, SPR0: SPI Clock Rate Select 1 and 0 - Fosc/16
}

uint8_t spiRead()
{
  spiWrite(0);  // Dummy-data for å få slave til å sende data til oss :)
  /* Wait for reception complete */
  while(!(SPSR & (1<<SPIF)));
  /* Return data register */
  return SPDR;
}

void spiWrite(uint8_t cData)
{
  /* Start transmission */
  SPDR = cData;
  /* Wait for transmission complete */
  while(!(SPSR & (1<<SPIF)));
}

void chipSelect(bool selc)
{
  if(selc) PORTB &= ~(1<<SS);
  else PORTB |= (1<<SS);
}

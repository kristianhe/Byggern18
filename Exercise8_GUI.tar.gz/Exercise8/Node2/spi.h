#include "setup.h"
#include "util.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define SS PB7 //slave select
#define SCK PB1 //clock signal
#define MOSI PB2 //Master out, slave in
#define MISO PB3 //Master in, slave out


void spi_init();
uint8_t spiRead();
void spiWrite(uint8_t cData);
void chipSelect(bool selc);

#include "setup.h"
#include "util.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

//128
#define SCALING_FACTOR  100

typedef struct PID_DATA{
  int sumError;
  int16_t Kp;
  int16_t Ki;
  int16_t Kd;
} pidData_t;

void pid_Init(int16_t Kp_in, int16_t Ki_in, int16_t Kd_in,struct PID_DATA *pid);
int pid_Controller(int16_t setPoint, int16_t processValue, uint8_t Timestep, int deltaError, struct PID_DATA *pid_st);
void pid_Reset_Integrator(pidData_t *pid_st);
void pid_ChangeControllerValues(int16_t Kp_in, int16_t Ki_in, int16_t Kd_in, struct PID_DATA *pid);

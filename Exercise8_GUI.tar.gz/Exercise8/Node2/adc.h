#include "setup.h"

#include <stdbool.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

void IR_Init();
uint8_t IR_Read();
uint16_t IR_Read_withFilter();
uint8_t ADC_Read(uint8_t Channel);

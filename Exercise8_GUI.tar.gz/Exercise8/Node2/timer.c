#include "timer.h"

void PWM_init()
{
  //Make pin PE3 as output
  DDRE |= (1<<PE3);
  //Initialize timer3 in Fast PWM mode (non-inverting)
  TCCR3A |= (1<<WGM31) | (1<<COM3A1) | (0<<COM3A0);
  TCCR3B |= (1<<WGM33) | (1<<WGM32) | (1<<CS31);
  //Set TOP count
  ICR3 = 39999;
  printf("Initialize timer3 in Fast PWM mode\n");
}

void timer0_init(){
	TCCR0B |= (1<<CS02) |(0<<CS01) | (1<<CS00); //clk I/O /1024 (From prescaler)
	TIMSK0 |= (1<<TOIE0); //interupt at Timer/Counter0 Overflow
  printf("Timer/Counter0, prescaler: %0.2X\n", TCCR0B);
}

/*
void timer1_init(){
	TCCR1A |= (1<<COM1A1) | (1<<COM1A0);
	TCCR1B |= (1<<CS11); // clk/8 prescale -> overflow hvert 0.1 s
	TIMSK1 |= (1<<OCIE1A); //Output Compare A Match Interrupt Enable
}
*/

void timer1_init(){
	TCCR1A = 0x00; //top value = 0xFFFF
  TCCR1B |= (0<<CS12) | (1<<CS11) | (1<<CS10); //Prescale 64 ~ ovf pr 0.85 s
	TIMSK1 |= (1<<TOIE1); //interupt at Timer/Counter1 Overflow
  printf("Timer/Counter1, prescaler: %0.2X\n", TCCR1B);
}


#include "setup.h"
#include "uart.h"
#include "util.h"
#include "adc.h"
#include "slider.h"
#include "joystick.h"
#include "spi.h"
#include "MCP2515.h"
#include "can.h"
#include "timer.h"
#include "Notes.h"
#include "Motor_driver.h"
#include "pid.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>     /* atoi */
#include <string.h>			/* strchr */
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

// PI
//Medium Kp = 1.5, Ki = 0.01, Kd = 0.9
// Kp = 3.0, Ki = 0.01, Kd = 1.3
//Nightmare Kp = 1.0, Ki = 0.01, Kd = 5.3

#define K_P   1.5
#define K_I 	0.0
#define K_D 	1.3

#define SCALING 100
struct PID_DATA pidData;

bool Deltime = false;
bool INTflag = false;

//Global counters
uint8_t stateCounter = 0;
uint8_t trigCounter = 0;
uint8_t timeStep = 0;
uint8_t startupCounter = 0;

uint8_t SCTlimit = 0;
uint16_t scorecount = 0;

uint8_t muCount = 0;
uint16_t freq = 0;

//Timer0 overflow interrupt
ISR(TIMER0_OVF_vect){
	trigCounter++;
	timeStep++;
	startupCounter++;
	stateCounter++;
	SCTlimit++;
}

//Timer1 overflow interrupt
ISR(TIMER1_OVF_vect){
	scorecount++;
}

//Initialize the drivers
void drivers(){
	UART_Init(MYUBRR);
	PWM_init();
	timer0_init();
	timer1_init();
	canInit();
	IR_Init();
	MotorInit();
	pid_Init(K_P*SCALING, K_I*SCALING, K_D*SCALING, &pidData);
}

int main(void)
{
	//Drivers and global interupt
	drivers();
	sei();
	DDRE |= (1<<PE4);
	OCR3A = 3200;
	//--------------------------

	//State variables for the game
	uint8_t state = 0;
	bool stateFlag = false;
	//--------------------------

	//Inputs and Outputs
	uint8_t servoVal = 0;
	uint8_t joyPos_x = 0;
	uint8_t dirVal = 0;
	uint8_t solenoid = 0;
	uint8_t sliderPos = 0;
	uint8_t IR_value = 255;
	//--------------------------

	//For PID controller
	uint8_t refPos = 128;
	uint16_t enc = 0;
	int motorInput = 0;
	uint16_t tmpEnc1 = 0;
	uint16_t tmpEnc2 = 0;
	int deltaEnc = 0;
	//--------------------------

	//Boolean control variables
	bool startFlag = false;
	bool trigFlag = false;
	bool trigCountFlag = false;
	//--------------------------

	//For state machine
	bool oddFlag = true;
	bool evenFlag = false;
	bool calcDelta = false;
	bool pidFlag = false;
	//--------------------------

	//CAN frame----------------
	//Pregame ID 62
	//Ingame ID 42
	CAN_frame RXframe;
	CAN_frame TXframe;
	TXframe.id = 13;
	TXframe.length = 1;
	TXframe.data[0] = 0;
	//--------------------------

	// TESTLOGIKK FOR STYRING VIA GUI
	char guidata[15];
	char inputChar = 0;
	bool endMsgFlag = false;
	uint8_t l = 0;
	servoVal = 127;
	solenoid = 0;
	sliderPos = 127;
	//-------------------------------

	while((startupCounter < 100) && !(startFlag)){ //Reseting the motor and encoder
		MotorContrl(-128);
		Encoder_Reset();
	}
	printf("$Node 2 opertional*\n");
	_delay_ms(2000);

	while(1)
	{

		for (int k = 0; k < l; k++)
		{
			guidata[k] = "";
		}

		l = 0;
		guidata[l++] = UART_Receive();

		while (!endMsgFlag)
		{
			inputChar = UART_Receive();

			if (inputChar == '#')
			{
				endMsgFlag = true;
			}

			guidata[l++] = inputChar;
		}
		endMsgFlag = false;



		int posHash = strcspn(guidata, "#");
		char temp[posHash-1];
		for (uint8_t i = 0; i < (posHash - 1); i++)
		{
			temp[i] = guidata[i + 1];
		}

		//int guiValue = atoi(temp);
		//printf("$temp = %s*\n", temp);
		//_delay_ms(1000);
		//printf("$atoi = %d*\n", atoi(temp));
		//_delay_ms(1000);

		if (guidata[0] == 'S')
		{
			solenoid  = atoi(temp);	// Solenoid
			printf("$Solenoid: %d*\n", solenoid);
			//_delay_ms(1000);
		}
		else if (guidata[0] == 'D')
		{
			servoVal  = atoi(temp); // Servo
			printf("$Servo: %d*\n", servoVal);
			//_delay_ms(1000);
		}
		else if (guidata[0] == 'R')
		{
			sliderPos = atoi(temp); // DC-motor referanse (slider)
			printf("$slider: %d*\n", sliderPos);
			//_delay_ms(1000);
		}
		else if (guidata[0] == 'C') // PID-verdier
		{

			//ALTERNATIV:							// $CP5I6D7#   length = 9			$CP90I50D1#		length = 11
			int posP = strcspn(guidata, "P");		//			   posP = 2								posP = 2
			int posI = strcspn(guidata, "I");		//			   posI = 4								posI = 5
			int posD = strcspn(guidata, "D");		//			   posD = 6								posD = 8

			char tempP[15];
			char tempI[15];
			char tempD[15];

			int j = 0;
			for (uint8_t i = (posP + 1); i < posI; i++) tempP[j++] = guidata[i];

			j = 0;
			for (uint8_t i = (posI + 1); i < posD; i++) tempI[j++] = guidata[i];
			j = 0;
			for (uint8_t i = (posD + 1); i < (l - 1); i++) tempD[j++] = guidata[i];

			int16_t KP = atoi(tempP);
			int16_t KI = atoi(tempI);
			int16_t KD = atoi(tempD);

			pid_ChangeControllerValues(KP, KI, KD, &pidData);


		}


	}	// end while

	return 0;
}

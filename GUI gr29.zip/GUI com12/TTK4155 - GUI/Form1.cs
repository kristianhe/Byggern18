﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.IO.Ports;          // Serial port


// Every message from the MCUs are expected to start with '$' and end with '*'
// Every message we send to the MCUs starts with a string that explains what type of value we are sending (solenoid, DC-motor, ...)
// S = Solenoid, D = servo, R = DC-motor reference, C = PID controller values. Ends with '#'

namespace TTK4155___GUI
{
    public partial class Form1 : Form
    {
        bool exit;

        SerialPort sPort;  // Serial port for node 2
        string readbuffer, trackbar, message;
        char charInput;
        int lastValue, threshold, blinkCounter, quoteCounter, score;

        System.Windows.Media.MediaPlayer gun;
        System.Windows.Media.MediaPlayer background;
        System.Windows.Media.MediaPlayer loose;
        System.Windows.Media.MediaPlayer intro;
        System.Windows.Media.MediaPlayer quote1;
        System.Windows.Media.MediaPlayer quote2;
        System.Windows.Media.MediaPlayer quote3;

        public Form1()
        {
            // Initialization at startup
            InitializeComponent();
            timerBlink.Interval = 330;
            timerSong.Interval  = 11000;
            timerBlink.Tick     += new EventHandler(timerBlink_Tick);
            timerSong.Tick      += new EventHandler(timerSong_Tick);
            timerScore.Tick     += new EventHandler(timerScore_Tick);
            pbLoose.Visible = false;
            exit            = false;
            message         = "";
            readbuffer      = "";
            trackbar        = "";
            charInput       = '*';
            blinkCounter    = 0;
            quoteCounter    = 0;
            lastValue       = 0;
            score           = 0;
            threshold       = 5;
            sPort       = null;
            gun         = null;
            background  = null;
            loose       = null;
            intro       = null;
            quote1      = null;
            quote2      = null;
            quote3      = null;
        }

        private void timerScore_Tick(object Sender, EventArgs e)
        {
            tbScore.Text = ((score++)*100).ToString() + "$";
        }

        private void timerSong_Tick(object Sender, EventArgs e)
        {
            // Logic for playing of different quotes
            timerBlink.Enabled = true;
            if (quoteCounter == 0)
            {
                background.Volume = 0.1;
                quote1.Volume = 0.5;
                quote1.Play();
                timerSong.Interval = 4000;
                quoteCounter++;
            }
            else if (quoteCounter == 1)
            {
                background.Volume = 0.2;
                timerSong.Interval = 13000;
                quoteCounter++;
            }
            else if (quoteCounter == 2)
            {
                background.Volume = 0.1;
                quote2.Volume = 1;
                quote2.Play();
                timerSong.Interval = 5900;
                quoteCounter++;
            }
            else if (quoteCounter == 3)
            {
                background.Volume = 0.2;
                timerSong.Interval = 7000;
                quoteCounter++;
            }
            else if (quoteCounter == 4)
            {
                background.Volume = 0.1;
                quote3.Volume = 1;
                quote3.Play();
                timerSong.Interval = 2000;
                quoteCounter++;
            }
            else if (quoteCounter == 5)
            {
                background.Volume = 0.2;
                timerSong.Interval = 15000;
                tbScore.BackColor = Color.Green;
                quoteCounter = 0;
            }
        }

        private void timerBlink_Tick(object Sender, EventArgs e)
        {
            // Logic for blinking the text box with the quotes
            if (quoteCounter % 2 != 0)
            {
                if (tbScore.BackColor == SystemColors.Control)
                {
                    tbScore.BackColor = Color.LightGreen;
                }
                else
                {
                    tbScore.BackColor = SystemColors.Control;
                }
                blinkCounter++;
                if (blinkCounter > 7)
                {
                    timerBlink.Enabled = false;
                    blinkCounter = 0;
                }
            }
        }

        private void btn_Avslutt_Click(object sender, EventArgs e)
        {
            exit = true;
            if (sPort == null)
            {
                Application.Exit();
            }
        }

        private void btnTap_Click(object sender, EventArgs e)
        {
            // If we loose
            lost();
            try
            {
                sPort.Write("Q");
                sPort.Write("0");
                sPort.Write("#");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void lost()
        {
            // Disable controls
            pbLoose.Visible     = true;
            pbLoose.Enabled     = true;
            btnPID.Enabled      = false;
            btnStart.Enabled    = false;
            btnTap.Enabled      = false;
            trackBarDC.Enabled  = false;
            tbKp.Enabled        = false;
            tbKi.Enabled        = false;
            tbKd.Enabled        = false;
            numGrense.Enabled   = false;
            tbScore.BackColor   = Color.Red;
            loose.Volume        = 1;

            // Close media
            gun.Close();
            quote1.Close();
            quote2.Close();
            quote3.Close();
            background.Close();

            // Stop timers
            timerBlink.Stop();
            timerScore.Stop();
            timerSong.Stop();
            
            // Play loose-media
            loose.Play();
        }

        private void pbLoose_Click(object sender, EventArgs e)
        {
            // Makes the picture box invisible when clicked
            pbLoose.Enabled = false;
            pbLoose.Visible = false;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            // FOR MICROCONTROLLERS (NODE1 & NODE2) ON UBUNTU
            //sPort1 = new SerialPort("/dev/ttyS0", 9600, Parity.None, 8, StopBits.Two);
            //sPort2 = new SerialPort("/dev/ttyACM0", 9600, Parity.None, 8, StopBits.Two);

            // FOR MICROCONTROLLER (NODE2) ON WINDOWS
            sPort = new SerialPort("COM12", 9600, Parity.None, 8, StopBits.Two);

            // FOR TESTING WITH OWN PROGRAM. USE VIRTUAL COM-PORTS (e.g. with com0com).
            //sPort1 = new SerialPort("COM6", 9600, Parity.None, 8, StopBits.Two);
            //sPort2 = new SerialPort("COM5", 9600, Parity.None, 8, StopBits.Two);

            try
            {
                sPort.Open();
            }
            catch (Exception ex)
            {
                sPort = null;
                MessageBox.Show("Error: " + ex.Message);
            }

            if (sPort != null)
            {
                if (sPort.IsOpen)
                {
                    btnStart.Enabled        = false;
                    btnPID.Enabled          = true;
                    trackBarDC.Enabled      = true;
                    bwDatainnsamler2.RunWorkerAsync();

                    try
                    {
                        gun         = new System.Windows.Media.MediaPlayer();
                        background  = new System.Windows.Media.MediaPlayer();
                        loose       = new System.Windows.Media.MediaPlayer();
                        intro       = new System.Windows.Media.MediaPlayer();
                        quote1      = new System.Windows.Media.MediaPlayer();
                        quote2      = new System.Windows.Media.MediaPlayer();
                        quote3      = new System.Windows.Media.MediaPlayer();

                        gun.Open        (new System.Uri(@"D:\Desktop\GUN\gun2_cut.wav"));
                        background.Open (new System.Uri(@"D:\Desktop\GUN\perqualche.wav"));
                        loose.Open      (new System.Uri(@"D:\Desktop\GUN\tap.wav"));
                        intro.Open      (new System.Uri(@"D:\Desktop\GUN\getthreecoffinsready.wav"));
                        quote1.Open     (new System.Uri(@"D:\Desktop\GUN\suicide.wav"));
                        quote2.Open     (new System.Uri(@"D:\Desktop\GUN\threethousand.wav"));
                        quote3.Open     (new System.Uri(@"D:\Desktop\GUN\NotEnough.wav"));

                        intro.Play();
                        System.Threading.Thread.Sleep(1600);    // Wait for the intro to finish playing
                        background.Volume   = 0.2;
                        gun.Volume          = 0.15;
                        background.Play();

                        timerSong.Enabled   = true;
                        timerScore.Enabled  = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        private void btnBlink_Click(object sender, EventArgs e)
        {
            timerBlink.Enabled = true;
        }

        // When the value for the slider changes
        private void trackBarDC_ValueChanged(object sender, EventArgs e)
        {
            // Only updates the slider values if they exceed the threshold
            if ((trackBarDC.Value >= (lastValue + threshold)) || (trackBarDC.Value <= lastValue - threshold))
            {
                try
                {
                    sPort.Write("R");
                    trackbar = (trackBarDC.Value).ToString();
                    for (int i = 0; i < trackbar.Length; i++)
                    {
                        sPort.Write(trackbar[i].ToString());
                    }
                    sPort.Write("#");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                
                tbSlider.Text = trackBarDC.Value.ToString();
                tbSkyt.Text = "";
                lastValue = trackBarDC.Value;
            }
        }

        private void numGrense_ValueChanged(object sender, EventArgs e)
        {
            // Update the threshold to the numeric value chosen in the GUI
            threshold = Convert.ToInt16(numGrense.Value);
        }

        private void btnPID_Click(object sender, EventArgs e)
        {
            // Checks if the PID-values are valid
            bool isInt = true;
            foreach(char c in (tbKp.Text + tbKi.Text + tbKd.Text))
            {
                if (!Char.IsNumber(c))
                {
                    isInt = false;
                    MessageBox.Show("Values in PID-tuning is not valid integers");
                    break;
                }
            }

            // If the PID-values are valid, send them. Values are between 0-9
            if (isInt)
            {
                // Send the chosen PID-values when the "Apply"-button is pushed
                string pidmsg = "C";
                pidmsg += Convert.ToInt16(tbKp.Text);
                pidmsg += Convert.ToInt16(tbKi.Text);
                pidmsg += Convert.ToInt16(tbKd.Text);
                pidmsg += "#";
                try
                {
                    for (int i = 0; i < pidmsg.Length; i++)
                    {
                        sPort.Write(pidmsg[i].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
               
            }
        }

        // When a button is pushed down while the trackbar is in focus
        private void trackBarDC_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Space)    // Checks if the key pushed is spacebar, which will make the solenoid shoot
                {
                    // Set solenoid
                    sPort.Write("S");
                    sPort.Write("1");
                    sPort.Write("3");
                    sPort.Write("3");
                    sPort.Write("#");
                    System.Threading.Thread.Sleep(200); 

                    // Reset solenoid
                    sPort.Write("S");
                    sPort.Write("0");
                    sPort.Write("#");

                    tbSkyt.Text = "SHOOT!";
                    gun.Stop();
                    gun.Play();
                }
                if (e.KeyCode == Keys.A)        // Checks if the key pushed is 'A', which will turn the servo half way left
                {
                    sPort.Write("D");
                    sPort.Write("6");
                    sPort.Write("4");
                    sPort.Write("#");
                    tbServo.Text = "Left";
                }
                if (e.KeyCode == Keys.S)        // Checks if the key pushed is 'D', which will turn the servo to the middle
                {
                    sPort.Write("D");
                    sPort.Write("1");
                    sPort.Write("2");
                    sPort.Write("7");
                    sPort.Write("#");
                    tbServo.Text = "Mid";
                }
                else if (e.KeyCode == Keys.D)   // Checks if the key pushed is 'D', which will turn the servo half way right
                {
                    sPort.Write("D");
                    sPort.Write("1");
                    sPort.Write("9");
                    sPort.Write("2");
                    sPort.Write("#");
                    tbServo.Text = "Right";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // Thread reading messages from node 2
        private void bwDatainnsamler2_DoWork(object sender, DoWorkEventArgs e)
        {
            readbuffer = "";
            charInput  = '*';

            // Look for the start-sign
            while (charInput != '$')
            {
                try
                {
                    charInput = Convert.ToChar(sPort.ReadChar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                
            }
            readbuffer = "$";

            // The message is received here, until the stop-sign is read
            while (charInput != '*')
            {
                try
                {
                    charInput = Convert.ToChar(sPort.ReadChar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                
                readbuffer += charInput;
            }
            message = readbuffer;
        }

        private void bwDatainnsamler2_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (message.StartsWith("$tap")) // For troubleshooting
            {
                lost();
            }
            txtData2.Text = message;
            if (!exit) bwDatainnsamler2.RunWorkerAsync();  // If we want to continue, run the thread again
            else
            {
                if (sPort != null)
                {
                    if (sPort.IsOpen) sPort.Close();
                }
                Application.Exit();
            }
        }
    }
}

﻿// Applikasjon som har som mål å snakke med mikrokontrolleren ved hjelp av seriell kommunikasjon
// Steg 1: Få til kommunikasjon
// Steg 2: Utvid med ulike funksjoner. Styring av motor, styring av meny, vise score, vise errors, ha et outputvindu


using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;          // Seriell port - klasse

namespace TTK4155___GUI
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}

% FOR HELICOPTER NR 3-10
% This file contains the initialization for the helicopter assignment in
% the course TTK4115. Run this file before you execute QuaRC_ -> Build 
% to build the file heli_q8.mdl.

% Oppdatert h�sten 2006 av Jostein Bakkeheim
% Oppdatert h�sten 2008 av Arnfinn Aas Eielsen
% Oppdatert h�sten 2009 av Jonathan Ronen
% Updated fall 2010, Dominik Breu
% Updated fall 2013, Mark Haring
% Updated spring 2015, Mark Haring


%%%%%%%%%%% Calibration of the encoder and the hardware for the specific
%%%%%%%%%%% helicopter
Joystick_gain_x = 1;
Joystick_gain_y = -1;


%%%%%%%%%%% Physical constants
g = 9.81; % gravitational constant [m/s^2]
l_c = 0.46; % distance elevation axis to counterweight [m]
l_h = 0.66; % distance elevation axis to helicopter head [m]
l_p = 0.175; % distance pitch axis to motor [m]
m_c = 1.92; % Counterweight mass [kg]
m_p = 0.72; % Motor mass [kg]


%%%%%%%%%%% Fra Part 1 - Problem 1-4
%%%%%%%%%%% Egne konstanter, m�linger og utregninger
V_s = 7.15;                                 % Motorspenning sum: M�lt og justert flere ganger
K_f = -(g*(m_c*l_c-2*m_p*l_h))/(V_s*l_h);   % Motorkraftkonstant Kf

J_p = 2*m_p*l_p^2;                          % Ligning (5a) side 14 i oppgavetekst
J_e = m_c*l_c^2+2*m_p*l_h^2;                % Ligning (5b) side 14 i oppgavetekst
J_lambda = (m_c*l_c^2)+2*m_p*(l_h^2+l_p^2);   % Ligning (5c) side 14 i oppgavetekst

L_1 = K_f*l_p;                              % Funnet ved utregning i Part 1 - Problem 1
L_2 = g*(m_c*l_c - 2*m_p*l_h);              % Funnet ved utregning i Part 1 - Problem 1
L_3 = K_f*l_h;                              % Funnet ved utregning i Part 1 - Problem 1
L_4 = -(K_f*l_h);                           % DENNE ER ENDRET HER! SER AT JEG GJORDE FEIL!

K_1 = L_1/J_p;
K_2 = L_3/J_e;
K_3 = (L_4*V_s)/J_lambda;


%%%%%%%%%%% Part 2 - Problem 1
omega_n = 2.7;      % En f�rste gjetning p� omega. H�yere omega -> kjappere respons
zeta = 1;         % Zeta = 1 gir et kritisk dempet system. Kan pr�ve litt forskjellig (under 1)

K_pp = (omega_n*omega_n)/K_1;       % Funnet via utregning problem 1
K_pd = (2*zeta*omega_n)/K_1;        % Funnet via utregning problem 1

h_1 = tf(K_1*K_pp, [1, K_1*K_pd, K_1*K_pp]);  % Transferfunksjon pitch
%step(h_1);                                    % Stegresponsen til pitch tf (BRUK FOR TUNING OMEGA)

%%%%%%%%%%% Part 2 - Problem 2
K_rp = -0.6;      % EN F�RSTE GJETNING P� K_rp! Denne skal v�re negativ. Jo mer negativ, jo kjappere
                  % P-kontroller-konstant for travel-rate

h_2 = tf(K_3*K_rp, [1, K_3*K_rp]);  % Transferfunksjon travel-rate
%step(h_2);                          % Stegresponsen til transferfunksjonen

%%%%%%%%%%% Part 3 - Problem 2
A = [0 1 0; 0 0 0; 0 0 0];
B = [0 0; 0 K_1; K_2 0];
C = [1 0 0; 0 0 1];
D = 0;
Q = [100 0 0; 0 40 0; 0 0 30];
R = [1 0; 0 1];
K = lqr(A, B, Q, R)
P = inv(C*inv(B*K - A)*B)

damp(A-B*K)


